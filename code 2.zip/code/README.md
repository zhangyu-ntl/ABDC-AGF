# VitaCLIP

Multimodal cattle behavior recognition (video + IMU) with **CE + Adaptive Tversky** and dynamic \(\lambda_{\mathrm{ATV}}\in[0.3,0.7]\).

## Layout

```text
code/
├── training/       # model, dynamic-λ loss, train entry
├── video_dataset/  # dataset + dataloader
├── scripts/        # cow_train.sh, run_5seeds.sh
└── weights/        # place .pth here (not shipped)
```

## Availability

| Item | Status |
|------|--------|
| Source code | Yes |
| Preprocessing / CSV format | Yes (below) |
| Seeds | Yes (`--seed`; `run_5seeds.sh` uses `42 123 2024 7 2025`) |
| Official splits + raw data | Upon reasonable request |
| Pretrained `.pth` | Upon reasonable request (put under `weights/`) |

## Setup

```bash
pip install -r requirements.txt
# install a CUDA build of PyTorch separately if needed
```

## Data layout & split CSV

```text
behavior/
├── train-video/  val-video/
├── train-table/  val-table/
├── train_balanced.csv
└── val_balanced.csv
```

CSV lines: `<video_filename>,<imu_filename>,<label>` with `label` in **1–6**.

## Train

```bash
export DATA_ROOT=/path/to/behavior
export SEED=42
# optional: export PRETRAIN=weights/best_model.pth
bash scripts/cow_train.sh

# five seeds
bash scripts/run_5seeds.sh
```

Eval: same entry with `--eval_only --pretrain /path/to/ckpt.pth`.

## Dynamic λ_ATV

\[
\lambda_{\mathrm{ATV}}(t)=\mathrm{clip}\Big(
0.3+0.4\,\sigma\big((\bar L_{\mathrm{ATV}}-\bar L_{\mathrm{CE}})/\tau\big),\,0.3,\,0.7\Big)
\]

See `training/improved_losses_dynamic_lambda.py` and `training/train-Behavior-dynamic-lambda.py`.
