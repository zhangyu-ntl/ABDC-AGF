#!/usr/bin/env bash
# VitaCLIP training (dynamic λ_ATV)
# Usage: DATA_ROOT=/path/to/behavior SEED=42 bash scripts/cow_train.sh
set -eo pipefail
cd "$(dirname "$0")/.."

DATA_ROOT="${DATA_ROOT:-/path/to/behavior}"
PRETRAIN="${PRETRAIN:-}"
SEED="${SEED:-42}"
GPUS="${GPUS:-0}"
EXP_DIR="${EXP_DIR:-train_output/result_seed${SEED}}"

mkdir -p "${EXP_DIR}"

PRETRAIN_ARGS=()
if [[ -n "${PRETRAIN}" ]]; then
  PRETRAIN_ARGS+=(--pretrain "${PRETRAIN}")
fi

python3 ./training/train-Behavior-dynamic-lambda.py \
    --checkpoint_dir "${EXP_DIR}" \
    --seed "${SEED}" \
    --gpus "${GPUS}" \
    "${PRETRAIN_ARGS[@]}" \
    --num_steps "${NUM_STEPS:-10000}" \
    --save_freq 1000 \
    --eval_freq 500 \
    --print_freq 200 \
    --batch_size "${BATCH_SIZE:-2}" \
    --batch_split 16 \
    --num_workers "${NUM_WORKERS:-4}" \
    --lr 1.5e-5 \
    --warmup_steps 1500 \
    --weight_decay 0.1 \
    --grad_clip 1.0 \
    --train_list_path "${DATA_ROOT}/train_balanced.csv" \
    --val_list_path "${DATA_ROOT}/val_balanced.csv" \
    --train_data_root "${DATA_ROOT}/train-video" \
    --val_data_root "${DATA_ROOT}/val-video" \
    --accel_train_dir "${DATA_ROOT}/train-table" \
    --accel_val_dir "${DATA_ROOT}/val-table" \
    --accel_dim 9 \
    --sampling_rate 16 \
    --auto_augment "rand-m9-n2-mstd1.0-inc1" \
    --interpolation bicubic \
    --spatial_size 224 \
    --num_frames 8 \
    --accel_num_layers 6 \
    --accel_d_model 768 \
    --accel_nhead 8 \
    --accel_dim_feedforward 2048 \
    --accel_dropout 0.15 \
    --mean 0.485 0.456 0.406 \
    --std 0.229 0.224 0.225 \
    --use_dynamic_sample \
    --use_pyramid \
    --use_keyframe \
    --use_dual_path_attention \
    --dual_path_fusion_method gate \
    --use_context \
    --use_cross_attn \
    --use_gate \
    --loss_type ce_adaptive_tversky_dynamic \
    --lambda_mode dynamic \
    --lambda_min 0.3 \
    --lambda_max 0.7 \
    --lambda_tau 1.0 \
    --lambda_ema 0.9 \
    --tversky_alpha 0.7 \
    --label_smoothing 0.1 \
    2>&1 | tee "${EXP_DIR}/train-$(date +"%Y%m%d_%H%M%S").log"
