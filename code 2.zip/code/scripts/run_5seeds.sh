#!/usr/bin/env bash
# Run training 5 times with different random seeds.
# Seeds: 42 123 2024 7 2025
set -eo pipefail
cd "$(dirname "$0")/.."

DATA_ROOT="${DATA_ROOT:-/path/to/behavior}"
PRETRAIN="${PRETRAIN:-}"
GPUS="${GPUS:-0}"
SEEDS="${SEEDS:-42 123 2024 7 2025}"

for SEED in ${SEEDS}; do
  echo "========== seed=${SEED} =========="
  DATA_ROOT="${DATA_ROOT}" PRETRAIN="${PRETRAIN}" SEED="${SEED}" GPUS="${GPUS}" \
    EXP_DIR="train_output/result_seed${SEED}" \
    bash scripts/cow_train.sh
done

echo "[DONE] finished seeds: ${SEEDS}"
