from typing import Union, List
import torch
import torch.nn as nn
from Accelerometer_EncoderUtils import (
    QuickGELU, LayerNorm, AccelerometerTokenizer, PositionalEncoding, _get_clones
)
from SelfAttention import SelfAttention             # 新增
from ContextAwareModule import ContextAwareModule   # 新增

class TransformerEncoderLayer(nn.Module):
    def __init__(self, d_model, nhead, dim_feedforward=2048, dropout=0.1):
        super().__init__()
        self.self_attn = SelfAttention(embed_dim=d_model, num_heads=nhead)
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(dim_feedforward, d_model)
        self.norm1 = LayerNorm(d_model)
        self.norm2 = LayerNorm(d_model)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        #self.use_accel_self_attn = use_accel_self_attn

    def forward(self, src):
        src2 = self.norm1(src)
        src2 = self.self_attn(src2)
        src = src + self.dropout1(src2)
        src2 = self.norm2(src)
        src2 = self.linear2(self.dropout(torch.relu(self.linear1(src2))))
        src = src + self.dropout2(src2)
        return src

class AccelerometerEncoder(nn.Module):
    def __init__(
        self,
        accel_dim=11,
        accel_d_model=768,
        accel_nhead=8,
        accel_num_layers=6,
        accel_dim_feedforward=2048,
        accel_dropout=0.1,
        use_context=True,
    ):
        super().__init__()
        self.tokenizer = AccelerometerTokenizer(accel_dim, accel_d_model)
        self.pos_encoder = PositionalEncoding(accel_d_model)
        self.layers = _get_clones(
            TransformerEncoderLayer(
                accel_d_model, accel_nhead, accel_dim_feedforward, accel_dropout
            ),
            accel_num_layers,
        )
        self.norm = LayerNorm(accel_d_model)
        self.use_context = use_context
        if use_context:
            self.context = ContextAwareModule(accel_d_model)

    def forward(self, src):
        B, L, C = src.size()
        src = src.view(B * L, C)  # 展平为 [B*L, C]
        src = self.tokenizer(src)  # [B*L, D]
        src = src.view(B, L, -1)  # 重新调整为 [B, L, D]
        src = src.permute(1, 0, 2)  # [L, B, D]
        src = self.pos_encoder(src)
        for layer in self.layers:
            src = layer(src)
        src = self.norm(src)
        src = src.permute(1, 0, 2)  # [B, L, D]
        if self.use_context:
            src = self.context(src)
        return src

        print(f"[AccelerometerEncoder] a_tokens shape: {a_tokens.shape}")
        return a_tokens
