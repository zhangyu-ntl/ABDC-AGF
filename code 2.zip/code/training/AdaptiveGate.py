# 特征融合阶段
# 定义逐样本自适应权重模块

import torch
import torch.nn as nn
import torch.nn.functional as F


class AdaptiveGate(nn.Module):
    """
    逐样本自适应权重融合
    输入: v [B, C], a [B, C]
    输出: fused [B, C], alpha [B, 1]
    """
    def __init__(self, dim: int):
        super().__init__()
        # 注意：这里 dim 是最大可能维度，实际运行时会动态截断
        self.w = nn.Sequential(
            nn.Linear(dim * 2, 64),
            nn.ReLU(inplace=True),
            nn.Linear(64, 1),
            nn.Sigmoid()
        )

    def forward(self, v: torch.Tensor, a: torch.Tensor):
        # ---------- 统一 batch 维 ----------
        B_v, B_a = v.shape[0], a.shape[0]
        if B_v != B_a:
            min_B = min(B_v, B_a)
            v = v[:min_B]
            a = a[:min_B]

        # ---------- 统一特征维 ----------
        min_dim = min(v.shape[-1], a.shape[-1])
        v = v[..., :min_dim]
        a = a[..., :min_dim]

        z = torch.cat([v, a], dim=-1)
        alpha = self.w(z)
        fused = alpha * v + (1 - alpha) * a
        return fused, alpha