#!/usr/bin/env python
from typing import Tuple, Optional
import torch
import torch.nn as nn
from Accelerometer_Encoder import AccelerometerEncoder
from BehaviorCLIP_vision_encoder import CLIPVisionEncoder
from BiDirectionalDynamicCrossAttention import BiDirectionalDynamicCrossAttention
from AdaptiveGate import AdaptiveGate


def build_visual_encoder(
    video_encoder_type: str,
    input_size: Tuple[int, int],
    num_frames: int,
    feature_dim: int,
    patch_size: Tuple[int, int],
    num_heads: int,
    num_layers: int,
    mlp_factor: float,
    embed_dim: int,
    use_dynamic_sample: bool,
    use_keyframe: bool,
    use_spatial: bool,
    use_temporal: bool,
    use_pyramid: bool,
    use_dual_path_attention: bool,
    dual_path_fusion_method: str,
    use_contrastive_learning: bool,
    contrastive_temperature: float,
    contrastive_time_window: int,
    contrastive_spatial_window: int,
    use_temporal_contrast: bool,
    use_positional_contrast: bool,
):
    encoder_type = video_encoder_type.lower()
    if encoder_type == "clip":
        return CLIPVisionEncoder(
            input_size=input_size,
            num_frames=num_frames,
            feature_dim=feature_dim,
            patch_size=patch_size,
            num_heads=num_heads,
            num_layers=num_layers,
            mlp_factor=mlp_factor,
            embed_dim=embed_dim,
            use_dynamic_sample=use_dynamic_sample,
            use_keyframe=use_keyframe,
            use_spatial=use_spatial,
            use_temporal=use_temporal,
            use_pyramid=use_pyramid,
            use_dual_path_attention=use_dual_path_attention,
            dual_path_fusion_method=dual_path_fusion_method,
            use_contrastive_learning=use_contrastive_learning,
            contrastive_temperature=contrastive_temperature,
            contrastive_time_window=contrastive_time_window,
            contrastive_spatial_window=contrastive_spatial_window,
            use_temporal_contrast=use_temporal_contrast,
            use_positional_contrast=use_positional_contrast,
        )
    raise ValueError(
        f"Unsupported video_encoder_type={video_encoder_type!r}. "
        "This release ships the CLIP encoder only."
    )


class VitaCLIP(nn.Module):
    def __init__(
        self,
        input_size: Tuple[int, int] = (224, 224),
        num_frames: int = 8,
        feature_dim: int = 768,
        patch_size: Tuple[int, int] = (16, 16),
        num_heads: int = 12,
        num_layers: int = 12,
        mlp_factor: float = 4.0,
        embed_dim: int = 512,
        accel_dim: int = 9,
        accel_d_model: int = 768,
        accel_nhead: int = 8,
        accel_num_layers: int = 6,
        accel_dim_feedforward: int = 2048,
        accel_dropout: float = 0.1,
        num_classes: int = 6,
        video_encoder_type: str = "clip",
        video_only: bool = False,
        use_distill: bool = False,
        teacher_ckpt: str = None,
        use_dynamic_sample: bool = False,
        use_keyframe: bool = False,
        use_spatial: bool = False,
        use_temporal: bool = False,
        use_pyramid: bool = False,
        use_dual_path_attention: bool = False,
        dual_path_fusion_method: str = "gate",
        use_context: bool = False,
        use_accel_self_attn: bool = False,
        use_cross_attn: bool = False,
        use_gate: bool = False,
        use_contrastive_learning: bool = False,
        contrastive_temperature: float = 0.07,
        contrastive_time_window: int = 2,
        contrastive_spatial_window: int = 3,
        use_temporal_contrast: bool = True,
        use_positional_contrast: bool = True,
        contrastive_loss_weight: float = 0.1,
    ):
        super().__init__()
        if use_distill:
            raise ValueError("Distillation is not included in this release.")
        self.video_only = video_only
        self.video_encoder_type = video_encoder_type.lower()

        self.visual = build_visual_encoder(
            video_encoder_type=self.video_encoder_type,
            input_size=input_size,
            num_frames=num_frames,
            feature_dim=feature_dim,
            patch_size=patch_size,
            num_heads=num_heads,
            num_layers=num_layers,
            mlp_factor=mlp_factor,
            embed_dim=embed_dim,
            use_dynamic_sample=use_dynamic_sample,
            use_keyframe=use_keyframe,
            use_spatial=use_spatial,
            use_temporal=use_temporal,
            use_pyramid=use_pyramid,
            use_dual_path_attention=use_dual_path_attention,
            dual_path_fusion_method=dual_path_fusion_method,
            use_contrastive_learning=use_contrastive_learning,
            contrastive_temperature=contrastive_temperature,
            contrastive_time_window=contrastive_time_window,
            contrastive_spatial_window=contrastive_spatial_window,
            use_temporal_contrast=use_temporal_contrast,
            use_positional_contrast=use_positional_contrast,
        )

        if not video_only:
            self.accelerometer = AccelerometerEncoder(
                accel_dim=accel_dim,
                accel_d_model=accel_d_model,
                accel_nhead=accel_nhead,
                accel_num_layers=accel_num_layers,
                accel_dim_feedforward=accel_dim_feedforward,
                accel_dropout=accel_dropout,
                use_context=use_context,
            )
        else:
            self.accelerometer = None

        if not video_only and use_cross_attn and use_gate:
            self.cross_attn = BiDirectionalDynamicCrossAttention(dim=feature_dim)
            self.fusion = AdaptiveGate(dim=feature_dim)
        else:
            self.cross_attn = None
            self.fusion = None

        self.classifier = nn.Linear(feature_dim, num_classes)
        self.teacher = None

    def forward(self, video: torch.Tensor, accel: Optional[torch.Tensor] = None):
        v_tokens, key_score = self.visual.forward_tokens(video)  # [B, T, C]

        if self.video_only:
            fused = v_tokens.mean(dim=1)
            alpha = None
        else:
            a_tokens = self.accelerometer(accel)  # [B, L, C]
            if self.cross_attn is not None and self.fusion is not None:
                v2a, a2v = self.cross_attn(v_tokens, a_tokens)
                fused, alpha = self.fusion(v2a, a2v)
            else:
                fused = (v_tokens.mean(dim=1) + a_tokens.mean(dim=1)) / 2
                alpha = None

        logits = self.classifier(fused)
        return {"logits": logits, "alpha": alpha, "key_score": key_score}

    def forward_accel(self, accel):
        return self.accelerometer(accel)
