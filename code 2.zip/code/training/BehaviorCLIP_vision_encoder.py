#!/usr/bin/env python
# BehaviorCLIP_vision_encoder.py

import torch.nn.functional as F
from operator import mul
from functools import reduce
import math
from typing import Tuple
import numpy as np
import torch
import torch.nn as nn
from einops import rearrange

from BehaviorCLIP_vision_encoder_utils import (
    QuickGELU, LayerNorm, TransformerEncoderLayer, ImagePatchEmbed2D
)

# ===== 新增模块 =====
from dynamic_frame_sampler import LocalDynamicFrameSampler
from feature_pyramid import GlobalFeaturePyramid
from KeyFramePredictor import KeyFramePredictor
from DualPathSpatioTemporalAttention import DualPathSpatioTemporalAttention
from BehaviorCLIP_vision_encoder_utils import Attention


class TemporalAttention(nn.Module):
    def __init__(self, feature_dim, num_heads):
        super().__init__()
        self.attn = Attention(
            q_in_dim=feature_dim, k_in_dim=feature_dim, v_in_dim=feature_dim,
            qk_proj_dim=feature_dim, v_proj_dim=feature_dim,
            num_heads=num_heads, out_dim=feature_dim
        )

    def forward(self, x):
        return self.attn(x, x, x)


class CLIPVisionEncoder(nn.Module):
    def __init__(
        self,
        input_size: Tuple[int, int] = (224, 224),
        num_frames: int = 8,
        feature_dim: int = 768,
        patch_size: Tuple[int, int] = (16, 16),
        num_heads: int = 12,
        num_layers: int = 12,
        mlp_factor: float = 4.0,
        embed_dim: int = 512,
        # ===== 5 个独立开关 =====
        use_dynamic_sample: bool = False,
        use_keyframe: bool = False,
        use_spatial: bool = False,
        use_temporal: bool = False,
        use_pyramid: bool = False,
        # ===== 双路径时空注意力开关 =====
        use_dual_path_attention: bool = False,  # 如果为True，将替代use_spatial和use_temporal
        dual_path_fusion_method: str = 'gate',  # 'gate', 'add', 'concat'
        # ===== 对比学习开关 =====
        use_contrastive_learning: bool = False,  # 是否使用时间-位置对比学习
        contrastive_temperature: float = 0.07,  # 对比学习温度参数
        contrastive_time_window: int = 2,  # 时间对比的正样本窗口
        contrastive_spatial_window: int = 3,  # 位置对比的正样本窗口
        use_temporal_contrast: bool = True,  # 是否使用时间对比
        use_positional_contrast: bool = True,  # 是否使用位置对比
    ):
        super().__init__()
        self.feature_dim = feature_dim
        self.num_frames = num_frames

        # 开关
        self.use_dynamic_sample = use_dynamic_sample
        self.use_keyframe = use_keyframe
        self.use_spatial = use_spatial
        self.use_temporal = use_temporal
        self.use_pyramid = use_pyramid
        self.use_dual_path_attention = use_dual_path_attention
        self.dual_path_fusion_method = dual_path_fusion_method
        self.use_contrastive_learning = use_contrastive_learning

        # 基础组件
        self.patch_embed = ImagePatchEmbed2D(
            img_size=input_size[0], patch_size=patch_size[0], in_chans=3, embed_dim=feature_dim
        )
        self.num_patches = (input_size[0] // patch_size[0]) ** 2 + 1
        self.cls_token = nn.Parameter(torch.zeros(feature_dim))
        self.pos_embed = nn.Parameter(torch.zeros(self.num_patches, feature_dim))
        self.time_embed = nn.Parameter(torch.zeros(num_frames, feature_dim))

        self.blocks = nn.ModuleList([
            TransformerEncoderLayer(
                in_feature_dim=feature_dim,
                qkv_dim=feature_dim,
                num_heads=num_heads,
                mlp_factor=mlp_factor,
                num_frames=num_frames,
                patch_size=patch_size,
            ) for _ in range(num_layers)
        ])
        self.ln_pre = LayerNorm(feature_dim)
        self.ln_post = LayerNorm(feature_dim)
        scale = feature_dim ** -0.5
        self.proj = nn.Parameter(scale * torch.randn(feature_dim, embed_dim))

        # 按需实例化
        if self.use_dynamic_sample:
            self.sampler = LocalDynamicFrameSampler(num_frames)
        if self.use_pyramid:
            self.pyramid = GlobalFeaturePyramid([768])
        if self.use_keyframe:
            self.keypred = KeyFramePredictor(dim=feature_dim)
        
        # 对比学习（本发布默认关闭；启用需自备模块）
        if self.use_contrastive_learning:
            raise ValueError("Contrastive learning is not included in this release.")
        self.contrastive_module = None

        # 双路径时空注意力或独立注意力模块
        if self.use_dual_path_attention:
            self.dual_path_attn = DualPathSpatioTemporalAttention(
                feature_dim=feature_dim,
                num_heads=num_heads,
                qkv_dim=feature_dim,
                fusion_method=dual_path_fusion_method
            )
            self.use_temporal = False
            self.use_spatial = False
        else:
            self.dual_path_attn = None
            if self.use_temporal:
                self.temp_attn = TemporalAttention(feature_dim=feature_dim, num_heads=num_heads)
            if self.use_spatial:
                raise ValueError("Legacy SpatialAttention is not included in this release; use --use_dual_path_attention.")

        self._initialize_weights()

    def _initialize_weights(self):
        nn.init.normal_(self.cls_token, std=0.02)
        nn.init.normal_(self.pos_embed, std=0.02)
        nn.init.normal_(self.time_embed, std=0.02)

    def temporal_encoding(self, x, T, B):
        x = rearrange(x, '(b t) n d -> (b n) t d', b=B, t=T)
        if T != self.time_embed.size(0):
            time_embed = self.time_embed.unsqueeze(0).transpose(1, 2)
            time_embed = torch.nn.functional.interpolate(time_embed, size=T, mode='nearest')
            time_embed = time_embed.transpose(1, 2).squeeze(0)
            x = x + time_embed
        else:
            x = x + self.time_embed
        x = rearrange(x, '(b n) t d -> (b t) n d', b=B, t=T)
        return x

    def forward_tokens(self, x: torch.Tensor, return_patch_tokens: bool = False):
        B, C, T, H, W = x.size()

        # 1. 动态帧采样
        if self.use_dynamic_sample:
            indices = self.sampler.select(T)
            x = x[:, :, indices, :, :]
            T = len(indices)

        x = x.permute(0, 2, 1, 3, 4).flatten(0, 1)          # [B*T, C, H, W]
        x = self.patch_embed(x)                              # [B*T, N, C]
        patch_tokens = x  # 保存patch tokens用于位置对比学习
        x = torch.cat([self.cls_token.view(1, 1, -1).repeat(x.size(0), 1, 1), x], dim=1)
        x = x + self.pos_embed
        x = self.temporal_encoding(x, T, B)
        x = self.ln_pre(x)

        # 2. 主干 Transformer
        for blk in self.blocks:
            x = blk(x)

        # 取出 cls token 并 reshape 成 [B, T, C]
        cls_tokens = rearrange(x[:, 0], '(b t) c -> b t c', b=B, t=T)

        # 3. 注意力机制应用
        if self.use_dual_path_attention:
            # 使用双路径时空注意力（统一处理）
            cls_tokens = self.dual_path_attn(cls_tokens)  # [B, T, C]
        else:
            # 使用独立的注意力模块（向后兼容）
            # 3a. 空间注意力: [B, T, C] -> [B, C, 1, T] -> 卷积 -> [B, T, C]
            if self.use_spatial:
                B, T, C = cls_tokens.shape
                cls_tokens = cls_tokens.permute(0, 2, 1).unsqueeze(2)   # [B, C, 1, T]
                cls_tokens = self.spatial_attn(cls_tokens)              # 4-D 卷积
                cls_tokens = cls_tokens.squeeze(2).permute(0, 2, 1)     # 还原 [B, T, C]
            
            # 3b. 时序注意力（输入必须是 [B, T, C]）
            if self.use_temporal:
                cls_tokens = self.temp_attn(cls_tokens)

        # 5. 特征金字塔
        if self.use_pyramid:
            cls_tokens = self.pyramid(cls_tokens)

        # 6. 关键帧预测
        key_score = None
        if self.use_keyframe:
            key_score = self.keypred(cls_tokens)

        # 返回结果
        if return_patch_tokens:
            return cls_tokens, key_score, patch_tokens
        else:
            return cls_tokens, key_score

        print(f"[CLIPVisionEncoder] v_tokens shape: {v_tokens.shape}")
        return v_tokens

    def forward(self, x: torch.Tensor):
        cls_tokens, key_score = self.forward_tokens(x)
        cls_tokens = self.ln_post(cls_tokens.mean(dim=1))
        cls_tokens = cls_tokens @ self.proj
        return cls_tokens, key_score