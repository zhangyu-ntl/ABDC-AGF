from collections import OrderedDict
from typing import Tuple

import torch
import torch.nn as nn
from operator import mul
from functools import reduce
import math
import torch.nn.functional as F

class QuickGELU(nn.Module):
    def forward(self, x: torch.Tensor):
        return x * torch.sigmoid(1.702 * x)

class LayerNorm(nn.LayerNorm):
    """Subclass torch's LayerNorm to handle fp16."""

    def forward(self, x: torch.Tensor):
        orig_type = x.dtype
        ret = super().forward(x.type(torch.float32))
        return ret.type(orig_type)

class Attention(nn.Module):
    def __init__(
        self, q_in_dim: int, k_in_dim: int, v_in_dim: int,
        qk_proj_dim: int, v_proj_dim: int, num_heads: int,
        out_dim: int
    ):
        super().__init__()
        self.q_proj = nn.Linear(q_in_dim, qk_proj_dim)
        self.k_proj = nn.Linear(k_in_dim, qk_proj_dim)
        self.v_proj = nn.Linear(v_in_dim, v_proj_dim)
        self.out_proj = nn.Linear(v_proj_dim, out_dim)
        self.num_heads = num_heads
        assert qk_proj_dim % num_heads == 0 and v_proj_dim % num_heads == 0
        self._initialize_weights()

    def _initialize_weights(self):
        for m in (self.q_proj, self.k_proj, self.v_proj, self.out_proj):
            nn.init.xavier_uniform_(m.weight)
            nn.init.constant_(m.bias, 0.)

    def forward(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor):
        assert q.ndim == 3 and k.ndim == 3 and v.ndim == 3
        N = q.size(0); assert k.size(0) == N and v.size(0) == N
        Lq, Lkv = q.size(1), k.size(1); assert v.size(1) == Lkv
        q, k, v = self.q_proj(q), self.k_proj(k), self.v_proj(v)
        H = self.num_heads
        Cqk, Cv = q.size(-1) // H, v.size(-1) // H
        q = q.view(N, Lq, H, Cqk)
        k = k.view(N, Lkv, H, Cqk)
        v = v.view(N, Lkv, H, Cv)
        aff = torch.einsum('nqhc,nkhc->nqkh', q / (Cqk ** 0.5), k)
        aff = aff.softmax(dim=-2)
        mix = torch.einsum('nqlh,nlhc->nqhc', aff, v)
        out = self.out_proj(mix.flatten(-2))
        return out

class MultiHeadAttention(nn.Module):
    def __init__(self, embed_dim, num_heads, dropout=0.0):
        super(MultiHeadAttention, self).__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads
        assert self.head_dim * num_heads == embed_dim, "embed_dim must be divisible by num_heads"

        self.query_proj = nn.Linear(embed_dim, embed_dim)
        self.key_proj = nn.Linear(embed_dim, embed_dim)
        self.value_proj = nn.Linear(embed_dim, embed_dim)
        self.out_proj = nn.Linear(embed_dim, embed_dim)

        self.dropout = nn.Dropout(dropout)

    def forward(self, query, key, value, mask=None):
        batch_size = query.size(0)
        query_len = query.size(1)
        key_len = key.size(1)

        query = self.query_proj(query).view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        key = self.key_proj(key).view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        value = self.value_proj(value).view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)

        scores = torch.matmul(query, key.transpose(-2, -1)) / math.sqrt(self.head_dim)

        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)

        attention_weights = torch.softmax(scores, dim=-1)
        attention_weights = self.dropout(attention_weights)

        attention_output = torch.matmul(attention_weights, value)

        attention_output = attention_output.transpose(1, 2).contiguous().view(batch_size, query_len, self.embed_dim)
        attention_output = self.out_proj(attention_output)

        return attention_output, attention_weights

class MambaBlock(nn.Module):
    def __init__(self, d_model, dim_feedforward=2048, dropout=0.1, num_heads=8):
        super().__init__()
        # 使用自定义的 MultiHeadAttention
        self.self_attn = MultiHeadAttention(embed_dim=d_model, num_heads=num_heads, dropout=dropout)
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(dim_feedforward, d_model)
        self.norm1 = LayerNorm(d_model)
        self.norm2 = LayerNorm(d_model)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.feed_forward = nn.Sequential(
            nn.Linear(d_model, dim_feedforward),
            QuickGELU(),
            nn.Dropout(dropout),
            nn.Linear(dim_feedforward, d_model),
            nn.Dropout(dropout)
        )

    def forward(self, src):
        src2 = self.norm1(src)
        src2 = self.self_attn(query=src2, key=src2, value=src2)[0]
        src = src + self.dropout1(src2)
        src = src + self.feed_forward(self.norm2(src))
        return src

class TransformerEncoderLayer(nn.Module):
    def __init__(
        self,
        in_feature_dim: int = 768,
        qkv_dim: int = 768,
        num_heads: int = 12,
        mlp_factor: float = 4.0,
        mlp_dropout: float = 0.0,
        act: nn.Module = QuickGELU,
        use_summary_token: bool = False,
        use_local_prompts: bool = False,
        num_frames: int = 8,
        patch_size: Tuple[int, int] = (16, 16),
    ):
        super().__init__()
        self.mamba_block = MambaBlock(in_feature_dim, int(mlp_factor * in_feature_dim), mlp_dropout, num_heads)
        self.norm3 = LayerNorm(in_feature_dim)
        self.use_summary_token = use_summary_token
        self.use_local_prompts = use_local_prompts

        if self.use_summary_token or self.use_local_prompts:
            self.cls_proj = nn.Linear(in_feature_dim, in_feature_dim)
            self.num_frames = num_frames
        
        if self.use_summary_token:
            self.summary_ln = LayerNorm(in_feature_dim)
            self.summary_attn_layer = Attention(
                                    q_in_dim=in_feature_dim, k_in_dim=in_feature_dim, v_in_dim=in_feature_dim,
                                    qk_proj_dim=qkv_dim, v_proj_dim=qkv_dim, num_heads=num_heads, out_dim=in_feature_dim
                                )

        if self.use_local_prompts:
            self.local_prompts = nn.Parameter(torch.zeros(1, self.num_frames, in_feature_dim))
            self._initialize_cls_prompts(patch_size, in_feature_dim)

        self._initialize_weights()

    def _initialize_weights(self):
        pass

    def _initialize_cls_prompts(self, patch_size, prompt_dim):
        val = math.sqrt(6. / float(3 * reduce(mul, patch_size, 1) + prompt_dim))
        nn.init.uniform_(self.local_prompts.data, -val, val)

    def forward(self, x: torch.Tensor):
        if self.use_summary_token or self.use_local_prompts:
            BT, N, C = x.shape
            T = self.num_frames
            B = BT//T
            cls_token = x[:, 0, :].view(B, T, C)
            cls_token_proj = self.cls_proj(cls_token)
        
        if self.use_summary_token:
            summary_token_norm = self.summary_ln(cls_token_proj)
            summary_token_attn = cls_token_proj + self.summary_attn_layer(summary_token_norm, summary_token_norm, summary_token_norm)
            summary_token_attn_reshape = summary_token_attn.view(BT, 1, C)
            x = torch.cat([x, summary_token_attn_reshape], dim=1)

        if self.use_local_prompts:
            local_prompts = self.local_prompts.expand(B, -1, -1)
            if T != self.num_frames:
                token_multiplier = T//self.num_frames
                local_prompts = local_prompts.repeat(1,token_multiplier,1)
            local_prompts = local_prompts + cls_token_proj
            local_prompts = local_prompts.repeat_interleave(repeats=T, dim=0)
            x = torch.cat((x[:, :1, :], local_prompts, x[:, 1:, :]), dim=1)

        x = self.mamba_block(x)

        if self.use_summary_token:
            x = x[:, :-1, :]
        if self.use_local_prompts:
            x = torch.cat((x[:, :1, :], x[:, self.local_prompts.shape[1]+1:, :]), dim=1)

        return x

class ImagePatchEmbed2D(nn.Module):
    def __init__(self, img_size=224, patch_size=16, in_chans=3, embed_dim=768):
        super().__init__()
        num_patches = (img_size // patch_size) * (img_size // patch_size)
        self.img_size = img_size
        self.patch_size = patch_size
        self.num_patches = num_patches
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=patch_size)

    def forward(self, x):
        B, C, H, W = x.shape
        x = self.proj(x).flatten(2).transpose(1, 2)
        return x
