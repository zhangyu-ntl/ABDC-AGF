# 特征融合阶段
# 定义双向动态交叉注意力模块

import torch
import torch.nn as nn
import torch.nn.functional as F


class DynamicScaling(nn.Module):
    def __init__(self, dim, hidden=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.ReLU(inplace=True),
            nn.Linear(hidden, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        scale = self.net(x)  # [B, 1]
        return x * scale     # [B, C]

class BiDirectionalDynamicCrossAttention(nn.Module):
    """
    双向动态交叉注意力
    输入: video_feat [B, C] , accel_feat [B, T, C]
    输出: v2a [B, C] , a2v [B, C]
    """
    def __init__(self, dim, num_heads=8):
        super().__init__()
        self.v2a_attn = nn.MultiheadAttention(
            embed_dim=dim, num_heads=num_heads, batch_first=True
        )
        self.a2v_attn = nn.MultiheadAttention(
            embed_dim=dim, num_heads=num_heads, batch_first=True
        )
        self.norm_v = nn.LayerNorm(dim)
        self.norm_a = nn.LayerNorm(dim)
        self.num_heads = num_heads
        self.dynamic_v = DynamicScaling(dim)
        self.dynamic_a = DynamicScaling(dim)



    def forward(self, video_feat, accel_feat):
        # ---------- 维度保险 ----------
        if video_feat.dim() == 1:
            video_feat = video_feat.unsqueeze(0)          # [1, C]
        if accel_feat.dim() == 1:
            accel_feat = accel_feat.unsqueeze(0)          # [1, C]

        # 处理 video_feat 可能是 [B, T, C] 的情况
        if video_feat.dim() == 3:                       # [B, T, C]
            video_feat = video_feat.mean(dim=1)          # [B, C] - 平均池化时间维度
        
        B, C = video_feat.shape
        if accel_feat.dim() == 2:                       # [B, C]
            T = 1
            accel_feat = accel_feat.unsqueeze(1)        # [B, 1, C]
        else:                                           # [B, T, C]
            B, T, C = accel_feat.shape

        v = self.dynamic_v(self.norm_v(video_feat))       # [B, C]
        a = self.dynamic_a(self.norm_a(accel_feat))       # [B, T, C]

        # 扩展 v 到 [B, T, C]
        v = v.unsqueeze(1).expand(-1, T, -1)              # [B, T, C]

        # 把 batch-first 转成 seq-first
        v2a, _ = self.v2a_attn(query=a.transpose(0, 1),
                               key=v.transpose(0, 1),
                               value=v.transpose(0, 1))
        v2a = v2a.transpose(0, 1)                         # 还原 batch-first

        a2v, _ = self.a2v_attn(query=v.transpose(0, 1),
                               key=a.transpose(0, 1),
                               value=a.transpose(0, 1))
        a2v = a2v.transpose(0, 1)                         # 还原 batch-first

        # 平均回去
        return v2a.mean(dim=1), a2v.mean(dim=1)           # [B, C], [B, C]