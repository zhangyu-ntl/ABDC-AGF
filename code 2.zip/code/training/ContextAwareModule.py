#加速度部分
#定义上下文感知模块

import torch
import torch.nn as nn
import torch.nn.functional as F





class ContextAwareModule(nn.Module):
    def __init__(self, embed_dim):
        super(ContextAwareModule, self).__init__()
        self.fc = nn.Linear(embed_dim, embed_dim)
        self.relu = nn.ReLU()

    def forward(self, x):
        context = torch.mean(x, dim=1, keepdim=True)
        context = self.fc(context)
        context = self.relu(context)
        return x + context
