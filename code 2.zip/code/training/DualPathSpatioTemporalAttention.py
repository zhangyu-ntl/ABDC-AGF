# 视频部分
# 双路径时空注意力模块 (Dual-Path Spatio-Temporal Attention)
# 将时序注意力和空间注意力合并为一个统一的模块

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from BehaviorCLIP_vision_encoder_utils import LayerNorm, Attention


class DualPathSpatioTemporalAttention(nn.Module):
    """
    双路径时空注意力模块
    同时处理时序和空间两个维度的注意力
    
    输入: x [B, T, C]
    输出: x [B, T, C]
    
    双路径设计:
    - 路径1: 时序注意力路径 - 建模帧间时序关系
    - 路径2: 空间注意力路径 - 关注空间重要区域
    - 融合: 两个路径的输出通过门控机制融合
    """
    def __init__(
        self,
        feature_dim: int = 768,
        num_heads: int = 12,
        qkv_dim: int = 768,
        mlp_factor: float = 4.0,
        mlp_dropout: float = 0.0,
        fusion_method: str = 'gate',  # 'gate', 'add', 'concat'
    ):
        super().__init__()
        self.feature_dim = feature_dim
        self.fusion_method = fusion_method
        
        # ===== 路径1: 时序注意力 =====
        self.temporal_attn = Attention(
            q_in_dim=feature_dim, 
            k_in_dim=feature_dim, 
            v_in_dim=feature_dim,
            qk_proj_dim=qkv_dim, 
            v_proj_dim=qkv_dim, 
            num_heads=num_heads, 
            out_dim=feature_dim
        )
        self.temporal_norm = LayerNorm(feature_dim)
        
        # ===== 路径2: 空间注意力 =====
        # 使用1D卷积处理时序维度上的空间注意力
        # 输入: [B, T, C] -> [B, C, T] -> 卷积 -> [B, T, C]
        self.spatial_conv1 = nn.Conv1d(feature_dim, feature_dim // 4, kernel_size=1)
        self.spatial_conv2 = nn.Conv1d(feature_dim // 4, feature_dim, kernel_size=1)
        self.spatial_norm = LayerNorm(feature_dim)
        self.sigmoid = nn.Sigmoid()
        
        # ===== 融合机制 =====
        if fusion_method == 'gate':
            # 门控融合：学习两个路径的权重
            self.fusion_gate = nn.Sequential(
                nn.Linear(feature_dim * 2, feature_dim),
                nn.ReLU(),
                nn.Linear(feature_dim, 2),
                nn.Softmax(dim=-1)
            )
        elif fusion_method == 'concat':
            # 拼接后线性映射
            self.fusion_proj = nn.Linear(feature_dim * 2, feature_dim)
        elif fusion_method == 'add':
            # 简单相加（需要归一化）
            self.fusion_scale = nn.Parameter(torch.ones(1) * 0.5)
        
        # 最终归一化
        self.output_norm = LayerNorm(feature_dim)
    
    def forward(self, x: torch.Tensor):
        """
        前向传播
        输入: x [B, T, C]
        输出: x [B, T, C]
        """
        B, T, C = x.size()
        
        # ===== 路径1: 时序注意力 =====
        x_temporal_norm = self.temporal_norm(x)  # [B, T, C]
        x_temporal = x + self.temporal_attn(
            x_temporal_norm, 
            x_temporal_norm, 
            x_temporal_norm
        )  # [B, T, C]
        
        # ===== 路径2: 空间注意力 =====
        x_spatial_norm = self.spatial_norm(x)  # [B, T, C]
        # 转换为 [B, C, T] 进行1D卷积
        x_spatial = x_spatial_norm.permute(0, 2, 1)  # [B, C, T]
        # 空间注意力：通过卷积学习空间权重
        attention_weights = self.sigmoid(
            self.spatial_conv2(F.relu(self.spatial_conv1(x_spatial)))
        )  # [B, C, T]
        x_spatial = (x_spatial_norm.permute(0, 2, 1) * attention_weights).permute(0, 2, 1)  # [B, T, C]
        x_spatial = x + x_spatial  # 残差连接
        
        # ===== 融合两个路径 =====
        if self.fusion_method == 'gate':
            # 门控融合：学习自适应权重
            concat_features = torch.cat([x_temporal, x_spatial], dim=-1)  # [B, T, 2C]
            gates = self.fusion_gate(concat_features)  # [B, T, 2]
            gate_temporal = gates[:, :, 0:1]  # [B, T, 1]
            gate_spatial = gates[:, :, 1:2]   # [B, T, 1]
            fused = gate_temporal * x_temporal + gate_spatial * x_spatial  # [B, T, C]
        
        elif self.fusion_method == 'concat':
            # 拼接融合
            concat_features = torch.cat([x_temporal, x_spatial], dim=-1)  # [B, T, 2C]
            fused = self.fusion_proj(concat_features)  # [B, T, C]
        
        elif self.fusion_method == 'add':
            # 加权相加
            fused = self.fusion_scale * x_temporal + (1 - self.fusion_scale) * x_spatial
        
        # 最终归一化
        fused = self.output_norm(fused)
        
        return fused
    
    def get_attention_weights(self, x: torch.Tensor):
        """
        返回注意力权重（用于可视化）
        返回: (spatial_weights, fusion_gates)
        """
        B, T, C = x.size()
        
        # 时序注意力权重（如果有的话，这里简化处理）
        x_temporal_norm = self.temporal_norm(x)
        temporal_out = self.temporal_attn(x_temporal_norm, x_temporal_norm, x_temporal_norm)
        
        # 空间注意力权重
        x_spatial_norm = self.spatial_norm(x)
        x_spatial = x_spatial_norm.permute(0, 2, 1)
        spatial_weights = self.sigmoid(
            self.spatial_conv2(F.relu(self.spatial_conv1(x_spatial)))
        )
        
        # 融合门控权重
        if self.fusion_method == 'gate':
            x_temporal = x + temporal_out
            x_spatial = (x_spatial_norm.permute(0, 2, 1) * spatial_weights).permute(0, 2, 1) + x
            concat_features = torch.cat([x_temporal, x_spatial], dim=-1)
            fusion_gates = self.fusion_gate(concat_features)
        else:
            fusion_gates = None
        
        return spatial_weights, fusion_gates

