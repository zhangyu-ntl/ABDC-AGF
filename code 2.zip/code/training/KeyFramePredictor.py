#视频部分
#关键帧预测模块
import torch
import torch.nn as nn

class KeyFramePredictor(nn.Module):
    def __init__(self, dim, hidden_dim=256):   # 给默认值
        super().__init__()
        self.fc1 = nn.Linear(dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.sigmoid(self.fc2(x))
        return x.squeeze(-1)          # [B,T,1] -> [B,T]
