import argparse
import os

import torch
import torch.distributed as dist


def setup_arg_parser(parser: argparse.ArgumentParser):
    parser.add_argument('--checkpoint_dir', type=str,
                        help='checkpoint output path')
    parser.add_argument('--auto_resume', action='store_true',
                        help='auto resume from the last checkpoint from checkpoint_dir')
    parser.add_argument('--resume_path', type=str,
                        help='resume from manually specified checkpoint file, overriding auto_resume')
    parser.add_argument('--pretrain', type=str,
                        help='path to pretrained weights. will NOT override auto_resume of resume_path, '
                             'load optimizer state or enforce strict matching of checkpoint and model weights.')


def _find_autoresume_path(args: argparse.Namespace):
    print('Trying to auto resume from path:', args.checkpoint_dir)

    if os.path.isdir(args.checkpoint_dir):
        checkpoint_files = [x for x in os.listdir(args.checkpoint_dir) if x.startswith('checkpoint-') and x.endswith('.pth')]
        checkpoint_iters = []
        for x in checkpoint_files:
            try:
                x = x[len('checkpoint-'): -len('.pth')]
                x = int(x)
            except ValueError:
                continue
            checkpoint_iters.append(x)
    else:
        checkpoint_iters = []

    if len(checkpoint_iters) == 0:
        print('Did not find a valid checkpoint file.')
    else:
        checkpoint_iters.sort()
        args.resume_path = os.path.join(args.checkpoint_dir, 'checkpoint-%d.pth' % checkpoint_iters[-1])
        print(f'Found {len(checkpoint_iters)} checkpoint file(s).')
        print(f'Setting resume_path to {args.resume_path}')


def resume_from_checkpoint(
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        lr_sched: torch.optim.lr_scheduler._LRScheduler,
        loss_scaler: torch.cuda.amp.grad_scaler.GradScaler,
        args: argparse.Namespace,
) -> int:
    if args.pretrain is not None:
        print(f'[INFO] 正在加载预训练模型: {args.pretrain}')
        ckpt = torch.load(args.pretrain, map_location='cpu')
        
        # 显示检查点信息（如果有）
        if 'step' in ckpt:
            print(f'[INFO] 预训练模型来自 Step {ckpt["step"]}')
        if 'best_f1_score' in ckpt:
            print(f'[INFO] 预训练模型最佳 F1-score: {ckpt["best_f1_score"]:.4f}')
        if 'f1_score' in ckpt:
            print(f'[INFO] 预训练模型 F1-score: {ckpt["f1_score"]:.4f}')
        if 'accuracy' in ckpt:
            print(f'[INFO] 预训练模型 Accuracy: {ckpt["accuracy"]:.4f}')
        
        # 兼容两种格式：'model' (标准检查点) 或 'model_state_dict' (best_model.pth)
        if 'model' in ckpt:
            model_state = ckpt['model']
        elif 'model_state_dict' in ckpt:
            model_state = ckpt['model_state_dict']
        else:
            raise KeyError(f"检查点文件中未找到 'model' 或 'model_state_dict' 键。可用键: {list(ckpt.keys())}")
        
        load_result = model.load_state_dict(model_state, strict=False)
        if load_result.missing_keys:
            print(f'[WARN] 缺失的键 ({len(load_result.missing_keys)} 个): {load_result.missing_keys[:5]}...' if len(load_result.missing_keys) > 5 else f'[WARN] 缺失的键: {load_result.missing_keys}')
        if load_result.unexpected_keys:
            print(f'[WARN] 未使用的键 ({len(load_result.unexpected_keys)} 个): {load_result.unexpected_keys[:5]}...' if len(load_result.unexpected_keys) > 5 else f'[WARN] 未使用的键: {load_result.unexpected_keys}')
        print(f'[INFO] ✅ 预训练模型权重加载完成')

    if args.auto_resume and args.resume_path is None:
        _find_autoresume_path(args)

    if args.resume_path is None:
        print('Not resuming from a checkpoint.')
        return 0
    else:
        print(f'Resuming from checkpoint file {args.resume_path}')
        ckpt = torch.load(args.resume_path, map_location='cpu')
        # 兼容两种格式：'model' (标准检查点) 或 'model_state_dict' (best_model.pth)
        if 'model' in ckpt:
            model.load_state_dict(ckpt['model'], strict=False)
        elif 'model_state_dict' in ckpt:
            model.load_state_dict(ckpt['model_state_dict'], strict=False)
        else:
            raise KeyError(f"检查点文件中未找到 'model' 或 'model_state_dict' 键。可用键: {list(ckpt.keys())}")
        
        # 兼容两种格式的优化器状态
        if 'optimizer' in ckpt:
            try:
                optimizer.load_state_dict(ckpt['optimizer'])
                lr_sched.load_state_dict(ckpt['lr_sched'])
                loss_scaler.load_state_dict(ckpt['loss_scaler'])
                return ckpt.get('next_step', ckpt.get('step', 0))
            except (ValueError, KeyError) as e:
                print(f'[WARN] 优化器状态不匹配，仅加载模型权重: {e}')
                print('[INFO] 将从头开始训练（优化器和学习率调度器已重新初始化）')
                return 0
        elif 'optimizer_state_dict' in ckpt:
            try:
                optimizer.load_state_dict(ckpt['optimizer_state_dict'])
                lr_sched.load_state_dict(ckpt['lr_sched_state_dict'])
                loss_scaler.load_state_dict(ckpt['loss_scaler_state_dict'])
                return ckpt.get('next_step', ckpt.get('step', 0))
            except (ValueError, KeyError) as e:
                print(f'[WARN] 优化器状态不匹配，仅加载模型权重: {e}')
                print('[INFO] 将从头开始训练（优化器和学习率调度器已重新初始化）')
                return 0
        else:
            print('Optimizer state is NOT found in checkpoint.')
            return 0

def save_checkpoint(
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        lr_sched: torch.optim.lr_scheduler._LRScheduler,
        loss_scaler: torch.cuda.amp.grad_scaler.GradScaler,
        next_step: int,
        args: argparse.Namespace,
):
    if args.checkpoint_dir is None:
        return

    if not os.path.isdir(args.checkpoint_dir):
        os.makedirs(args.checkpoint_dir)

    to_save = {
        'model': model.state_dict(),
        'optimizer': optimizer.state_dict(),
        'lr_sched': lr_sched.state_dict(),
        'loss_scaler': loss_scaler.state_dict(),
        'next_step': next_step,
    }
    save_path = os.path.join(args.checkpoint_dir, f'checkpoint-{next_step}.pth')
    torch.save(to_save, save_path)
    print(f"Checkpoint saved to {save_path}")
