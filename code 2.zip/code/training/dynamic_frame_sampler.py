#视频部分
#定义局部动态帧采样模块
import numpy as np
import torch
class LocalDynamicFrameSampler:
    def __init__(self, num_frames, window_size=16, samples_per_window=2):
        self.num_frames = num_frames
        self.ws = window_size
        self.spw = samples_per_window

    def select(self, total_frames):
        indices = []
        num_win = total_frames // self.ws
        for w in range(num_win):
            base = w * self.ws
            end = min(base + self.ws, total_frames)
            indices.extend(np.random.choice(range(base, end), self.spw, replace=False))
        return sorted(indices)