#视频部分
#全局特征金字塔模块（全局1D）

import torch
import torch.nn as nn

class GlobalFeaturePyramid(nn.Module):
    def __init__(self, dims):
        super().__init__()
        self.projs = nn.ModuleList([nn.Linear(d, dims[-1]) for d in dims])

    def forward(self, feats):               # feats: list of [B,T,Ci]
        proj = [p(f) for f, p in zip(feats, self.projs)]  # 统一通道
        stacked = torch.stack(proj, dim=-1)               # [B,T,C,N]
        return stacked.mean(dim=-1)                       # [B,T,C]
