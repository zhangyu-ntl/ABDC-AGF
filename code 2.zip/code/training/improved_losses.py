"""
改进的损失函数集合
针对当前指标问题（特别是Precision偏低）设计
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class FocalLoss(nn.Module):
    """
    Focal Loss: 关注难分样本，提升整体性能
    
    原理: 对难分样本给予更高权重，自动降低易分样本的贡献
    适用: 类别不平衡、难分样本多的情况
    
    Args:
        alpha: 类别权重（可以是tensor或float）
        gamma: 聚焦参数，越大越关注难分样本（推荐2.0-3.0）
        label_smoothing: 标签平滑系数
    """
    def __init__(self, alpha=None, gamma=2.0, label_smoothing=0.0, reduction='mean'):
        super(FocalLoss, self).__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.label_smoothing = label_smoothing
        self.reduction = reduction
        
        # 处理alpha参数
        if isinstance(alpha, (float, int)):
            self.alpha = torch.tensor([alpha, 1 - alpha])
        elif isinstance(alpha, (list, np.ndarray)):
            self.alpha = torch.tensor(alpha)
        elif isinstance(alpha, torch.Tensor):
            self.alpha = alpha
        
    def forward(self, inputs, targets):
        """
        Args:
            inputs: [B, num_classes] 分类logits
            targets: [B] 类别标签
        """
        ce_loss = F.cross_entropy(inputs, targets, reduction='none', label_smoothing=self.label_smoothing)
        pt = torch.exp(-ce_loss)  # 预测概率
        
        # 应用alpha权重
        if self.alpha is not None:
            if self.alpha.device != inputs.device:
                self.alpha = self.alpha.to(inputs.device)
            if len(self.alpha.shape) == 1:
                alpha_t = self.alpha[targets]
            else:
                alpha_t = self.alpha
            focal_loss = alpha_t * (1 - pt) ** self.gamma * ce_loss
        else:
            focal_loss = (1 - pt) ** self.gamma * ce_loss
        
        if self.reduction == 'mean':
            return focal_loss.mean()
        elif self.reduction == 'sum':
            return focal_loss.sum()
        else:
            return focal_loss


class DiceLoss(nn.Module):
    """
    Dice Loss: 直接优化Precision和Recall的平衡
    
    原理: Dice系数衡量预测和真实的重叠度，直接优化Precision
    适用: Precision偏低的情况（如drinking的Precision只有61.99%）
    
    Args:
        smooth: 平滑系数，避免除零
        ignore_index: 忽略的类别索引
    """
    def __init__(self, smooth=1.0, ignore_index=None):
        super(DiceLoss, self).__init__()
        self.smooth = smooth
        self.ignore_index = ignore_index
    
    def forward(self, logits, targets):
        """
        Args:
            logits: [B, num_classes] 分类logits
            targets: [B] 类别标签
        """
        num_classes = logits.size(1)
        probs = F.softmax(logits, dim=1)
        
        # 转换为one-hot
        targets_one_hot = F.one_hot(targets, num_classes).float()
        
        # 计算每个类别的dice系数
        dice_scores = []
        for c in range(num_classes):
            pred_c = probs[:, c]
            target_c = targets_one_hot[:, c]
            
            intersection = (pred_c * target_c).sum()
            union = pred_c.sum() + target_c.sum()
            
            dice = (2.0 * intersection + self.smooth) / (union + self.smooth)
            dice_scores.append(dice)
        
        # Dice Loss = 1 - Dice Score
        dice_loss = 1.0 - torch.stack(dice_scores).mean()
        return dice_loss


class TverskyLoss(nn.Module):
    """
    Tversky Loss: 可调节的Precision/Recall平衡
    
    原理: 通过alpha和beta参数控制对False Positive和False Negative的惩罚
    适用: 需要精确控制Precision和Recall平衡的情况
    
    Args:
        alpha: False Positive的权重（越大越关注Precision）
        beta: False Negative的权重（越大越关注Recall）
        smooth: 平滑系数
    """
    def __init__(self, alpha=0.7, beta=0.3, smooth=1.0):
        super(TverskyLoss, self).__init__()
        self.alpha = alpha  # FP权重（越大越关注Precision）
        self.beta = beta    # FN权重（越大越关注Recall）
        self.smooth = smooth
    
    def forward(self, logits, targets):
        """
        Args:
            logits: [B, num_classes] 分类logits
            targets: [B] 类别标签
        """
        num_classes = logits.size(1)
        probs = F.softmax(logits, dim=1)
        targets_one_hot = F.one_hot(targets, num_classes).float()
        
        tversky_scores = []
        for c in range(num_classes):
            pred_c = probs[:, c]
            target_c = targets_one_hot[:, c]
            
            true_pos = (pred_c * target_c).sum()
            false_pos = (pred_c * (1 - target_c)).sum()
            false_neg = ((1 - pred_c) * target_c).sum()
            
            tversky = (true_pos + self.smooth) / (
                true_pos + self.alpha * false_pos + self.beta * false_neg + self.smooth
            )
            tversky_scores.append(tversky)
        
        return 1.0 - torch.stack(tversky_scores).mean()


class AdaptiveTverskyLoss(nn.Module):
    """
    自适应Tversky Loss：根据类别动态调整alpha参数
    
    原理：
    - feeding需要更高的alpha（更关注Precision，减少FP）
    - walking/brushing需要更低的alpha（更关注Recall，减少FN）
    - 其他类别使用平衡的alpha
    
    Args:
        base_alpha: 基础alpha值（用于没有特定设置的类别）
        smooth: 平滑系数
        class_alpha_dict: 类别特定的alpha字典，例如 {0: 0.6, 2: 0.85, 5: 0.6}
    """
    def __init__(self, base_alpha=0.7, smooth=1.0, class_alpha_dict=None):
        super(AdaptiveTverskyLoss, self).__init__()
        self.base_alpha = base_alpha
        self.smooth = smooth
        
        # 类别特定的alpha设置
        # 默认设置：根据当前问题优化
        if class_alpha_dict is None:
            # brushing(0): 需要提升Recall → alpha=0.6
            # walking(5): 需要提升Recall → alpha=0.6
            # feeding(2): 需要提升Precision → alpha=0.85
            # 其他: 平衡 → alpha=0.7
            self.class_alpha = {
                0: 0.6,  # brushing: 更关注Recall
                1: 0.7,  # drinking: 平衡
                2: 0.85, # feeding: 更关注Precision
                3: 0.7,  # fighting: 平衡
                4: 0.65, # standing: 稍微关注Recall
                5: 0.6,  # walking: 更关注Recall
            }
        else:
            self.class_alpha = class_alpha_dict
    
    def forward(self, logits, targets):
        num_classes = logits.size(1)
        probs = F.softmax(logits, dim=1)
        targets_one_hot = F.one_hot(targets, num_classes).float()
        
        tversky_scores = []
        for c in range(num_classes):
            pred_c = probs[:, c]
            target_c = targets_one_hot[:, c]
            
            true_pos = (pred_c * target_c).sum()
            false_pos = (pred_c * (1 - target_c)).sum()
            false_neg = ((1 - pred_c) * target_c).sum()
            
            # 根据类别使用不同的alpha
            alpha = self.class_alpha.get(c, self.base_alpha)
            beta = 1.0 - alpha
            
            tversky = (true_pos + self.smooth) / (
                true_pos + alpha * false_pos + beta * false_neg + self.smooth
            )
            tversky_scores.append(tversky)
        
        return 1.0 - torch.stack(tversky_scores).mean()


class CombinedLoss(nn.Module):
    """
    组合损失函数：Focal Loss + Dice Loss / Tversky Loss
    
    设计思路:
    1. Focal Loss: 关注难分样本，提升整体性能
    2. Dice/Tversky Loss: 直接优化Precision，解决drinking等类别的Precision偏低问题
    
    Args:
        alpha: Focal Loss的类别权重
        gamma: Focal Loss的聚焦参数
        lambda_dice: Dice Loss的权重（推荐0.1-0.3）
        use_tversky: 是否使用Tversky Loss替代Dice Loss
        tversky_alpha: Tversky Loss的alpha参数（越大越关注Precision）
        label_smoothing: 标签平滑系数
    """
    def __init__(
        self,
        alpha=None,
        gamma=2.0,
        lambda_dice=0.15,
        use_tversky=False,
        tversky_alpha=0.7,
        label_smoothing=0.1,
    ):
        super(CombinedLoss, self).__init__()
        self.lambda_dice = lambda_dice
        self.use_tversky = use_tversky
        
        # Focal Loss
        self.focal_loss = FocalLoss(alpha=alpha, gamma=gamma, label_smoothing=label_smoothing)
        
        # Dice Loss 或 Tversky Loss
        if use_tversky:
            self.dice_loss = TverskyLoss(alpha=tversky_alpha, beta=1.0 - tversky_alpha)
        else:
            self.dice_loss = DiceLoss(smooth=1.0)
    
    def forward(self, logits, labels):
        """
        Args:
            logits: [B, num_classes] 分类logits
            labels: [B] 类别标签
        Returns:
            total_loss: 总损失
            loss_dict: 各损失分量的字典
        """
        # Focal Loss
        focal = self.focal_loss(logits, labels)
        
        # Dice/Tversky Loss
        dice = self.dice_loss(logits, labels)
        
        # 组合损失
        total_loss = focal + self.lambda_dice * dice
        
        loss_dict = {
            'focal': focal.item(),
            'dice': dice.item(),
            'total': total_loss.item()
        }
        
        return total_loss, loss_dict


class AdaptiveFocalLoss(nn.Module):
    """
    自适应Focal Loss: 根据类别难度动态调整gamma
    
    原理: 对难分类别使用更大的gamma，对易分类别使用较小的gamma
    适用: 不同类别难度差异大的情况
    """
    def __init__(self, alpha=None, base_gamma=2.0, label_smoothing=0.0):
        super(AdaptiveFocalLoss, self).__init__()
        self.alpha = alpha
        self.base_gamma = base_gamma
        self.label_smoothing = label_smoothing
        
        if isinstance(alpha, (float, int)):
            self.alpha = torch.tensor([alpha, 1 - alpha])
        elif isinstance(alpha, (list, np.ndarray)):
            self.alpha = torch.tensor(alpha)
        elif isinstance(alpha, torch.Tensor):
            self.alpha = alpha
    
    def forward(self, inputs, targets):
        ce_loss = F.cross_entropy(inputs, targets, reduction='none', label_smoothing=self.label_smoothing)
        pt = torch.exp(-ce_loss)
        
        # 根据pt动态调整gamma：难分样本(pt小)使用更大的gamma
        gamma = self.base_gamma * (1 - pt)  # 难分样本gamma更大
        
        if self.alpha is not None:
            if self.alpha.device != inputs.device:
                self.alpha = self.alpha.to(inputs.device)
            alpha_t = self.alpha[targets] if len(self.alpha.shape) == 1 else self.alpha
            focal_loss = alpha_t * (1 - pt) ** gamma * ce_loss
        else:
            focal_loss = (1 - pt) ** gamma * ce_loss
        
        return focal_loss.mean()


class CETverskyLoss(nn.Module):
    """
    CrossEntropy + Tversky 组合损失函数
    
    设计思路:
    1. CrossEntropy Loss: 作为基础损失，保证训练稳定性和基础性能
    2. Tversky Loss: 精确控制Precision/Recall平衡，解决特定类别的P/R问题
    
    适用场景:
    - 样本平衡（不需要Focal Loss的类别不平衡处理）
    - 需要精确控制Precision/Recall平衡
    - 训练稳定性要求高
    
    优势:
    - 比Focal+Tversky更简单（不需要调gamma）
    - 比Focal+Tversky更稳定（CE Loss更稳定）
    - 比Focal+Tversky更高效（计算更快）
    - 仍然可以精确控制P/R平衡（通过Tversky）
    
    Args:
        lambda_tversky: Tversky Loss的权重（推荐0.1-0.3）
        tversky_alpha: Tversky Loss的alpha参数（越大越关注Precision）
        tversky_beta: Tversky Loss的beta参数（越大越关注Recall，通常=1-alpha）
        label_smoothing: 标签平滑系数（用于CE Loss）
        weight: 类别权重（用于CE Loss，可选）
    """
    def __init__(
        self,
        lambda_tversky=0.2,
        tversky_alpha=0.7,
        tversky_beta=None,
        label_smoothing=0.1,
        weight=None,
        smooth=1.0,
    ):
        super(CETverskyLoss, self).__init__()
        self.lambda_tversky = lambda_tversky
        self.label_smoothing = label_smoothing
        self.weight = weight
        
        # 如果未指定beta，使用1-alpha
        if tversky_beta is None:
            tversky_beta = 1.0 - tversky_alpha
        
        # CrossEntropy Loss
        self.ce_loss = nn.CrossEntropyLoss(
            weight=weight,
            label_smoothing=label_smoothing,
            reduction='mean'
        )
        
        # Tversky Loss
        self.tversky_loss = TverskyLoss(
            alpha=tversky_alpha,
            beta=tversky_beta,
            smooth=smooth
        )
    
    def forward(self, logits, labels):
        """
        Args:
            logits: [B, num_classes] 分类logits
            labels: [B] 类别标签
        Returns:
            total_loss: 总损失
            loss_dict: 各损失分量的字典
        """
        # CrossEntropy Loss
        ce = self.ce_loss(logits, labels)
        
        # Tversky Loss
        tversky = self.tversky_loss(logits, labels)
        
        # 组合损失
        total_loss = ce + self.lambda_tversky * tversky
        
        loss_dict = {
            'ce': ce.item(),
            'tversky': tversky.item(),
            'total': total_loss.item()
        }
        
        return total_loss, loss_dict


class CEAdaptiveTverskyLoss(nn.Module):
    """
    CrossEntropy + 自适应Tversky 组合损失函数
    
    设计思路:
    1. CrossEntropy Loss: 作为基础损失，保证训练稳定性和基础性能
    2. Adaptive Tversky Loss: 根据类别动态调整alpha，精确控制每个类别的Precision/Recall平衡
    
    适用场景:
    - 样本平衡（不需要Focal Loss的类别不平衡处理）
    - 不同类别需要不同的Precision/Recall优化策略
    - 训练稳定性要求高
    
    优势:
    - 比固定Tversky更灵活（每个类别可以有不同的alpha）
    - 比Focal+Tversky更简单（不需要调gamma）
    - 比Focal+Tversky更稳定（CE Loss更稳定）
    - 可以针对性地解决不同类别的问题
    
    Args:
        lambda_tversky: Tversky Loss的权重（推荐0.1-0.3）
        base_alpha: 基础alpha值（用于没有特定设置的类别）
        class_alpha_dict: 类别特定的alpha字典
        label_smoothing: 标签平滑系数（用于CE Loss）
        weight: 类别权重（用于CE Loss，可选）
    """
    def __init__(
        self,
        lambda_tversky=0.2,
        base_alpha=0.7,
        class_alpha_dict=None,
        label_smoothing=0.1,
        weight=None,
        smooth=1.0,
    ):
        super(CEAdaptiveTverskyLoss, self).__init__()
        self.lambda_tversky = lambda_tversky
        self.label_smoothing = label_smoothing
        self.weight = weight
        
        # CrossEntropy Loss
        self.ce_loss = nn.CrossEntropyLoss(
            weight=weight,
            label_smoothing=label_smoothing,
            reduction='mean'
        )
        
        # 自适应Tversky Loss
        self.adaptive_tversky_loss = AdaptiveTverskyLoss(
            base_alpha=base_alpha,
            smooth=smooth,
            class_alpha_dict=class_alpha_dict
        )
    
    def forward(self, logits, labels):
        """
        Args:
            logits: [B, num_classes] 分类logits
            labels: [B] 类别标签
        Returns:
            total_loss: 总损失
            loss_dict: 各损失分量的字典
        """
        # CrossEntropy Loss
        ce = self.ce_loss(logits, labels)
        
        # 自适应Tversky Loss
        adaptive_tversky = self.adaptive_tversky_loss(logits, labels)
        
        # 组合损失
        total_loss = ce + self.lambda_tversky * adaptive_tversky
        
        loss_dict = {
            'ce': ce.item(),
            'adaptive_tversky': adaptive_tversky.item(),
            'total': total_loss.item()
        }
        
        return total_loss, loss_dict

