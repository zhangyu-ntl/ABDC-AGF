"""
CE + Adaptive Tversky with dynamic λ_ATV.

  λ̃(t) = λ_min + (λ_max - λ_min) * σ( (L̄_ATV - L̄_CE) / τ )
  λ_ATV(t) = clip(λ̃(t), λ_min, λ_max)

Defaults: λ_min=0.3, λ_max=0.7, τ=1.0, EMA momentum=0.9.
This release supports dynamic λ only.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from improved_losses import AdaptiveTverskyLoss


class CEAdaptiveTverskyDynamicLambdaLoss(nn.Module):
    """CrossEntropy + AdaptiveTversky with dynamic λ_ATV."""

    def __init__(
        self,
        lambda_mode: str = "dynamic",
        lambda_tversky: float = 0.5,
        lambda_min: float = 0.3,
        lambda_max: float = 0.7,
        tau: float = 1.0,
        ema_momentum: float = 0.9,
        base_alpha: float = 0.7,
        class_alpha_dict=None,
        label_smoothing: float = 0.1,
        weight=None,
        smooth: float = 1.0,
    ):
        super().__init__()
        if lambda_mode != "dynamic":
            raise ValueError("This release uses dynamic λ_ATV only; got lambda_mode=%r" % (lambda_mode,))
        if lambda_min >= lambda_max:
            raise ValueError(f"require lambda_min < lambda_max, got {lambda_min} >= {lambda_max}")

        self.lambda_mode = "dynamic"
        self.lambda_tversky = float(lambda_tversky)
        self.lambda_min = float(lambda_min)
        self.lambda_max = float(lambda_max)
        self.tau = float(max(tau, 1e-6))
        self.ema_momentum = float(ema_momentum)

        self.register_buffer("ema_ce", torch.tensor(0.0))
        self.register_buffer("ema_atv", torch.tensor(0.0))
        self.register_buffer("ema_initialized", torch.tensor(False))
        self.register_buffer("current_lambda", torch.tensor(self.lambda_tversky))

        self.ce_loss = nn.CrossEntropyLoss(
            weight=weight,
            label_smoothing=label_smoothing,
            reduction="mean",
        )
        self.adaptive_tversky_loss = AdaptiveTverskyLoss(
            base_alpha=base_alpha,
            smooth=smooth,
            class_alpha_dict=class_alpha_dict,
        )

    def _update_ema(self, ce_val: torch.Tensor, atv_val: torch.Tensor):
        if not bool(self.ema_initialized.item()):
            self.ema_ce.copy_(ce_val.detach())
            self.ema_atv.copy_(atv_val.detach())
            self.ema_initialized.fill_(True)
        else:
            m = self.ema_momentum
            self.ema_ce.mul_(m).add_(ce_val.detach(), alpha=1.0 - m)
            self.ema_atv.mul_(m).add_(atv_val.detach(), alpha=1.0 - m)

    def _compute_dynamic_lambda(self) -> torch.Tensor:
        diff = (self.ema_atv - self.ema_ce) / self.tau
        gate = torch.sigmoid(diff)
        lam = self.lambda_min + (self.lambda_max - self.lambda_min) * gate
        return torch.clamp(lam, self.lambda_min, self.lambda_max)

    def forward(self, logits, labels):
        ce = self.ce_loss(logits, labels)
        adaptive_tversky = self.adaptive_tversky_loss(logits, labels)

        if self.training:
            self._update_ema(ce, adaptive_tversky)
        if not bool(self.ema_initialized.item()):
            lam = torch.as_tensor(
                0.5 * (self.lambda_min + self.lambda_max),
                device=logits.device,
                dtype=ce.dtype,
            )
        else:
            lam = self._compute_dynamic_lambda().to(dtype=ce.dtype)
        self.current_lambda.copy_(lam.detach())

        total_loss = ce + lam * adaptive_tversky
        loss_dict = {
            "ce": float(ce.detach().item()),
            "adaptive_tversky": float(adaptive_tversky.detach().item()),
            "lambda_atv": float(lam.detach().item()),
            "ema_ce": float(self.ema_ce.detach().item()),
            "ema_atv": float(self.ema_atv.detach().item()),
            "total": float(total_loss.detach().item()),
        }
        return total_loss, loss_dict
