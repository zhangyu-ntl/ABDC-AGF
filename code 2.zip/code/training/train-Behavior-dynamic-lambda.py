# VitaCLIP training with dynamic lambda_ATV
# CE + Adaptive Tversky，λ ∈ [0.3, 0.7] 按 EMA(L_ATV - L_CE) 动态更新；也支持固定 λ 消融
# !/usr/bin/env python
import sys, os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# CUDA_VISIBLE_DEVICES 可以通过命令行参数或环境变量设置
# 如果未设置，默认使用所有可用GPU
# 注意：如果通过命令行参数 --gpus 指定，会在main函数中设置
sys.path.append('/')
import torch
import argparse
from datetime import datetime
from torch.cuda.amp import GradScaler
import builtins
import checkpoint
from BehaviorCLIP_model import VitaCLIP
from video_dataset.dataloader import create_train_loader, create_val_loader
from sklearn.metrics import accuracy_score, precision_score, recall_score, roc_auc_score, f1_score, confusion_matrix, \
    classification_report
from sklearn.utils.class_weight import compute_class_weight
from collections import Counter
from improved_losses_dynamic_lambda import CEAdaptiveTverskyDynamicLambdaLoss

ID2NAME = ['brushing', 'drinking', 'feeding', 'fighting', 'standing', 'walking']  # 6 类
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np


# ---------- 打印时间戳 ----------
def setup_print():
    builtin_print = builtins.print

    def print(*args, **kwargs):
        now = datetime.now().time()
        builtin_print(f"[{now}] ", end="")
        builtin_print(*args, **kwargs)

    builtins.print = print


# ---------- 工具：逐类别指标 ----------
def compute_metrics(logits, labels, num_classes):
    preds = logits.argmax(dim=1).cpu().numpy()
    labels_np = labels.cpu().numpy()
    probs = torch.softmax(logits, dim=1).cpu().numpy()

    # 宏观指标
    metrics = {
        'top1': accuracy_score(labels_np, preds) * 100,
        'prec_macro': precision_score(labels_np, preds, average='macro', zero_division=0) * 100,
        'rec_macro': recall_score(labels_np, preds, average='macro', zero_division=0) * 100,
        'f1_macro': f1_score(labels_np, preds, average='macro', zero_division=0) * 100,
    }

    report = classification_report(
        labels_np, preds,
        labels=list(range(num_classes)),
        target_names=[f'class_{i}' for i in range(num_classes)],
        output_dict=True,
        zero_division=0
    )

    try:
        if num_classes == 2:
            auc = roc_auc_score(labels_np, probs[:, 1])
            auc_per_class = None
        else:
            auc = roc_auc_score(labels_np, probs, multi_class='ovr')
            auc_per_class = roc_auc_score(labels_np, probs, multi_class='ovr', average=None)
    except ValueError:
        auc = float('nan')
        auc_per_class = [float('nan')] * num_classes

    metrics['auc_macro'] = auc
    return metrics, report, auc_per_class


# ---------- 计算类别权重 ----------
def compute_class_weights(train_list_path, num_classes=6):
    """
    从训练数据列表中计算类别权重
    返回: torch.Tensor [num_classes] 类别权重
    """
    labels = []
    with open(train_list_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(',')
            if len(parts) >= 3:
                label = int(parts[2]) - 1  # 把 1-6 映射成 0-5
                if 0 <= label < num_classes:
                    labels.append(label)
    
    if len(labels) == 0:
        print("[WARN] 无法从训练列表计算类别权重，使用均匀权重")
        return torch.ones(num_classes).float()
    
    # 计算类别分布
    class_counts = Counter(labels)
    print(f"\n[INFO] 训练集类别分布:")
    for i in range(num_classes):
        count = class_counts.get(i, 0)
        print(f"  {ID2NAME[i]}: {count} 个样本")
    
    # 使用sklearn计算平衡权重
    class_weights = compute_class_weight(
        'balanced',
        classes=np.arange(num_classes),
        y=np.array(labels)
    )
    
    print(f"\n[INFO] 计算的类别权重:")
    for i in range(num_classes):
        print(f"  {ID2NAME[i]}: {class_weights[i]:.4f}")
    
    return torch.FloatTensor(class_weights)


# ---------- 主函数 ----------
def main():
    parser = argparse.ArgumentParser(description="BehaviorCLIP training (classification)")
    # 基础参数（略）
    parser.add_argument("--num_classes", type=int, default=6)
    parser.add_argument('--batch_split', type=int, default=1, help='gradient accumulation splits')
    parser.add_argument("--checkpoint_dir", type=str)
    parser.add_argument("--auto_resume", action="store_true")
    parser.add_argument("--resume_path", type=str)
    parser.add_argument("--pretrain", type=str, default=None,
                        help="path to pretrained weights. will NOT override auto_resume or resume_path, "
                             "load optimizer state or enforce strict matching of checkpoint and model weights.")
    parser.add_argument("--num_steps", type=int)
    parser.add_argument("--eval_only", action="store_true")
    parser.add_argument(
        "--prune_amount",
        type=float,
        default=0.0,
        help="加载权重后对 Linear/Conv2d 做全局 L1 剪枝比例，例如 0.5 表示剪掉 50%；微调时保留 mask",
    )
    parser.add_argument("--save_freq", type=int)
    parser.add_argument("--eval_freq", type=int)
    parser.add_argument("--print_freq", type=int)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--weight_decay", type=float, default=0.05)
    parser.add_argument("--warmup_steps", type=int, default=1000, help="学习率warmup步数")
    parser.add_argument("--grad_clip", type=float, default=1.0, help="梯度裁剪阈值")
    parser.add_argument("--label_smoothing", type=float, default=0.1, help="标签平滑系数")
    
    # ===== 损失函数参数（本脚本专注 CE+ATV + 动态/固定 λ）=====
    parser.add_argument(
        "--loss_type",
        type=str,
        default="ce_adaptive_tversky_dynamic",
        choices=["ce_adaptive_tversky_dynamic"],
        help="本脚本仅支持 CE + AdaptiveTversky（动态/固定 λ_ATV）",
    )
    parser.add_argument(
        "--lambda_mode",
        type=str,
        default="dynamic",
        choices=["dynamic"],
        help="dynamic λ_ATV only (EMA + sigmoid, clipped to [lambda_min, lambda_max])",
    )
    parser.add_argument(
        "--lambda_tversky",
        type=float,
        default=0.5,
        help="固定模式下的 λ_ATV（消融可用 0.3/0.5/0.7）",
    )
    parser.add_argument("--lambda_min", type=float, default=0.3, help="动态 λ_ATV 下界")
    parser.add_argument("--lambda_max", type=float, default=0.7, help="动态 λ_ATV 上界")
    parser.add_argument("--lambda_tau", type=float, default=1.0, help="动态 λ 的温度 τ")
    parser.add_argument("--lambda_ema", type=float, default=0.9, help="CE/ATV EMA 动量")
    parser.add_argument("--focal_gamma", type=float, default=2.0, help="兼容旧参数，本脚本未使用")
    parser.add_argument("--lambda_dice", type=float, default=0.15, help="兼容旧参数，本脚本未使用")
    parser.add_argument("--use_tversky", action="store_true", help="兼容旧参数，本脚本未使用")
    parser.add_argument(
        "--tversky_alpha",
        type=float,
        default=0.7,
        help="AdaptiveTversky 的 base_alpha（越大越关注Precision）",
    )
    
    # ===== 多GPU训练参数 =====
    parser.add_argument("--gpus", type=str, default=None,
                        help="使用的GPU ID，例如 '0,1' 表示使用GPU 0和1。如果不指定，使用所有可用GPU")
    parser.add_argument("--use_ddp", action="store_true",
                        help="使用DistributedDataParallel（需要多进程启动）。如果为False，使用DataParallel")
    parser.add_argument("--use_tta", action="store_true", help="使用测试时增强（TTA）")
    parser.add_argument("--tta_num_augments", type=int, default=5, help="TTA增强次数")
    parser.add_argument("--use_temperature_scaling", action="store_true", help="使用温度缩放")
    parser.add_argument("--temperature", type=float, default=1.5, help="温度缩放参数")
    parser.add_argument("--batch_size", type=int)
    parser.add_argument("--train_list_path", type=str)
    parser.add_argument("--val_list_path", type=str)
    parser.add_argument("--train_data_root", type=str)
    parser.add_argument("--val_data_root", type=str)
    parser.add_argument("--accel_train_dir", type=str)
    parser.add_argument("--accel_val_dir", type=str)
    parser.add_argument("--accel_dim", type=int, default=9)
    parser.add_argument("--sampling_rate", type=int, default=16)
    parser.add_argument(
        "--frame_sampling_strategy",
        type=str,
        default="default",
        choices=["default", "sparse"],
        help="default=128帧; sparse=TSN稀疏时序采样(num_frames帧)",
    )
    parser.add_argument("--spatial_size", type=int, default=224)
    parser.add_argument("--num_workers", type=int, default=8)
    parser.add_argument("--auto_augment", type=str, default="rand-m7-n4-mstd0.5-inc1")
    parser.add_argument("--interpolation", type=str, default="bicubic")
    parser.add_argument("--mirror", action="store_false", dest="mirror")
    parser.add_argument("--num_frames", type=int, default=8)
    parser.add_argument("--accel_num_layers", type=int, default=6)
    parser.add_argument("--accel_d_model", type=int, default=768)
    parser.add_argument("--accel_nhead", type=int, default=8)
    parser.add_argument("--accel_dim_feedforward", type=int, default=2048)
    parser.add_argument("--accel_dropout", type=float, default=0.1)
    parser.add_argument('--use_summary_token', action='store_true')
    parser.add_argument('--use_local_prompts', action='store_true')
    parser.add_argument('--use_global_prompts', action='store_true')
    parser.add_argument('--num_global_prompts', type=int, default=4)
    parser.add_argument('--mean', type=float, nargs='+', default=[0.485, 0.456, 0.406])
    parser.add_argument('--std', type=float, nargs='+', default=[0.229, 0.224, 0.225])
    parser.add_argument('--use_distill', action='store_true')
    parser.add_argument(
        "--video_encoder_type",
        type=str,
        default="clip",
        choices=["clip", "slowfast", "videomae"],
        help="视频编码器类型: clip(默认), slowfast, videomae",
    )
    parser.add_argument("--seed", type=int, default=None, help="随机种子")
    parser.add_argument(
        "--video_only",
        action="store_true",
        help="仅使用视频模态训练/评估，不使用传感器融合",
    )

    # ===== 视频 5 开关 =====
    parser.add_argument("--use_dynamic_sample", action="store_true")
    parser.add_argument("--use_keyframe", action="store_true")
    parser.add_argument("--use_spatial", action="store_true")
    parser.add_argument("--use_temporal", action="store_true")
    parser.add_argument("--use_pyramid", action="store_true")
    
    # ===== 双路径时空注意力（替代use_spatial和use_temporal） =====
    parser.add_argument("--use_dual_path_attention", action="store_true", 
                       help="使用双路径时空注意力（替代独立的时序和空间注意力）")
    parser.add_argument("--dual_path_fusion_method", type=str, default='gate',
                       choices=['gate', 'add', 'concat'],
                       help="双路径融合方法：gate(门控), add(相加), concat(拼接)")

    # ===== 加速度 3 开关 =====
    parser.add_argument("--use_context", action="store_true")
    parser.add_argument("--use_accel_self_attn", action="store_true")
    parser.add_argument("--accel_augment", action="store_true")

    # ===== 融合 2 开关 =====
    parser.add_argument("--use_cross_attn", action="store_true")
    parser.add_argument("--use_gate", action="store_true")
    
    # ===== 对比学习开关 =====
    parser.add_argument("--use_contrastive_learning", action="store_true",
                        help="是否使用时间-位置对比学习")
    parser.add_argument("--contrastive_temperature", type=float, default=0.07,
                        help="对比学习温度参数（默认0.07）")
    parser.add_argument("--contrastive_time_window", type=int, default=2,
                        help="时间对比的正样本窗口大小（默认2）")
    parser.add_argument("--contrastive_spatial_window", type=int, default=3,
                        help="位置对比的正样本窗口大小（默认3）")
    parser.add_argument("--use_temporal_contrast", action="store_true", default=True,
                        help="是否使用时间对比（默认True）")
    parser.add_argument("--use_positional_contrast", action="store_true", default=True,
                        help="是否使用位置对比（默认True）")
    parser.add_argument("--contrastive_loss_weight", type=float, default=0.1,
                        help="对比学习损失权重（默认0.1）")

    # ===== 扰动实验参数 =====
    parser.add_argument(
        "--perturb_type",
        type=str,
        default=None,
        choices=['video_occlusion', 'low_light', 'imu_noise', 'imu_drift', 'time_misalign'],
        help="扰动类型: video_occlusion=视频遮挡, low_light=低光照, imu_noise=IMU高斯噪声, "
             "imu_drift=IMU漂移, time_misalign=时间错位",
    )
    parser.add_argument(
        "--perturb_value",
        type=float,
        default=None,
        help="扰动强度: 遮挡比例(0.2/0.3/0.5), gamma(0.5/0.7), 噪声σ(0.05/0.1/0.2), "
             "漂移率(0.05), 帧偏移(±1/±3/±5)",
    )

    args = parser.parse_args()
    args.lambda_mode = "dynamic"
    args.loss_type = "ce_adaptive_tversky_dynamic"
    if args.seed is not None:
        import random
        random.seed(args.seed)
        np.random.seed(args.seed)
        torch.manual_seed(args.seed)
        torch.cuda.manual_seed_all(args.seed)
        print(f"[INFO] seed={args.seed}")
    setup_print()

    if args.perturb_type is not None:
        print(f"[INFO] 扰动实验: type={args.perturb_type}, value={args.perturb_value}")

    if args.video_encoder_type != "clip":
        args.use_dynamic_sample = False
        args.use_keyframe = False
        args.use_spatial = False
        args.use_temporal = False
        args.use_pyramid = False
        args.use_dual_path_attention = False
        args.use_contrastive_learning = False
        print(f"[INFO] baseline 编码器 {args.video_encoder_type}: 已关闭 CLIP 自定义视频模块")

    if args.frame_sampling_strategy == "sparse":
        args.use_dynamic_sample = False
        args.use_keyframe = False
        print("[INFO] sparse temporal sampling: 已关闭 use_dynamic_sample / use_keyframe")

    if args.video_only:
        print("[INFO] 视频单模态模式: 不使用传感器融合")
    
    # ===== 设置GPU =====
    if args.gpus is not None:
        os.environ['CUDA_VISIBLE_DEVICES'] = args.gpus
        print(f"[INFO] 使用GPU: {args.gpus}")
    else:
        # 如果没有指定，使用所有可用GPU
        num_gpus = torch.cuda.device_count()
        if num_gpus > 1:
            print(f"[INFO] 检测到 {num_gpus} 个GPU，将使用所有GPU进行训练")
        else:
            print(f"[INFO] 使用GPU: {torch.cuda.current_device()}")

    model = VitaCLIP(
        num_frames=args.num_frames,
        accel_dim=args.accel_dim,
        accel_d_model=args.accel_d_model,
        accel_nhead=args.accel_nhead,
        accel_num_layers=args.accel_num_layers,
        accel_dim_feedforward=args.accel_dim_feedforward,
        accel_dropout=args.accel_dropout,
        num_classes=args.num_classes,
        video_encoder_type=args.video_encoder_type,
        video_only=args.video_only,
        # 全部开关
        use_dynamic_sample=args.use_dynamic_sample,
        use_keyframe=args.use_keyframe,
        use_spatial=args.use_spatial,
        use_temporal=args.use_temporal,
        use_pyramid=args.use_pyramid,
        use_dual_path_attention=args.use_dual_path_attention,
        dual_path_fusion_method=args.dual_path_fusion_method,
        use_context=args.use_context,
        use_accel_self_attn=args.use_accel_self_attn,
        use_cross_attn=args.use_cross_attn,
        use_gate=args.use_gate,
        # 对比学习参数
        use_contrastive_learning=args.use_contrastive_learning,
        contrastive_temperature=args.contrastive_temperature,
        contrastive_time_window=args.contrastive_time_window,
        contrastive_spatial_window=args.contrastive_spatial_window,
        use_temporal_contrast=args.use_temporal_contrast,
        use_positional_contrast=args.use_positional_contrast,
        contrastive_loss_weight=args.contrastive_loss_weight,
    )
    
    # ===== 多GPU支持 =====
    num_gpus = torch.cuda.device_count()
    if num_gpus > 1 and not args.use_ddp:
        print(f"[INFO] 使用 DataParallel 在 {num_gpus} 个GPU上训练")
        model = torch.nn.DataParallel(model)
        model = model.cuda()
    else:
        model = model.cuda()
    
    # 如果是主模型（非DataParallel包装），保存原始模型引用用于保存检查点
    if isinstance(model, torch.nn.DataParallel):
        model_without_dp = model.module
    else:
        model_without_dp = model

    loss_scaler = GradScaler()
    # 降低学习率以稳定训练（从1e-4降到5e-5）
    adjusted_lr = args.lr if args.lr < 1e-4 else 5e-5
    if adjusted_lr != args.lr:
        print(f"[INFO] 学习率从 {args.lr} 调整为 {adjusted_lr} 以稳定训练")
    optimizer = torch.optim.AdamW(model.parameters(), lr=adjusted_lr, weight_decay=args.weight_decay)
    
    # 使用带warmup的学习率调度器（更保守的策略）
    warmup_steps = args.warmup_steps
    def lr_lambda(step):
        # step是全局步数（包括resume_step）
        if step < warmup_steps:
            # Warmup阶段：使用平方根增长（比线性更保守）
            # 这样可以更平滑地增长学习率
            warmup_ratio = step / warmup_steps
            return max(np.sqrt(warmup_ratio), 0.01)  # 平方根增长，最小学习率为初始的1%
        else:
            # Cosine退火阶段：更保守的衰减
            progress = (step - warmup_steps) / max(args.num_steps - warmup_steps, 1)
            # 使用更平滑的cosine衰减，保留更多学习率
            cosine_factor = 0.5 * (1 + np.cos(np.pi * progress))
            return max(0.1 + 0.9 * cosine_factor, 0.01)  # 最小学习率为初始的10%（而不是1%）
    
    lr_sched = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
    print(f"[INFO] 使用Warmup+Cosine学习率调度 (warmup={warmup_steps}步)")
    
    # 计算类别权重
    class_weights = compute_class_weights(args.train_list_path, args.num_classes)
    class_weights = class_weights.cuda()
    
    # 类别特定 alpha（与原 CEAdaptiveTversky 保持一致）
    class_alpha_dict = {
        0: 0.6,   # brushing: Recall
        1: 0.7,   # drinking: 平衡
        2: 0.85,  # feeding: Precision
        3: 0.7,   # fighting: 平衡
        4: 0.65,  # standing: 稍偏 Recall
        5: 0.6,   # walking: Recall
    }
    criterion = CEAdaptiveTverskyDynamicLambdaLoss(
        lambda_mode=args.lambda_mode,
        lambda_tversky=args.lambda_tversky,
        lambda_min=args.lambda_min,
        lambda_max=args.lambda_max,
        tau=args.lambda_tau,
        ema_momentum=args.lambda_ema,
        base_alpha=args.tversky_alpha,
        class_alpha_dict=class_alpha_dict,
        label_smoothing=args.label_smoothing,
        weight=class_weights,
    )
    print("[INFO] CrossEntropy + AdaptiveTversky with dynamic λ_ATV")
    print(f"  lambda_mode = {args.lambda_mode}")
    print(f"  dynamic λ_ATV ∈ [{args.lambda_min}, {args.lambda_max}], tau={args.lambda_tau}, ema={args.lambda_ema}")
    print("  update: λ = clip(λ_min + (λ_max-λ_min)*σ((EMA_ATV-EMA_CE)/τ), λ_min, λ_max)")
    print("  class-wise alpha: brushing/walking=0.6, standing=0.65, feeding=0.85, others=0.7")

    criterion = criterion.cuda()

    # resume_step = 0
    val_loader = create_val_loader(args)
    # ===== 打印加载状态 =====
    resume_step = checkpoint.resume_from_checkpoint(model_without_dp, optimizer, lr_sched, loss_scaler, args)
    print(f"[MAIN] resume_step = {resume_step}")  # > 0 表示已加载
    print("[MAIN] eval_only =", args.eval_only)  # 应该是 False
    if resume_step > 0:
        print(f"[INFO] ✅ 成功从检查点恢复训练 (Step {resume_step})")
    elif args.pretrain is not None:
        print(f"[INFO] ✅ 成功加载预训练模型: {args.pretrain}")
        print("[INFO] 开始新的训练（优化器和学习率调度器已重新初始化）")
    else:
        print("[WARN] ⚠️  未加载任何权重，模型为随机初始化！")

    if args.prune_amount and args.prune_amount > 0:
        from compress_utils import apply_magnitude_pruning
        prune_stats = apply_magnitude_pruning(
            model_without_dp,
            amount=args.prune_amount,
            make_permanent=False,
        )
        print(
            f"[INFO] 已应用幅值剪枝 amount={args.prune_amount:.2f}, "
            f"compress_sparsity={prune_stats['compress_sparsity']*100:.2f}%"
        )
        if not args.eval_only:
            optimizer = torch.optim.AdamW(model.parameters(), lr=adjusted_lr, weight_decay=args.weight_decay)
            lr_sched = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)
            print("[INFO] 剪枝后已重建 optimizer / lr_sched，微调期间保持稀疏 mask")

    if args.eval_only:
        model.eval()
        evaluate(model, val_loader, args.num_classes, args)
        return

    train_loader = create_train_loader(args)

    # 跟踪最佳F1-score
    best_f1_score = 0.0
    best_f1_step = 0
    
    batch_st = datetime.now()
    for i, batch_data in enumerate(train_loader, resume_step):
        video, accel, labels = batch_data[:3]
        video, accel, labels = video.cuda(), accel.cuda(), labels.cuda().long()
        assert labels.max() < args.num_classes, 'label out of range!'
        data_ed = datetime.now()

        optimizer.zero_grad()
        accel_input = None if args.video_only else accel
        outputs = model(video, accel_input)
        
        # 计算损失（本脚本始终返回 loss_dict，含 lambda_atv）
        classification_loss, loss_dict = criterion(outputs["logits"], labels)
        
        # 添加对比学习损失
        total_loss = classification_loss
        if args.use_contrastive_learning and outputs.get("contrastive_loss") is not None:
            contrastive_loss = outputs["contrastive_loss"]
            total_loss = classification_loss + args.contrastive_loss_weight * contrastive_loss
            if outputs.get("contrastive_loss_dict"):
                loss_dict.update(outputs["contrastive_loss_dict"])
        
        loss = total_loss
        loss.backward()
        
        # 梯度裁剪
        if args.grad_clip > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
        
        optimizer.step()
        lr_sched.step()
        torch.cuda.empty_cache()

        with torch.no_grad():
            metrics, _, _ = compute_metrics(outputs["logits"], labels, args.num_classes)

        if i % args.print_freq == 0:
            current_lr = optimizer.param_groups[0]['lr']
            loss_str = f"loss={loss.item():.4f}"
            if loss_dict:
                loss_details = " ".join([f"{k}={v:.4f}" for k, v in loss_dict.items()])
                loss_str += f" ({loss_details})"
            print(f"[{i}] {loss_str} top1={metrics['top1']:.2f}% lr={current_lr:.2e}")

        if (i + 1) % args.save_freq == 0:
            checkpoint.save_checkpoint(model_without_dp, optimizer, lr_sched, loss_scaler, i + 1, args)
            print(f"Checkpoint saved at step {i + 1}")
        
        # ---------- 定期验证（只跑一遍验证集，避免原先 F1 扫描 + evaluate 双倍耗时）----------
        if (i + 1) % args.eval_freq == 0:
            print(f"\n[INFO] Running evaluation at step {i + 1}...")
            args.resume_step = i + 1
            model.eval()
            with torch.no_grad():
                all_logits, all_labels = [], []
                for val_batch in val_loader:
                    val_video, val_accel, val_labels = val_batch[:3]
                    val_video = val_video.cuda()
                    val_labels = val_labels.cuda().long()
                    val_accel_input = None if args.video_only else val_accel.cuda()
                    val_outputs = model(val_video, val_accel_input)
                    all_logits.append(val_outputs["logits"].cpu())
                    all_labels.append(val_labels.cpu())

                all_logits = torch.cat(all_logits, dim=0)
                all_labels = torch.cat(all_labels, dim=0)
                val_metrics, _, _ = compute_metrics(all_logits, all_labels, args.num_classes)
                current_f1 = val_metrics['f1_macro'] / 100.0

                print(
                    f"[EVAL][step={i + 1}] "
                    f"Acc={val_metrics['top1']:.2f}% "
                    f"P={val_metrics['prec_macro']:.2f}% "
                    f"R={val_metrics['rec_macro']:.2f}% "
                    f"F1={val_metrics['f1_macro']:.2f}%"
                )

                if current_f1 > best_f1_score:
                    best_f1_score = current_f1
                    best_f1_step = i + 1
                    best_model_path = os.path.join(args.checkpoint_dir, 'best_model.pth')
                    torch.save({
                        'step': i + 1,
                        'model_state_dict': model_without_dp.state_dict(),
                        'optimizer_state_dict': optimizer.state_dict(),
                        'lr_sched_state_dict': lr_sched.state_dict(),
                        'loss_scaler_state_dict': loss_scaler.state_dict(),
                        'best_f1_score': best_f1_score,
                        'f1_score': current_f1,
                        'accuracy': val_metrics['top1'] / 100.0,
                    }, best_model_path)
                    print(f"✅ 保存最佳模型 (F1={best_f1_score:.4f}, Step={best_f1_step})")
                else:
                    print(f"📊 当前F1={current_f1:.4f}, 最佳F1={best_f1_score:.4f} (Step={best_f1_step})")

            # 仅在最终 step 输出完整混淆矩阵/逐类报告，中间 eval 不再二次扫验证集
            if args.num_steps is not None and (i + 1) >= args.num_steps:
                evaluate(model, val_loader, args.num_classes, args)
            model.train()

        # 按 num_steps 硬截止，避免跑完整个 DataLoader。
        if args.num_steps is not None and (i + 1) >= args.num_steps:
            print(f"[INFO] Reached num_steps={args.num_steps}, stop training loop.")
            break

    print(
        f"[INFO] Training finished. best_f1={best_f1_score:.4f} @ step={best_f1_step}. "
        f"results: {args.checkpoint_dir}"
    )


# ======================  完整 evaluate 函数  ======================
def evaluate(model, loader, num_classes, args=None):
    model.eval()
    all_preds, all_labels, all_probs = [], [], []
    all_video_paths = []  # 新增：记录视频路径
    
    with torch.no_grad():
        for batch in loader:
            video, accel = batch[:2]
            labels = batch[2] if len(batch) >= 3 else torch.zeros(video.size(0), dtype=torch.long).cuda()
            video_paths = batch[3] if len(batch) >= 4 else [f'unknown_{i}' for i in range(video.size(0))]
            video = video.cuda()
            labels = labels.cuda()
            accel_input = None if (args is not None and getattr(args, 'video_only', False)) else accel.cuda()
            logits = model(video, accel_input)["logits"]
            probs = torch.softmax(logits, dim=1).cpu().numpy()

            # 强制 1-D → 列表（兼容 batch=1）
            all_preds.extend(logits.argmax(1).cpu().numpy().ravel().tolist())
            all_labels.extend(labels.cpu().numpy().ravel().tolist())
            all_video_paths.extend(video_paths)  # 新增：保存视频路径
            all_probs.append(probs)

    # 空保护
    if len(all_preds) == 0:
        print('[WARN] 验证集没有样本，跳过评估')
        return

    # 安全拼接
    all_preds = np.array(all_preds, dtype=int)
    all_labels = np.array(all_labels, dtype=int)
    all_probs = np.concatenate(all_probs, axis=0)  # (N, C)

    # ---------- 1.  Overall (Macro) 指标（永远有） ----------
    acc = accuracy_score(all_labels, all_preds)
    macro_prec = precision_score(all_labels, all_preds, average='macro', zero_division=0)
    macro_rec = recall_score(all_labels, all_preds, average='macro', zero_division=0)
    macro_f1 = f1_score(all_labels, all_preds, average='macro', zero_division=0)

    print("\n==========  Overall (Macro) Metrics  ==========")
    print(f"Accuracy  : {acc:.4f}")
    print(f"Precision : {macro_prec:.4f}")
    print(f"Recall    : {macro_rec:.4f}")
    print(f"F1-score  : {macro_f1:.4f}")

    # ---------- 2.  三平均（永远存在，不读 report 键） ----------
    micro_prec = precision_score(all_labels, all_preds, average='micro', zero_division=0)
    micro_rec = recall_score(all_labels, all_preds, average='micro', zero_division=0)
    micro_f1 = f1_score(all_labels, all_preds, average='micro', zero_division=0)

    weighted_prec = precision_score(all_labels, all_preds, average='weighted', zero_division=0)
    weighted_rec = recall_score(all_labels, all_preds, average='weighted', zero_division=0)
    weighted_f1 = f1_score(all_labels, all_preds, average='weighted', zero_division=0)

    print("\n==========  Average Metrics  ==========")
    print(f"{'micro avg':>15}  P={micro_prec:.4f}  R={micro_rec:.4f}  F1={micro_f1:.4f}")
    print(f"{'macro avg':>15}  P={macro_prec:.4f}  R={macro_rec:.4f}  F1={macro_f1:.4f}")
    print(f"{'weighted avg':>15}  P={weighted_prec:.4f}  R={weighted_rec:.4f}  F1={weighted_f1:.4f}")

    # ---------- 3.  逐类（只打印出现过的类，永不缺键） ----------
    uniq_labels = sorted(np.unique(np.concatenate([all_labels, all_preds])))
    present_names = [ID2NAME[i] for i in uniq_labels]

    report = classification_report(
        all_labels, all_preds,
        labels=uniq_labels,
        target_names=present_names,
        output_dict=True,
        zero_division=0
    )

    print("\n==========  Per-Class Metrics  ==========")
    for name in present_names:
        p = report[name]['precision']
        r = report[name]['recall']
        f1 = report[name]['f1-score']
        sup = int(report[name]['support'])
        print(f"{name:>15}  P={p:.4f}  R={r:.4f}  F1={f1:.4f}  Support={sup}")

    # ---------- 4.  混淆矩阵（N×N） ----------
    cm = confusion_matrix(all_labels, all_preds, labels=list(range(num_classes)))
    
    # 计算百分比混淆矩阵（按行归一化，每行表示真实类别的预测分布）
    cm_percent = cm.astype('float') / (cm.sum(axis=1, keepdims=True) + 1e-8) * 100
    
    print("\n==========  Confusion Matrix (Percentage)  ==========")
    print("每行表示真实类别的预测分布百分比（%）")
    print(f"{'':>15}", end="")
    for name in ID2NAME:
        print(f"{name:>10}", end="")
    print()
    for i, name in enumerate(ID2NAME):
        print(f"{name:>15}", end="")
        for j in range(num_classes):
            print(f"{cm_percent[i, j]:>9.2f}%", end="")
        print()
    
    # 保存百分比混淆矩阵图片
    plt.figure(figsize=(10, 8))
    sns.heatmap(cm_percent, annot=True, fmt='.2f', cmap='Blues',
                xticklabels=ID2NAME, yticklabels=ID2NAME,
                cbar_kws={'label': 'Percentage (%)'})
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    perturb_suffix = ''
    if args is not None and getattr(args, 'perturb_type', None):
        perturb_suffix = f" - {args.perturb_type}"
        if getattr(args, 'perturb_value', None) is not None:
            perturb_suffix += f" ({args.perturb_value})"
    plt.title(f'Confusion Matrix - Percentage ({num_classes} classes){perturb_suffix}')
    plt.tight_layout()
    if args is not None and getattr(args, 'perturb_type', None) and args.checkpoint_dir is not None:
        save_dir = os.path.join(args.checkpoint_dir, 'confusion_matrix')
    elif args is not None and args.checkpoint_dir is not None:
        save_dir = args.checkpoint_dir.replace('/result', '/混淆矩阵-2')
    else:
        save_dir = 'train_output/混淆矩阵-2'
    os.makedirs(save_dir, exist_ok=True)  # 路径不存在就创建
    # ✅ 第一种最小改动：用当前训练步数命名
    step = args.resume_step if args is not None and hasattr(args, 'resume_step') else 0
    cm_path = os.path.join(save_dir, f'confusion_matrix_step{step}.png')
    plt.savefig(cm_path, dpi=150)
    print(f"✅ 混淆矩阵已保存为 {cm_path}")

    # ---------- 5.  AUC（全集概率） ----------
    if num_classes == 2:
        auc_macro = roc_auc_score(all_labels, all_probs[:, 1])
        auc_per_class = None
    else:
        auc_macro = roc_auc_score(all_labels, all_probs, multi_class='ovr', average='macro')
        auc_per_class = roc_auc_score(all_labels, all_probs, multi_class='ovr', average=None)

    print(f"\n==========  AUC  ==========")
    print(f"Macro AUC : {auc_macro:.4f}")
    if auc_per_class is not None:
        print("Per-class AUC:")
        for i, auc_i in enumerate(auc_per_class):
            print(f"  {ID2NAME[i]}: {auc_i:.4f}")

    if args is not None and getattr(args, 'perturb_type', None) and args.checkpoint_dir is not None:
        metrics_path = os.path.join(args.checkpoint_dir, 'eval_metrics.txt')
        with open(metrics_path, 'w', encoding='utf-8') as f:
            f.write(f"perturb_type: {args.perturb_type}\n")
            f.write(f"perturb_value: {args.perturb_value}\n")
            f.write(f"Accuracy: {acc:.4f}\n")
            f.write(f"Precision (macro): {macro_prec:.4f}\n")
            f.write(f"Recall (macro): {macro_rec:.4f}\n")
            f.write(f"F1-score (macro): {macro_f1:.4f}\n")
            f.write(f"AUC (macro): {auc_macro:.4f}\n")
        print(f"✅ 评估指标已保存为 {metrics_path}")


if __name__ == "__main__":
    main()
