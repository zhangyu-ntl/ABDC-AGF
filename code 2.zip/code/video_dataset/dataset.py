#!/usr/bin/env python

import os
import av
import torch
from torch.utils.data import Dataset
import pandas as pd
import numpy as np
from torchvision import transforms


class VideoDataset(Dataset):
    def __init__(
        self,
        list_path,
        data_root,
        accel_data_root,
        num_frames,
        sampling_rate,
        spatial_size,
        mean=None,
        std=None,
        auto_augment=None,
        interpolation="bicubic",
        mirror=False,
        train=True,
        perturb_type=None,
        perturb_value=None,
        frame_sampling_strategy="default",
    ):
        self.data_root = data_root
        self.accel_data_root = accel_data_root
        self.num_frames = num_frames
        self.sampling_rate = sampling_rate
        self.spatial_size = spatial_size
        self.mean = torch.tensor(mean) if mean is not None else torch.tensor([0.485, 0.456, 0.406])
        self.std = torch.tensor(std) if std is not None else torch.tensor([0.229, 0.224, 0.225])
        self.auto_augment = auto_augment
        self.interpolation = interpolation
        self.mirror = mirror
        self.train = train
        self.perturb_type = perturb_type
        self.perturb_value = perturb_value
        self.frame_sampling_strategy = frame_sampling_strategy
        if self.perturb_type is not None:
            raise ValueError("Perturbation experiments are not included in this release.")
        if self.frame_sampling_strategy not in {"default"}:
            raise ValueError(
                f"Unsupported frame_sampling_strategy={self.frame_sampling_strategy!r}. "
                "This release uses default sampling only."
            )

        with open(list_path, "r") as f:
            self.video_list = [line.strip() for line in f if line.strip()]

    def _load_accel(self, accel_path):
        FIX_LEN = 256
        accel_df = pd.read_excel(accel_path, engine="openpyxl").iloc[:, 1:10]
        accel_df = accel_df.apply(pd.to_numeric, errors="coerce").fillna(0.0)
        data = accel_df.values.astype(np.float32)
        data = torch.from_numpy(data)
        if data.shape[0] > FIX_LEN:
            data = data[:FIX_LEN]
        else:
            pad_len = FIX_LEN - data.shape[0]
            data = torch.cat([data, torch.zeros(pad_len, data.shape[1])], dim=0)
        return data

    def __len__(self):
        return len(self.video_list)

    def __getitem__(self, idx):
        line = self.video_list[idx]
        parts = line.split(",")
        video_path = parts[0].strip()
        accel_path = parts[1].strip() if len(parts) >= 2 else video_path.replace(".mp4", ".xlsx")
        video_path = os.path.join(self.data_root, video_path)
        accel_path = os.path.join(self.accel_data_root, accel_path)

        container = av.open(video_path)
        frames = [frame.to_rgb().to_ndarray() for frame in container.decode(video=0)]
        container.close()

        if self.train:
            frame_indices = np.random.choice(
                len(frames), self.num_frames * self.sampling_rate, replace=True
            )
        else:
            frame_indices = np.linspace(
                0, len(frames) - 1, self.num_frames * self.sampling_rate, dtype=int
            )

        frames = [frames[i] for i in frame_indices]
        frames = [torch.from_numpy(frame).permute(2, 0, 1).float() / 255.0 for frame in frames]
        frames = torch.stack(frames)  # [T, C, H, W]

        mean = self.mean.view(3, 1, 1)
        std = self.std.view(3, 1, 1)
        frames = (frames - mean) / std
        frames = frames.permute(1, 0, 2, 3)  # [C, T, H, W]
        frames = transforms.Resize((self.spatial_size, self.spatial_size), antialias=True)(frames)

        accel_data = self._load_accel(accel_path)
        label = int(parts[2]) - 1  # 1-6 -> 0-5
        assert 0 <= label < 6, f"invalid label {label} (must be 0-5)"
        video_rel_path = parts[0].strip()
        return frames, accel_data, label, video_rel_path
