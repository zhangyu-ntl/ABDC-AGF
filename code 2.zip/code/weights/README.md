Place downloaded checkpoints here (not shipped), e.g. `weights/best_model.pth`.
