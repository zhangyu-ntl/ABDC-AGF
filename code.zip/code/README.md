# VitaCLIP 开源代码

本目录从完整研究项目中提取 **VitaCLIP 多模态行为识别方法** 的核心源代码，用于公开发布。不包含训练日志、模型权重、消融/压缩/扰动等实验脚本及本地私有路径配置。

## 方法概述

VitaCLIP 是一个融合 **视频视觉** 与 **加速度计传感器** 的多模态行为识别框架，核心创新模块包括：

| 模块 | 文件 | 说明 |
|------|------|------|
| 主模型 | `training/BehaviorCLIP_model.py` | VitaCLIP 整体架构与分类头 |
| 视频编码器 | `training/BehaviorCLIP_vision_encoder.py` | 基于 ViT 的视频特征提取 |
| 传感器编码器 | `training/Accelerometer_Encoder.py` | 加速度计 Transformer 编码 |
| 动态帧采样 | `training/dynamic_frame_sampler.py` | 自适应关键帧选择 |
| 关键帧预测 | `training/KeyFramePredictor.py` | 帧重要性评分 |
| 双路径时空注意力 | `training/DualPathSpatioTemporalAttention.py` | 空间/时间双路径建模 |
| 特征金字塔 | `training/feature_pyramid.py` | 多尺度视觉特征 |
| 时空对比学习 | `training/TemporalPositionalContrastiveLearning.py` | 时间-位置对比损失 |
| 上下文感知 | `training/ContextAwareModule.py` | 传感器上下文增强 |
| 双向交叉注意力 | `training/BiDirectionalDynamicCrossAttention.py` | 跨模态交互 |
| 自适应门控融合 | `training/AdaptiveGate.py` | 模态权重融合 |
| 改进损失函数 | `training/improved_losses.py` | Focal / Dice / Tversky 等 |
| 三阶段集成融合 | `training/ensemble_*.py` | 全局 / 类别 / 样本级 MoE |

详细架构说明见 `docs/ARCHITECTURE_DETAILED.md`。

## 目录结构

```
开源代码/
├── README.md                 # 本文件
├── 文件清单.md               # 包含/排除文件说明
├── requirements.txt          # Python 依赖
├── training/                 # 模型与训练核心代码
├── video_dataset/            # 数据加载与增强
├── train_scripts/            # 示例训练/评估脚本（需修改数据路径）
├── fusion_run_guide/         # 三阶段集成融合示例脚本
└── docs/                     # 架构与指标说明文档
```

## 环境配置

```bash
# 建议使用 Python 3.9 + CUDA 11.8
pip install -r requirements.txt

# PyTorch 需按 CUDA 版本单独安装，例如：
pip install torch==2.0.0 torchvision==0.15.1 torchaudio==2.0.1 \
  --index-url https://download.pytorch.org/whl/cu118
```

> 若仅使用默认 CLIP 视频编码器，无需安装 `pytorchvideo` / `transformers`（SlowFast / VideoMAE 对比实验用）。

## 数据准备

数据目录结构示例：

```
behavior/
├── train-video/          # 训练视频
├── val-video/            # 验证视频
├── train-table/          # 训练加速度计 (.xlsx)
├── val-table/            # 验证加速度计 (.xlsx)
├── train_balanced.csv    # 训练列表
└── val_balanced.csv      # 验证列表
```

## 训练

1. 编辑 `train_scripts/cow_train.sh`，将 `DATA_ROOT` 改为你的数据路径
2. 运行：

```bash
cd 开源代码
bash train_scripts/cow_train.sh
```

或直接调用 Python：

```bash
python training/train-Behavior.py \
    --checkpoint_dir train_output/result \
    --train_list_path /path/to/train_balanced.csv \
    --val_list_path /path/to/val_balanced.csv \
    --train_data_root /path/to/train-video \
    --val_data_root /path/to/val-video \
    --accel_train_dir /path/to/train-table \
    --accel_val_dir /path/to/val-table \
    --use_dynamic_sample --use_pyramid --use_keyframe \
    --use_dual_path_attention --use_context \
    --use_cross_attn --use_gate
```

## 评估

```bash
# 修改 train_scripts/eval_single_model.sh 中的 CHECKPOINT 和数据路径
bash train_scripts/eval_single_model.sh
```

## 三阶段集成融合

训练多个专家模型后，可按以下顺序运行：

```bash
bash fusion_run_guide/run_stageA_ensemble_6.sh   # Stage A: 全局加权
bash fusion_run_guide/run_stageB_classwise_6.sh  # Stage B: 类别级权重
bash fusion_run_guide/run_stageC_moe_6.sh        # Stage C: 样本级 MoE
```

## 许可证

仅供学术研究使用。发布前请自行补充 LICENSE 文件并确认不含敏感数据路径。
