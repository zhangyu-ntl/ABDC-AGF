#!/usr/bin/env bash
# VitaCLIP 完整方法训练示例
# 使用前请设置 DATA_ROOT 为你的数据根目录

DATA_ROOT="${DATA_ROOT:-/path/to/behavior}"   # <-- 修改此处

exp_dir=train_output/result
mkdir -p "${exp_dir}"

python3 ./training/train-Behavior.py \
    --checkpoint_dir "${exp_dir}" \
    --auto_resume \
    --num_steps 10000 \
    --save_freq 1000 \
    --eval_freq 500 \
    --print_freq 200 \
    --batch_size 4 \
    --batch_split 16 \
    --lr           1.5e-5   \
    --warmup_steps 1500 \
    --weight_decay 0.1 \
    --train_list_path "${DATA_ROOT}/train_balanced.csv" \
    --val_list_path "${DATA_ROOT}/val_balanced.csv" \
    --train_data_root "${DATA_ROOT}/train-video" \
    --val_data_root "${DATA_ROOT}/val-video" \
    --accel_train_dir "${DATA_ROOT}/train-table" \
    --accel_val_dir "${DATA_ROOT}/val-table" \
    --accel_dim 9 \
    --sampling_rate 16 \
    --auto_augment "rand-m5-n1-mstd0.5-inc1" \
    --interpolation 'bicubic' \
    --spatial_size 224 \
    --num_frames 8 \
    --accel_num_layers 6 \
    --accel_d_model 768 \
    --accel_nhead 8 \
    --accel_dim_feedforward 2048 \
    --accel_dropout 0.1 \
    --use_summary_token \
    --use_local_prompts \
    --use_global_prompts \
    --num_global_prompts 4 \
    --mean 0.485 0.456 0.406 \
    --std 0.229 0.224 0.225 \
    --use_dynamic_sample        \
    --use_pyramid               \
    --use_keyframe              \
    --use_dual_path_attention   \
    --dual_path_fusion_method gate \
    --use_context               \
    --use_cross_attn            \
    --use_gate                  \
    --loss_type combined        \
    --focal_gamma 2.5           \
    --lambda_dice 0.25          \
    --use_tversky               \
    --tversky_alpha 0.8         \
    --label_smoothing 0.15      \
    --use_tta                   \
    --tta_num_augments 5        \
    --use_temperature_scaling   \
    --temperature 1.5           \
    2>&1 | tee "${exp_dir}/train-$(date +"%Y%m%d_%H%M%S").log"
