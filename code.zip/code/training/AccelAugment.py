#加速度处理部分
#定义数据增强模块

import numpy as np
import torch

class AccelAugment:
    def __init__(self,
                 crop_len=256,
                 noise_std=0.003,
                 scale_range=(0.95, 1.05),
                 shift_range=(-0.1, 0.1),
                 time_warp_ratio=(0.9, 1.1),
                 flip_prob=0.2):
        self.crop_len = crop_len
        self.noise_std = noise_std
        self.scale_range = scale_range
        self.shift_range = shift_range
        self.time_warp_ratio = time_warp_ratio
        self.flip_prob = flip_prob

    def __call__(self, x: torch.Tensor):
        # x: [L, C]
        x = x.numpy()
        L, C = x.shape

        # 1. 时间裁剪
        if L > self.crop_len:
            start = np.random.randint(0, L - self.crop_len + 1)
            x = x[start:start + self.crop_len]
        else:
            pad_len = self.crop_len - L
            x = np.pad(x, ((0, pad_len), (0, 0)), mode='constant')

        # 2. 时间扭曲（线性插值）
        warp_ratio = np.random.uniform(*self.time_warp_ratio)
        new_len = max(1, int(self.crop_len * warp_ratio))
        x = torch.from_numpy(x).unsqueeze(0)  # [1, L, C]
        x = torch.nn.functional.interpolate(x.permute(0, 2, 1), size=new_len, mode='linear', align_corners=False)
        x = torch.nn.functional.interpolate(x, size=self.crop_len, mode='linear', align_corners=False)
        x = x.permute(0, 2, 1).squeeze(0).numpy()

        # 3. 添加噪声
        noise = np.random.normal(0, self.noise_std, x.shape)
        x += noise

        # 4. 随机缩放
        scale = np.random.uniform(*self.scale_range)
        x *= scale

        # 5. 随机偏移
        shift = np.random.uniform(*self.shift_range)
        x += shift

        # 6. 时间翻转
        if np.random.rand() < self.flip_prob:
            x = np.flip(x, axis=0).copy()

        return torch.from_numpy(x.astype(np.float32))
