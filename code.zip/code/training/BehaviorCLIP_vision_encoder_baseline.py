# Baseline video encoders: SlowFast and VideoMAE
from typing import Tuple, Optional
import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

from BehaviorCLIP_vision_encoder_utils import LayerNorm


class SlowFastEncoder(nn.Module):
    """SlowFast R50 encoder (pytorchvideo), outputs [B, T, C] tokens."""

    SLOW_FRAMES = 8
    FAST_FRAMES = 32
    ALPHA = 4

    def __init__(
        self,
        feature_dim: int = 768,
        num_frames: int = 8,
        pretrained: bool = True,
    ):
        super().__init__()
        from pytorchvideo.models.hub import slowfast_r50

        self.feature_dim = feature_dim
        self.num_frames = num_frames
        backbone = slowfast_r50(pretrained=pretrained)
        # blocks: 0-4 pathway, 5 pool, 6 head
        self.blocks = nn.ModuleList(list(backbone.blocks[:-1]))
        self.slow_feature_dim = 1280
        self.proj = nn.Linear(self.slow_feature_dim, feature_dim)
        self._extract_block_idx = 3

    def _prepare_pathways(self, x: torch.Tensor):
        """Convert [B, C, T, H, W] to slow/fast pathway inputs."""
        b, c, t, h, w = x.shape
        if t >= self.SLOW_FRAMES:
            slow = x[:, :, : self.SLOW_FRAMES]
        else:
            slow = F.interpolate(
                x, size=(self.SLOW_FRAMES, h, w), mode="trilinear", align_corners=False
            )
        if t >= self.FAST_FRAMES:
            fast = x[:, :, : self.FAST_FRAMES]
        else:
            fast = F.interpolate(
                x, size=(self.FAST_FRAMES, h, w), mode="trilinear", align_corners=False
            )
        return [slow, fast]

    def _extract_slow_temporal(self, pathway_out):
        """Extract slow pathway tokens before temporal collapse."""
        slow = pathway_out[0]  # [B, C, T, H, W]
        b, c, t, h, w = slow.shape
        slow = slow.mean(dim=[3, 4])  # [B, C, T]
        slow = slow.permute(0, 2, 1)  # [B, T, C]
        return slow

    def forward_tokens(self, x: torch.Tensor, return_patch_tokens: bool = False):
        pathways = self._prepare_pathways(x)
        out = pathways
        slow_tokens = None
        for i, block in enumerate(self.blocks):
            out = block(out)
            if i == self._extract_block_idx:
                slow_tokens = self._extract_slow_temporal(out)

        if slow_tokens is None:
            slow_tokens = self._extract_slow_temporal(out)

        t = slow_tokens.size(1)
        if t != self.num_frames:
            slow_tokens = F.interpolate(
                slow_tokens.permute(0, 2, 1),
                size=self.num_frames,
                mode="linear",
                align_corners=False,
            ).permute(0, 2, 1)

        tokens = self.proj(slow_tokens)
        key_score = None
        if return_patch_tokens:
            return tokens, key_score, None
        return tokens, key_score

    def forward(self, x: torch.Tensor):
        tokens, key_score = self.forward_tokens(x)
        return tokens.mean(dim=1), key_score


class VideoMAEEncoder(nn.Module):
    """VideoMAE-style tubelet ViT encoder, outputs [B, T, C] tokens."""

    def __init__(
        self,
        input_size: Tuple[int, int] = (224, 224),
        num_frames: int = 8,
        feature_dim: int = 768,
        patch_size: Tuple[int, int] = (16, 16),
        tubelet_size: int = 1,
        num_heads: int = 12,
        num_layers: int = 12,
        mlp_factor: float = 4.0,
    ):
        super().__init__()
        self.feature_dim = feature_dim
        self.num_frames = num_frames
        self.patch_size = patch_size
        self.tubelet_size = tubelet_size

        self.patch_embed = nn.Conv3d(
            3,
            feature_dim,
            kernel_size=(tubelet_size, patch_size[0], patch_size[1]),
            stride=(tubelet_size, patch_size[0], patch_size[1]),
        )
        grid = input_size[0] // patch_size[0]
        self.num_spatial_patches = grid * grid
        self.num_temporal_patches = num_frames // tubelet_size

        self.cls_token = nn.Parameter(torch.zeros(1, 1, feature_dim))
        num_patches = self.num_temporal_patches * self.num_spatial_patches
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + 1, feature_dim))

        self.blocks = nn.ModuleList([
            nn.TransformerEncoderLayer(
                d_model=feature_dim,
                nhead=num_heads,
                dim_feedforward=int(feature_dim * mlp_factor),
                batch_first=True,
            )
            for _ in range(num_layers)
        ])
        self.ln_pre = LayerNorm(feature_dim)
        self.ln_post = LayerNorm(feature_dim)
        self._initialize_weights()

    def _initialize_weights(self):
        nn.init.normal_(self.cls_token, std=0.02)
        nn.init.normal_(self.pos_embed, std=0.02)

    def forward_tokens(self, x: torch.Tensor, return_patch_tokens: bool = False):
        b, c, t, h, w = x.size()
        if t % self.tubelet_size != 0:
            pad = self.tubelet_size - (t % self.tubelet_size)
            x = F.pad(x, (0, 0, 0, 0, 0, pad))
            t = x.size(2)

        x = self.patch_embed(x)  # [B, D, T', H', W']
        x = rearrange(x, "b d t h w -> b (t h w) d")
        cls = self.cls_token.expand(b, -1, -1)
        x = torch.cat([cls, x], dim=1)
        if x.size(1) != self.pos_embed.size(1):
            pos = F.interpolate(
                self.pos_embed.permute(0, 2, 1),
                size=x.size(1),
                mode="linear",
                align_corners=False,
            ).permute(0, 2, 1)
        else:
            pos = self.pos_embed
        x = self.ln_pre(x + pos)

        for blk in self.blocks:
            x = blk(x)

        patch_tokens = x[:, 1:]
        t_patches = t // self.tubelet_size
        s_patches = self.num_spatial_patches
        if patch_tokens.size(1) >= t_patches * s_patches:
            patch_tokens = patch_tokens[:, : t_patches * s_patches]
            frame_tokens = patch_tokens.view(b, t_patches, s_patches, -1).mean(dim=2)
        else:
            frame_tokens = patch_tokens.mean(dim=1, keepdim=True).expand(-1, self.num_frames, -1)

        if frame_tokens.size(1) != self.num_frames:
            frame_tokens = F.interpolate(
                frame_tokens.permute(0, 2, 1),
                size=self.num_frames,
                mode="linear",
                align_corners=False,
            ).permute(0, 2, 1)

        frame_tokens = self.ln_post(frame_tokens)
        key_score = None
        if return_patch_tokens:
            return frame_tokens, key_score, patch_tokens
        return frame_tokens, key_score

    def forward(self, x: torch.Tensor):
        tokens, key_score = self.forward_tokens(x)
        return tokens.mean(dim=1), key_score
