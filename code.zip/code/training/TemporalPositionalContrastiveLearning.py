# 时间-位置对比学习模块
# 用于视频特征的对比学习，包括时间维度对比和位置维度对比
# 用于消融实验

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange


class TemporalPositionalContrastiveLearning(nn.Module):
    """
    时间-位置对比学习模块
    
    设计思路:
    1. 时间对比学习: 
       - 正样本: 相邻时间帧的特征 (时间距离小)
       - 负样本: 距离远的时间帧特征 (时间距离大)
       - 目标: 使相邻帧特征相似，远距离帧特征不同
    
    2. 位置对比学习:
       - 正样本: 同一帧的不同patch位置 (空间邻域)
       - 负样本: 距离较远的patch位置
       - 目标: 使空间邻域的特征相似
    
    输入: 
    - cls_tokens: [B, T, C] - 视频特征tokens (从CLIPVisionEncoder的输出)
    - patch_tokens: [B*T, N, C] - patch tokens (可选，用于位置对比)
    
    输出:
    - contrastive_loss: 对比学习损失值
    """
    
    def __init__(
        self,
        feature_dim: int = 768,
        temperature: float = 0.07,
        time_window: int = 2,  # 时间对比的正样本窗口大小
        spatial_window: int = 3,  # 位置对比的正样本窗口大小
        use_temporal_contrast: bool = True,
        use_positional_contrast: bool = True,
        projection_dim: int = 256,  # 投影到更低维度进行对比
    ):
        super().__init__()
        self.feature_dim = feature_dim
        self.temperature = temperature
        self.time_window = time_window
        self.spatial_window = spatial_window
        self.use_temporal_contrast = use_temporal_contrast
        self.use_positional_contrast = use_positional_contrast
        self.projection_dim = projection_dim
        
        # 特征投影层：将特征投影到对比学习空间
        if self.use_temporal_contrast:
            self.temporal_proj = nn.Sequential(
                nn.Linear(feature_dim, projection_dim),
                nn.ReLU(inplace=True),
                nn.Linear(projection_dim, projection_dim),
                nn.LayerNorm(projection_dim)
            )
        
        if self.use_positional_contrast:
            self.positional_proj = nn.Sequential(
                nn.Linear(feature_dim, projection_dim),
                nn.ReLU(inplace=True),
                nn.Linear(projection_dim, projection_dim),
                nn.LayerNorm(projection_dim)
            )
    
    def temporal_contrastive_loss(self, features: torch.Tensor):
        """
        时间对比学习损失
        
        输入: features [B, T, C]
        输出: loss (标量)
        
        策略:
        - 对于每个时间步t，正样本是 [t-window, t+window] 范围内的帧
        - 负样本是超出window范围的帧
        """
        # 确保输入是3维的 [B, T, C]
        if features.dim() == 2:
            # 如果是2维 [B, C]，无法进行时间对比，返回0损失
            return torch.tensor(0.0, device=features.device, requires_grad=True)
        
        if features.dim() != 3:
            raise ValueError(f"Expected 3D tensor [B, T, C], got {features.dim()}D tensor with shape {features.shape}")
        
        B, T, C = features.shape
        
        # 投影特征
        features_proj = self.temporal_proj(features)  # [B, T, projection_dim]
        
        # 归一化
        features_proj = F.normalize(features_proj, p=2, dim=-1)  # [B, T, projection_dim]
        
        total_loss = 0.0
        valid_pairs = 0
        
        # 对于每个时间步，计算与其他时间步的对比
        for t in range(T):
            anchor = features_proj[:, t, :]  # [B, projection_dim]
            
            # 确定正样本和负样本
            pos_indices = []
            neg_indices = []
            
            for other_t in range(T):
                time_dist = abs(other_t - t)
                if 0 < time_dist <= self.time_window:
                    pos_indices.append(other_t)
                elif time_dist > self.time_window:
                    neg_indices.append(other_t)
            
            if len(pos_indices) == 0:
                continue
            
            # 计算与正样本的相似度
            pos_features = features_proj[:, pos_indices, :]  # [B, num_pos, projection_dim]
            pos_sim = torch.bmm(
                anchor.unsqueeze(1),  # [B, 1, projection_dim]
                pos_features.transpose(1, 2)  # [B, projection_dim, num_pos]
            ).squeeze(1)  # [B, num_pos]
            
            # 计算与负样本的相似度
            if len(neg_indices) > 0:
                neg_features = features_proj[:, neg_indices, :]  # [B, num_neg, projection_dim]
                neg_sim = torch.bmm(
                    anchor.unsqueeze(1),  # [B, 1, projection_dim]
                    neg_features.transpose(1, 2)  # [B, projection_dim, num_neg]
                ).squeeze(1)  # [B, num_neg]
                
                # InfoNCE损失
                # 将所有正样本平均作为单个正样本，然后与负样本对比
                pos_sim_avg = pos_sim.mean(dim=1, keepdim=True)  # [B, 1]
                logits = torch.cat([pos_sim_avg, neg_sim], dim=1) / self.temperature  # [B, 1 + num_neg]
                labels = torch.zeros(B, dtype=torch.long, device=features.device)  # 正样本在索引0
                
                # 使用CrossEntropy，第一个是正样本
                loss = F.cross_entropy(logits, labels, reduction='mean')
            else:
                # 如果没有负样本，使用正样本的相似度最大化
                loss = -pos_sim.mean()
            
            total_loss += loss
            valid_pairs += 1
        
        if valid_pairs == 0:
            return torch.tensor(0.0, device=features.device, requires_grad=True)
        
        return total_loss / valid_pairs
    
    def positional_contrastive_loss(self, patch_features: torch.Tensor):
        """
        位置对比学习损失（优化内存版本）
        
        输入: patch_features [B*T, N, C] - patch tokens
        输出: loss (标量)
        
        策略:
        - 对于每个patch位置，正样本是空间邻域内的patch
        - 负样本是距离较远的patch
        - 使用采样策略减少内存使用
        """
        if patch_features is None or patch_features.numel() == 0:
            return torch.tensor(0.0, device=patch_features.device if patch_features is not None else 'cuda', requires_grad=True)
        
        if patch_features.dim() != 3:
            # 如果不是3维，跳过位置对比
            return torch.tensor(0.0, device=patch_features.device, requires_grad=True)
        
        BT, N, C = patch_features.shape
        
        # 如果patch数量太大，进行采样以减少内存使用
        max_patches = 100  # 限制最大patch数量
        if N > max_patches:
            # 随机采样部分patches
            indices = torch.randperm(N, device=patch_features.device)[:max_patches]
            patch_features = patch_features[:, indices, :]
            N = max_patches
        
        # 投影特征
        features_proj = self.positional_proj(patch_features)  # [BT, N, projection_dim]
        
        # 归一化
        features_proj = F.normalize(features_proj, p=2, dim=-1)  # [BT, N, projection_dim]
        
        # 不计算所有patch对的相似度矩阵（太占内存），而是逐个处理
        # 假设patch排列为 grid_size x grid_size，计算空间距离
        grid_size = int(N ** 0.5)
        if grid_size * grid_size != N:
            # 如果不是完全平方数，简化处理：使用索引距离
            grid_size = N
        
        # 限制每个样本处理的patch数量，进一步减少内存
        max_samples_per_batch = min(16, BT)  # 每次只处理部分样本
        sample_indices = torch.randperm(BT, device=patch_features.device)[:max_samples_per_batch]
        features_proj_sampled = features_proj[sample_indices]  # [max_samples, N, projection_dim]
        BT_sampled = max_samples_per_batch
        
        total_loss = 0.0
        valid_patches = 0
        
        # 只处理部分patches以节省内存
        max_patches_to_process = min(20, N)  # 最多处理20个patches
        
        for i in range(0, N, max(1, N // max_patches_to_process)):
            # 计算patch i与其他patch的空间距离
            row_i = i // grid_size
            col_i = i % grid_size
            
            pos_indices = []
            neg_indices = []
            
            for j in range(N):
                if i == j:
                    continue
                
                row_j = j // grid_size
                col_j = j % grid_size
                
                # 计算空间距离（曼哈顿距离）
                spatial_dist = abs(row_i - row_j) + abs(col_i - col_j)
                
                if spatial_dist <= self.spatial_window:
                    pos_indices.append(j)
                else:
                    neg_indices.append(j)
            
            if len(pos_indices) == 0:
                continue
            
            # anchor特征（使用采样后的数据）
            anchor = features_proj_sampled[:, i, :]  # [BT_sampled, projection_dim]
            
            # 正样本相似度
            if len(pos_indices) > 0:
                pos_features = features_proj_sampled[:, pos_indices, :]  # [BT_sampled, num_pos, projection_dim]
                pos_sim = torch.bmm(
                    anchor.unsqueeze(1),  # [BT_sampled, 1, projection_dim]
                    pos_features.transpose(1, 2)  # [BT_sampled, projection_dim, num_pos]
                ).squeeze(1)  # [BT_sampled, num_pos]
            else:
                continue
            
            # 负样本相似度（也限制负样本数量以节省内存）
            if len(neg_indices) > 0:
                # 限制负样本数量
                max_neg = min(10, len(neg_indices))
                neg_indices_sampled = neg_indices[:max_neg]
                neg_features = features_proj_sampled[:, neg_indices_sampled, :]  # [BT_sampled, num_neg, projection_dim]
                neg_sim = torch.bmm(
                    anchor.unsqueeze(1),  # [BT_sampled, 1, projection_dim]
                    neg_features.transpose(1, 2)  # [BT_sampled, projection_dim, num_neg]
                ).squeeze(1)  # [BT_sampled, num_neg]
                
                # InfoNCE损失
                # 将所有正样本平均作为单个正样本，然后与负样本对比
                pos_sim_avg = pos_sim.mean(dim=1, keepdim=True)  # [BT_sampled, 1]
                logits = torch.cat([pos_sim_avg, neg_sim], dim=1) / self.temperature  # [BT_sampled, 1 + num_neg]
                labels = torch.zeros(BT_sampled, dtype=torch.long, device=patch_features.device)
                loss = F.cross_entropy(logits, labels, reduction='mean')
            else:
                loss = -pos_sim.mean()
            
            total_loss += loss
            valid_patches += 1
            
            # 清理中间变量以节省内存
            del anchor, pos_features, pos_sim
            if len(neg_indices) > 0:
                del neg_features, neg_sim
            torch.cuda.empty_cache()
        
        if valid_patches == 0:
            return torch.tensor(0.0, device=patch_features.device, requires_grad=True)
        
        return total_loss / valid_patches
    
    def forward(self, cls_tokens: torch.Tensor, patch_tokens: torch.Tensor = None):
        """
        前向传播
        
        参数:
        - cls_tokens: [B, T, C] - 视频特征tokens (必需)
        - patch_tokens: [B*T, N, C] - patch tokens (可选，用于位置对比)
        
        返回:
        - contrastive_loss: 对比学习损失值
        - loss_dict: 损失分量字典
        """
        loss_dict = {}
        total_loss = 0.0
        
        # 调试：检查输入维度
        if cls_tokens.dim() != 3:
            # 如果不是3维，打印警告并跳过时间对比
            # print(f"[DEBUG] cls_tokens shape: {cls_tokens.shape}, dim: {cls_tokens.dim()}")
            if cls_tokens.dim() == 2:
                # 尝试reshape为[B, 1, C]（假设只有一个时间步）
                cls_tokens = cls_tokens.unsqueeze(1)  # [B, C] -> [B, 1, C]
            else:
                # 其他情况，跳过时间对比
                temporal_loss = torch.tensor(0.0, device=cls_tokens.device, requires_grad=True)
                if self.use_temporal_contrast:
                    loss_dict['temporal_contrast'] = temporal_loss.item()
                return total_loss, loss_dict
        
        # 时间对比学习
        if self.use_temporal_contrast:
            temporal_loss = self.temporal_contrastive_loss(cls_tokens)
            loss_dict['temporal_contrast'] = temporal_loss.item()
            total_loss += temporal_loss
        
        # 位置对比学习
        if self.use_positional_contrast and patch_tokens is not None:
            positional_loss = self.positional_contrastive_loss(patch_tokens)
            loss_dict['positional_contrast'] = positional_loss.item()
            total_loss += positional_loss
        
        loss_dict['total_contrast'] = total_loss.item()
        
        return total_loss, loss_dict

