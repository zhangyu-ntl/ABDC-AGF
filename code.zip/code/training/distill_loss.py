#定义蒸馏动态损失函数

import torch
import torch.nn as nn
import torch.nn.functional as F


class DynamicDistillLoss(nn.Module):
    def __init__(self, temperature=3.0):
        super(DynamicDistillLoss, self).__init__()
        self.temperature = temperature
        self.ce_loss = nn.CrossEntropyLoss()
        self.kd_loss = nn.KLDivLoss(reduction='batchmean')

    def forward(self, student_logits, teacher_logits, labels):
        ce_loss = self.ce_loss(student_logits, labels)
        student_softmax = F.log_softmax(student_logits / self.temperature, dim=-1)
        teacher_softmax = F.softmax(teacher_logits / self.temperature, dim=-1)
        kd_loss = self.kd_loss(student_softmax, teacher_softmax) * (self.temperature ** 2)
        total_loss = ce_loss + kd_loss
        return total_loss
