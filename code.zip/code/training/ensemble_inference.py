"""
模型集成推理脚本
使用多个检查点进行集成，提升预测性能
"""
import sys
import os

# 添加项目根目录和training目录到路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
training_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)
sys.path.insert(0, training_dir)

import torch
import argparse
import numpy as np
from BehaviorCLIP_model import VitaCLIP
from video_dataset.dataloader import create_val_loader
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score


def load_model(checkpoint_path, device):
    """加载模型检查点"""
    print(f"[INFO] 加载模型: {checkpoint_path}")
    
    # 创建模型（根据实际训练配置）
    model = VitaCLIP(
        input_size=(224, 224),
        num_frames=8,
        feature_dim=768,
        patch_size=(16, 16),
        num_heads=12,
        num_layers=12,
        mlp_factor=4.0,
        embed_dim=512,
        accel_dim=9,
        accel_d_model=768,
        accel_nhead=8,
        accel_num_layers=6,
        accel_dim_feedforward=2048,
        accel_dropout=0.1,
        num_classes=6,
        use_dynamic_sample=True,
        use_pyramid=True,
        use_keyframe=True,
        use_dual_path_attention=True,
        dual_path_fusion_method='gate',
        use_context=True,
        use_cross_attn=True,
        use_gate=True,
    )
    
    # 加载权重（PyTorch 2.6+ 默认 weights_only=True 会导致含 numpy 等对象的旧 checkpoint 解包失败）
    try:
        ckpt = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
    except TypeError:
        ckpt = torch.load(checkpoint_path, map_location='cpu')
    
    # 获取模型状态字典
    if 'model_state_dict' in ckpt:
        model_state = ckpt['model_state_dict']
    elif 'model' in ckpt:
        model_state = ckpt['model']
    else:
        raise KeyError(f"检查点文件中未找到 'model' 或 'model_state_dict'。可用键: {list(ckpt.keys())}")
    
    # 处理DataParallel的module.前缀
    new_model_state = {}
    for k, v in model_state.items():
        if k.startswith('module.'):
            # 去掉module.前缀
            new_model_state[k[7:]] = v
        else:
            new_model_state[k] = v
    
    # 加载权重并显示详细信息
    load_result = model.load_state_dict(new_model_state, strict=False)
    if load_result.missing_keys:
        print(f'[WARN] 缺失的键 ({len(load_result.missing_keys)} 个): {load_result.missing_keys[:5]}...' if len(load_result.missing_keys) > 5 else f'[WARN] 缺失的键: {load_result.missing_keys}')
    if load_result.unexpected_keys:
        print(f'[WARN] 未使用的键 ({len(load_result.unexpected_keys)} 个): {load_result.unexpected_keys[:5]}...' if len(load_result.unexpected_keys) > 5 else f'[WARN] 未使用的键: {load_result.unexpected_keys}')
    
    # 显示检查点信息
    if 'best_f1_score' in ckpt:
        print(f'[INFO] 检查点最佳 F1-score: {ckpt["best_f1_score"]:.4f}')
    if 'f1_score' in ckpt:
        print(f'[INFO] 检查点 F1-score: {ckpt["f1_score"]:.4f}')
    if 'accuracy' in ckpt:
        print(f'[INFO] 检查点 Accuracy: {ckpt["accuracy"]:.4f}')
    
    model = model.to(device)
    model.eval()
    print(f"[INFO] ✅ 模型加载完成")
    
    return model


def ensemble_predict(models, video, accel, weights=None, use_tta=False, tta_num_augments=5):
    """
    集成多个模型的预测
    
    Args:
        models: 模型列表
        video: 视频张量 [B, C, T, H, W]
        accel: 加速度计张量 [B, L, C]
        weights: 模型权重列表（可选）
        use_tta: 是否使用测试时增强
        tta_num_augments: TTA 增强次数
    
    Returns:
        final_pred: 集成后的预测概率 [B, num_classes]
    """
    all_logits = []  # 收集logits而不是概率
    
    for model_idx, model in enumerate(models):
        model.eval()
        with torch.no_grad():
            if use_tta:
                # 测试时增强
                logits_list = []
                for _ in range(tta_num_augments):
                    output = model(video, accel)
                    logits_list.append(output['logits'])
                # 平均logits
                logits = torch.stack(logits_list).mean(dim=0)
            else:
                output = model(video, accel)
                logits = output['logits']
            
            all_logits.append(logits)
            
            # 调试信息（第一个模型，第一个批次）
            if model_idx == 0 and video.shape[0] > 0:
                print(f"[DEBUG] 模型 {model_idx + 1} 输出:")
                print(f"  - Logits形状: {logits.shape}")
                print(f"  - Logits值（前5个样本，前3个类别）: {logits[:5, :3].cpu().numpy()}")
                print(f"  - 预测类别: {logits.argmax(dim=1)[:5].cpu().numpy()}")
    
    # 集成logits
    all_logits = torch.stack(all_logits)  # [num_models, B, num_classes]
    
    if weights is None:
        # 简单平均logits
        ensemble_logits = all_logits.mean(dim=0)
    else:
        # 加权平均logits
        weights_tensor = torch.tensor(weights, device=all_logits.device, dtype=torch.float32)
        weights_tensor = weights_tensor / weights_tensor.sum()  # 归一化
        ensemble_logits = (all_logits * weights_tensor.view(-1, 1, 1)).sum(dim=0)
    
    # 对平均后的logits进行softmax
    final_pred = torch.softmax(ensemble_logits, dim=1)
    
    return final_pred


def evaluate_ensemble(models, val_loader, device, weights=None, use_tta=False):
    """评估集成模型"""
    all_preds = []
    all_labels = []
    
    print(f"[INFO] 开始评估集成模型（模型数量: {len(models)}）")
    
    for batch_idx, batch_data in enumerate(val_loader):
        # VideoDataset 返回 (frames, accel_data, label, video_rel_path)
        # 只取前3个值，忽略 video_rel_path
        video, accel, labels = batch_data[:3]
        video = video.to(device)
        accel = accel.to(device)
        labels = labels.to(device).long()  # 确保是long类型
        
        # 集成预测
        pred_probs = ensemble_predict(models, video, accel, weights, use_tta)
        pred_labels = pred_probs.argmax(dim=1)
        
        # 调试信息（第一个批次）
        if batch_idx == 0:
            print(f"[DEBUG] 第一个批次:")
            print(f"  - 视频形状: {video.shape}")
            print(f"  - 加速度计形状: {accel.shape}")
            print(f"  - 标签形状: {labels.shape}, 标签值: {labels[:5].cpu().numpy()}")
            print(f"  - 预测概率形状: {pred_probs.shape}")
            print(f"  - 预测标签: {pred_labels[:5].cpu().numpy()}")
            print(f"  - 预测概率（前5个样本）:\n{pred_probs[:5].cpu().numpy()}")
        
        all_preds.append(pred_labels.cpu().numpy())
        all_labels.append(labels.cpu().numpy())
        
        if (batch_idx + 1) % 50 == 0:
            print(f"[INFO] 已处理 {batch_idx + 1}/{len(val_loader)} 批次")
    
    # 计算指标
    all_preds = np.concatenate(all_preds)
    all_labels = np.concatenate(all_labels)
    
    accuracy = accuracy_score(all_labels, all_preds)
    precision = precision_score(all_labels, all_preds, average='macro', zero_division=0)
    recall = recall_score(all_labels, all_preds, average='macro', zero_division=0)
    f1 = f1_score(all_labels, all_preds, average='macro', zero_division=0)
    
    return {
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1': f1
    }


def main():
    parser = argparse.ArgumentParser(description='模型集成推理')
    parser.add_argument('--checkpoints', nargs='+', required=True,
                        help='模型检查点路径列表')
    parser.add_argument('--weights', nargs='+', type=float, default=None,
                        help='模型权重列表（可选，默认等权重）')
    parser.add_argument('--val_list_path', type=str, required=True,
                        help='验证集列表路径')
    parser.add_argument('--val_data_root', type=str, required=True,
                        help='验证集视频根目录')
    parser.add_argument('--accel_val_dir', type=str, required=True,
                        help='验证集加速度计数据目录')
    parser.add_argument('--use_tta', action='store_true',
                        help='使用测试时增强')
    parser.add_argument('--tta_num_augments', type=int, default=5,
                        help='TTA 增强次数')
    parser.add_argument('--device', type=str, default='cuda',
                        help='设备')
    
    args = parser.parse_args()
    
    device = torch.device(args.device if torch.cuda.is_available() else 'cpu')
    print(f"[INFO] 使用设备: {device}")
    
    # 加载模型
    models = []
    for ckpt_path in args.checkpoints:
        if not os.path.exists(ckpt_path):
            print(f"[WARN] 检查点不存在: {ckpt_path}，跳过")
            continue
        model = load_model(ckpt_path, device)
        models.append(model)
    
    if len(models) == 0:
        print("[ERROR] 没有可用的模型检查点")
        return
    
    print(f"[INFO] 成功加载 {len(models)} 个模型")
    
    # 创建验证集加载器参数对象
    val_args = argparse.Namespace(
        val_list_path=args.val_list_path,
        val_data_root=args.val_data_root,
        accel_val_dir=args.accel_val_dir,
        num_frames=8,
        sampling_rate=16,
        spatial_size=224,
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225],
        batch_size=4,  # 评估时可以使用更大的batch size
        num_workers=4,
    )
    
    # 创建验证集加载器
    val_loader = create_val_loader(val_args)
    
    # 评估
    metrics = evaluate_ensemble(
        models, val_loader, device,
        weights=args.weights,
        use_tta=args.use_tta
    )
    
    # 打印结果
    print("\n" + "=" * 70)
    print("集成模型评估结果")
    print("=" * 70)
    print(f"Accuracy  : {metrics['accuracy']:.4f}")
    print(f"Precision : {metrics['precision']:.4f}")
    print(f"Recall    : {metrics['recall']:.4f}")
    print(f"F1-score  : {metrics['f1']:.4f}")
    print("=" * 70)


if __name__ == '__main__':
    main()

