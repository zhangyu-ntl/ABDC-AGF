#!/usr/bin/env python3
"""
StageB/StageC ensemble on cached expert logits.

StageB: class-wise expert weights W[K, C]
StageC: sample-wise MoE gating network g(x)->[K]
"""
import os
import sys
import argparse
import numpy as np
import torch
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
training_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)
sys.path.insert(0, training_dir)

from ensemble_inference import load_model  # reuse fixed loader
from video_dataset.dataloader import create_val_loader


def _forward_logits(model, video, accel, tta_num_augments):
    if tta_num_augments > 1:
        logits_list = []
        for _ in range(tta_num_augments):
            logits_list.append(model(video, accel)["logits"])
        return torch.stack(logits_list, dim=0).mean(dim=0)
    return model(video, accel)["logits"]


def collect_logits_sequential(checkpoints, val_loader, device, tta_num_augments=1):
    """
    逐个专家加载模型、跑完整验证集，避免 6 个模型同时占显存导致 OOM。
    返回 logits_nkc [N, K, C], labels_n [N]
    """
    labels_chunks = []
    for batch_data in val_loader:
        labels_chunks.append(batch_data[2].numpy())
    labels_n = np.concatenate(labels_chunks, axis=0)

    expert_logits = []
    for ki, ckpt in enumerate(checkpoints):
        print(f"[INFO] 提取专家 {ki + 1}/{len(checkpoints)}: {ckpt}")
        model = load_model(ckpt, device)
        model.eval()
        batch_out = []
        with torch.no_grad():
            for batch_idx, batch_data in enumerate(val_loader):
                video, accel, _ = batch_data[:3]
                video = video.to(device)
                accel = accel.to(device)
                logits = _forward_logits(model, video, accel, tta_num_augments)
                batch_out.append(logits.cpu().numpy())
                if (batch_idx + 1) % 50 == 0:
                    print(f"[INFO]  专家{ki + 1} 已处理 {batch_idx + 1}/{len(val_loader)} 批次")
        expert_logits.append(np.concatenate(batch_out, axis=0))
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    logits_nkc = np.stack(expert_logits, axis=1)
    return logits_nkc, labels_n


def metrics_from_logits(logits_nc, labels_n):
    pred = logits_nc.argmax(axis=1)
    return {
        "accuracy": accuracy_score(labels_n, pred),
        "precision": precision_score(labels_n, pred, average="macro", zero_division=0),
        "recall": recall_score(labels_n, pred, average="macro", zero_division=0),
        "f1": f1_score(labels_n, pred, average="macro", zero_division=0),
    }


def fuse_stage_b(logits_nkc, class_weight_kc):
    # logits_nkc: [N, K, C], class_weight_kc: [K, C]
    return (logits_nkc * class_weight_kc[None, :, :]).sum(axis=1)


def optimize_stage_b(logits_nkc, labels_n):
    n, k, c = logits_nkc.shape
    w = np.ones((k, c), dtype=np.float32) / float(k)
    best_logits = fuse_stage_b(logits_nkc, w)
    best_f1 = metrics_from_logits(best_logits, labels_n)["f1"]
    print(f"[INFO] StageB 初始宏F1: {best_f1:.4f}")

    # simple coordinate-style search per class
    candidates = np.array([0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40], dtype=np.float32)
    for cls in range(c):
        improved = True
        while improved:
            improved = False
            cur_best = w[:, cls].copy()
            cur_best_f1 = best_f1
            for m in range(k):
                for val in candidates:
                    trial = w[:, cls].copy()
                    rest = np.delete(np.arange(k), m)
                    remain = 1.0 - val
                    if remain <= 0:
                        continue
                    trial[rest] = trial[rest] / max(trial[rest].sum(), 1e-8) * remain
                    trial[m] = val

                    w_trial = w.copy()
                    w_trial[:, cls] = trial
                    logits_trial = fuse_stage_b(logits_nkc, w_trial)
                    f1_trial = metrics_from_logits(logits_trial, labels_n)["f1"]
                    if f1_trial > cur_best_f1:
                        cur_best_f1 = f1_trial
                        cur_best = trial.copy()
                        improved = True
            if improved:
                w[:, cls] = cur_best
                best_f1 = cur_best_f1
                print(f"[INFO] StageB 类{cls} 优化后宏F1: {best_f1:.4f}")

    return w


class GatingMLP(torch.nn.Module):
    def __init__(self, in_dim, num_experts, hidden=128):
        super().__init__()
        self.net = torch.nn.Sequential(
            torch.nn.Linear(in_dim, hidden),
            torch.nn.ReLU(inplace=True),
            torch.nn.Dropout(0.2),
            torch.nn.Linear(hidden, hidden),
            torch.nn.ReLU(inplace=True),
            torch.nn.Linear(hidden, num_experts),
        )

    def forward(self, x):
        return self.net(x)


def train_stage_c_moe(
    logits_nkc,
    labels_n,
    epochs=20,
    lr=1e-3,
    batch_size=256,
    seed=42,
    label_smoothing=0.0,
    entropy_reg=0.0,
):
    torch.manual_seed(seed)
    np.random.seed(seed)
    n, k, c = logits_nkc.shape

    x = logits_nkc.reshape(n, k * c).astype(np.float32)
    y = labels_n.astype(np.int64)

    idx = np.arange(n)
    np.random.shuffle(idx)
    split = int(n * 0.8)
    tr, va = idx[:split], idx[split:]

    x_tr = torch.from_numpy(x[tr])
    y_tr = torch.from_numpy(y[tr])
    logits_tr = torch.from_numpy(logits_nkc[tr].astype(np.float32))

    x_va = torch.from_numpy(x[va])
    y_va = y[va]
    logits_va = logits_nkc[va].astype(np.float32)

    model = GatingMLP(in_dim=k * c, num_experts=k, hidden=128)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    ce = torch.nn.CrossEntropyLoss(label_smoothing=label_smoothing)

    best_state = None
    best_f1 = -1.0

    for ep in range(1, epochs + 1):
        model.train()
        perm = torch.randperm(x_tr.size(0))
        x_tr = x_tr[perm]
        y_tr = y_tr[perm]
        logits_tr = logits_tr[perm]

        total_loss = 0.0
        for s in range(0, x_tr.size(0), batch_size):
            e = min(s + batch_size, x_tr.size(0))
            xb = x_tr[s:e]
            yb = y_tr[s:e]
            lb = logits_tr[s:e]  # [B, K, C]

            gate_logits = model(xb)                 # [B, K]
            gate = torch.softmax(gate_logits, dim=1)
            fused = (lb * gate.unsqueeze(-1)).sum(dim=1)  # [B, C]
            loss = ce(fused, yb)
            if entropy_reg > 0:
                # Encourage smoother expert routing to reduce overfitting.
                gate_log = torch.log(gate.clamp_min(1e-8))
                neg_entropy = (gate * gate_log).sum(dim=1).mean()
                loss = loss + entropy_reg * neg_entropy

            opt.zero_grad()
            loss.backward()
            opt.step()
            total_loss += float(loss.item()) * (e - s)

        # validation
        model.eval()
        with torch.no_grad():
            gate_logits = model(x_va)  # [Nv, K]
            gate = torch.softmax(gate_logits, dim=1).cpu().numpy()
            fused_va = (logits_va * gate[:, :, None]).sum(axis=1)
            f1 = metrics_from_logits(fused_va, y_va)["f1"]
        avg_loss = total_loss / max(x_tr.size(0), 1)
        print(f"[INFO] StageC epoch {ep:02d}: loss={avg_loss:.4f}, val_f1={f1:.4f}")
        if f1 > best_f1:
            best_f1 = f1
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}

    model.load_state_dict(best_state)
    return model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["stageB", "stageC"], required=True)
    parser.add_argument("--checkpoints", nargs="+", required=True)
    parser.add_argument("--val_list_path", type=str, required=True)
    parser.add_argument("--val_data_root", type=str, required=True)
    parser.add_argument("--accel_val_dir", type=str, required=True)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--tta_num_augments", type=int, default=1)
    parser.add_argument("--cache_npz", type=str, default="train_output/fusion_pipeline_logs/stageABC_logits_cache.npz")
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--batch_size", type=int, default=1, help="验证 DataLoader batch（单专家推理，默认 1 最省显存）")
    parser.add_argument("--num_workers", type=int, default=0, help="DataLoader worker 数（默认 0 降低内存占用，避免被 OOM killer 杀）")
    parser.add_argument("--gate_label_smoothing", type=float, default=0.0)
    parser.add_argument("--gate_entropy_reg", type=float, default=0.0)
    args = parser.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    print(f"[INFO] 设备: {device}")

    os.makedirs(os.path.dirname(args.cache_npz), exist_ok=True)

    if os.path.exists(args.cache_npz):
        cache = np.load(args.cache_npz)
        logits_nkc = cache["logits_nkc"]
        labels_n = cache["labels_n"]
        print(f"[INFO] 使用缓存 logits: {args.cache_npz}, 形状={logits_nkc.shape}")
    else:
        val_args = argparse.Namespace(
            val_list_path=args.val_list_path,
            val_data_root=args.val_data_root,
            accel_val_dir=args.accel_val_dir,
            num_frames=8,
            sampling_rate=16,
            spatial_size=224,
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225],
            batch_size=args.batch_size,
            num_workers=args.num_workers,
        )
        val_loader = create_val_loader(val_args)
        logits_nkc, labels_n = collect_logits_sequential(
            args.checkpoints,
            val_loader,
            device,
            tta_num_augments=max(1, args.tta_num_augments),
        )
        np.savez_compressed(args.cache_npz, logits_nkc=logits_nkc, labels_n=labels_n)
        print(f"[INFO] 已保存缓存 logits: {args.cache_npz}")

    # baseline (equal)
    equal_w = np.ones((logits_nkc.shape[1], logits_nkc.shape[2]), dtype=np.float32) / float(logits_nkc.shape[1])
    base_logits = fuse_stage_b(logits_nkc, equal_w)
    base = metrics_from_logits(base_logits, labels_n)
    print(f"[BASE] Acc={base['accuracy']:.4f} Prec={base['precision']:.4f} Rec={base['recall']:.4f} F1={base['f1']:.4f}")

    if args.mode == "stageB":
        w_kc = optimize_stage_b(logits_nkc, labels_n)
        out_logits = fuse_stage_b(logits_nkc, w_kc)
        m = metrics_from_logits(out_logits, labels_n)
        weight_path = args.cache_npz.replace(".npz", "_stageB_weights.npy")
        np.save(weight_path, w_kc)
        print(f"[INFO] StageB 权重已保存: {weight_path}")
        print("=" * 70)
        print("StageB 评估结果")
        print("=" * 70)
        print(f"Accuracy  : {m['accuracy']:.4f}")
        print(f"Precision : {m['precision']:.4f}")
        print(f"Recall    : {m['recall']:.4f}")
        print(f"F1-score  : {m['f1']:.4f}")
        print("=" * 70)
    else:
        gate = train_stage_c_moe(
            logits_nkc,
            labels_n,
            epochs=args.epochs,
            lr=args.lr,
            label_smoothing=args.gate_label_smoothing,
            entropy_reg=args.gate_entropy_reg,
        )
        x = torch.from_numpy(logits_nkc.reshape(logits_nkc.shape[0], -1).astype(np.float32))
        with torch.no_grad():
            g = torch.softmax(gate(x), dim=1).numpy()
        out_logits = (logits_nkc * g[:, :, None]).sum(axis=1)
        m = metrics_from_logits(out_logits, labels_n)
        gate_path = args.cache_npz.replace(".npz", "_stageC_gate.pt")
        torch.save(gate.state_dict(), gate_path)
        print(f"[INFO] StageC 门控参数已保存: {gate_path}")
        print("=" * 70)
        print("StageC 评估结果")
        print("=" * 70)
        print(f"Accuracy  : {m['accuracy']:.4f}")
        print(f"Precision : {m['precision']:.4f}")
        print(f"Recall    : {m['recall']:.4f}")
        print(f"F1-score  : {m['f1']:.4f}")
        print("=" * 70)


if __name__ == "__main__":
    main()

