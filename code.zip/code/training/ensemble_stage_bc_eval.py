#!/usr/bin/env python3
"""
Pure evaluation for StageB/StageC on a hold-out dataset.
No weight optimization or gate training is performed here.
"""
import os
import sys
import argparse
import numpy as np
import torch
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
training_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)
sys.path.insert(0, training_dir)

from ensemble_inference import load_model
from video_dataset.dataloader import create_val_loader


class GatingMLP(torch.nn.Module):
    def __init__(self, in_dim, num_experts, hidden=128):
        super().__init__()
        self.net = torch.nn.Sequential(
            torch.nn.Linear(in_dim, hidden),
            torch.nn.ReLU(inplace=True),
            torch.nn.Dropout(0.2),
            torch.nn.Linear(hidden, hidden),
            torch.nn.ReLU(inplace=True),
            torch.nn.Linear(hidden, num_experts),
        )

    def forward(self, x):
        return self.net(x)


def metrics_from_logits(logits_nc, labels_n):
    pred = logits_nc.argmax(axis=1)
    return {
        "accuracy": accuracy_score(labels_n, pred),
        "precision": precision_score(labels_n, pred, average="macro", zero_division=0),
        "recall": recall_score(labels_n, pred, average="macro", zero_division=0),
        "f1": f1_score(labels_n, pred, average="macro", zero_division=0),
    }


def _forward_logits(model, video, accel, tta_num_augments):
    if tta_num_augments > 1:
        logits_list = []
        for _ in range(tta_num_augments):
            logits_list.append(model(video, accel)["logits"])
        return torch.stack(logits_list, dim=0).mean(dim=0)
    return model(video, accel)["logits"]


def collect_logits_sequential(checkpoints, val_loader, device, tta_num_augments=1):
    labels_chunks = []
    for batch_data in val_loader:
        labels_chunks.append(batch_data[2].numpy())
    labels_n = np.concatenate(labels_chunks, axis=0)

    expert_logits = []
    for ki, ckpt in enumerate(checkpoints):
        print(f"[INFO] 提取专家 {ki + 1}/{len(checkpoints)}: {ckpt}")
        model = load_model(ckpt, device)
        model.eval()
        batch_out = []
        with torch.no_grad():
            for batch_idx, batch_data in enumerate(val_loader):
                video, accel, _ = batch_data[:3]
                video = video.to(device)
                accel = accel.to(device)
                logits = _forward_logits(model, video, accel, tta_num_augments)
                batch_out.append(logits.cpu().numpy())
                if (batch_idx + 1) % 50 == 0:
                    print(f"[INFO]  专家{ki + 1} 已处理 {batch_idx + 1}/{len(val_loader)} 批次")
        expert_logits.append(np.concatenate(batch_out, axis=0))
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    logits_nkc = np.stack(expert_logits, axis=1)  # [N, K, C]
    return logits_nkc, labels_n


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["stageB", "stageC"], required=True)
    parser.add_argument("--checkpoints", nargs="+", required=True)
    parser.add_argument("--list_path", type=str, required=True)
    parser.add_argument("--data_root", type=str, required=True)
    parser.add_argument("--accel_dir", type=str, required=True)
    parser.add_argument("--device", type=str, default="cuda")
    parser.add_argument("--tta_num_augments", type=int, default=1)
    parser.add_argument("--batch_size", type=int, default=1)
    parser.add_argument("--num_workers", type=int, default=0)
    parser.add_argument("--stageB_weights", type=str, default="")
    parser.add_argument("--stageC_gate", type=str, default="")
    args = parser.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    print(f"[INFO] 设备: {device}")

    val_args = argparse.Namespace(
        val_list_path=args.list_path,
        val_data_root=args.data_root,
        accel_val_dir=args.accel_dir,
        num_frames=8,
        sampling_rate=16,
        spatial_size=224,
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225],
        batch_size=args.batch_size,
        num_workers=args.num_workers,
    )
    val_loader = create_val_loader(val_args)
    logits_nkc, labels_n = collect_logits_sequential(
        args.checkpoints, val_loader, device, tta_num_augments=max(1, args.tta_num_augments)
    )

    n, k, c = logits_nkc.shape
    print(f"[INFO] logits形状: {logits_nkc.shape}")

    equal_w = np.ones((k, c), dtype=np.float32) / float(k)
    base_logits = (logits_nkc * equal_w[None, :, :]).sum(axis=1)
    base = metrics_from_logits(base_logits, labels_n)
    print(f"[BASE] Acc={base['accuracy']:.4f} Prec={base['precision']:.4f} Rec={base['recall']:.4f} F1={base['f1']:.4f}")

    if args.mode == "stageB":
        if not args.stageB_weights or not os.path.exists(args.stageB_weights):
            raise FileNotFoundError(f"找不到 StageB 权重文件: {args.stageB_weights}")
        w_kc = np.load(args.stageB_weights)
        if w_kc.shape != (k, c):
            raise ValueError(f"StageB 权重形状不匹配: 期望 {(k, c)}，实际 {w_kc.shape}")
        logits = (logits_nkc * w_kc[None, :, :]).sum(axis=1)
        m = metrics_from_logits(logits, labels_n)
        print("=" * 70)
        print("StageB Hold-out 评估结果")
        print("=" * 70)
        print(f"Accuracy  : {m['accuracy']:.4f}")
        print(f"Precision : {m['precision']:.4f}")
        print(f"Recall    : {m['recall']:.4f}")
        print(f"F1-score  : {m['f1']:.4f}")
        print("=" * 70)
    else:
        if not args.stageC_gate or not os.path.exists(args.stageC_gate):
            raise FileNotFoundError(f"找不到 StageC 门控文件: {args.stageC_gate}")
        gate = GatingMLP(in_dim=k * c, num_experts=k, hidden=128)
        gate.load_state_dict(torch.load(args.stageC_gate, map_location="cpu"))
        gate.eval()
        x = torch.from_numpy(logits_nkc.reshape(n, -1).astype(np.float32))
        with torch.no_grad():
            g = torch.softmax(gate(x), dim=1).numpy()
        logits = (logits_nkc * g[:, :, None]).sum(axis=1)
        m = metrics_from_logits(logits, labels_n)
        print("=" * 70)
        print("StageC Hold-out 评估结果")
        print("=" * 70)
        print(f"Accuracy  : {m['accuracy']:.4f}")
        print(f"Precision : {m['precision']:.4f}")
        print(f"Recall    : {m['recall']:.4f}")
        print(f"F1-score  : {m['f1']:.4f}")
        print("=" * 70)


if __name__ == "__main__":
    main()

