#!/usr/bin/env python3
"""
Fit per-expert temperature on validation logits, then evaluate on test logits.
"""
import os
import sys
import argparse
import numpy as np
import torch
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
training_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)
sys.path.insert(0, training_dir)

from ensemble_stage_bc_eval import collect_logits_sequential
from video_dataset.dataloader import create_val_loader


def metrics(logits, labels):
    pred = logits.argmax(axis=1)
    return {
        "accuracy": accuracy_score(labels, pred),
        "precision": precision_score(labels, pred, average="macro", zero_division=0),
        "recall": recall_score(labels, pred, average="macro", zero_division=0),
        "f1": f1_score(labels, pred, average="macro", zero_division=0),
    }


def make_loader(list_path, data_root, accel_dir, batch_size=1, num_workers=0):
    args = argparse.Namespace(
        val_list_path=list_path,
        val_data_root=data_root,
        accel_val_dir=accel_dir,
        num_frames=8,
        sampling_rate=16,
        spatial_size=224,
        mean=[0.485, 0.456, 0.406],
        std=[0.229, 0.224, 0.225],
        batch_size=batch_size,
        num_workers=num_workers,
    )
    return create_val_loader(args)


def fit_temps(logits_nkc, labels_n, max_iter=100):
    n, k, c = logits_nkc.shape
    y = torch.from_numpy(labels_n.astype(np.int64))
    temps = np.ones((k,), dtype=np.float32)

    for i in range(k):
        logits = torch.from_numpy(logits_nkc[:, i, :].astype(np.float32))
        log_t = torch.nn.Parameter(torch.zeros(()))
        optimizer = torch.optim.LBFGS([log_t], lr=0.1, max_iter=max_iter, line_search_fn="strong_wolfe")

        def closure():
            optimizer.zero_grad()
            t = torch.exp(log_t).clamp_min(1e-4)
            loss = F.cross_entropy(logits / t, y)
            loss.backward()
            return loss

        optimizer.step(closure)
        temps[i] = float(torch.exp(log_t).detach().cpu().item())
        print(f"[INFO] 专家{i+1} 最优温度: {temps[i]:.4f}")

    return temps


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--checkpoints", nargs="+", required=True)
    p.add_argument("--val_list_path", required=True)
    p.add_argument("--val_data_root", required=True)
    p.add_argument("--val_accel_dir", required=True)
    p.add_argument("--test_list_path", required=True)
    p.add_argument("--test_data_root", required=True)
    p.add_argument("--test_accel_dir", required=True)
    p.add_argument("--batch_size", type=int, default=1)
    p.add_argument("--num_workers", type=int, default=0)
    p.add_argument("--device", default="cuda")
    p.add_argument("--out_temps", default="train_output/fusion_pipeline_logs/expert_temps.npy")
    p.add_argument("--stageB_weights", default="")
    args = p.parse_args()

    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    print(f"[INFO] 设备: {device}")

    val_loader = make_loader(args.val_list_path, args.val_data_root, args.val_accel_dir, args.batch_size, args.num_workers)
    test_loader = make_loader(args.test_list_path, args.test_data_root, args.test_accel_dir, args.batch_size, args.num_workers)

    print("[INFO] 提取验证集 logits（用于拟合温度）...")
    val_logits, val_labels = collect_logits_sequential(args.checkpoints, val_loader, device, tta_num_augments=1)
    temps = fit_temps(val_logits, val_labels)
    os.makedirs(os.path.dirname(args.out_temps), exist_ok=True)
    np.save(args.out_temps, temps)
    print(f"[INFO] 温度已保存: {args.out_temps}")

    print("[INFO] 提取测试集 logits（用于最终评估）...")
    test_logits, test_labels = collect_logits_sequential(args.checkpoints, test_loader, device, tta_num_augments=1)

    # equal fusion
    eq = test_logits.mean(axis=1)
    m_eq = metrics(eq, test_labels)
    print(f"[BASE] Acc={m_eq['accuracy']:.4f} Prec={m_eq['precision']:.4f} Rec={m_eq['recall']:.4f} F1={m_eq['f1']:.4f}")

    # temperature-scaled equal fusion
    scaled = test_logits / temps[None, :, None]
    eq_t = scaled.mean(axis=1)
    m_eq_t = metrics(eq_t, test_labels)
    print(f"[TEMP-EQ] Acc={m_eq_t['accuracy']:.4f} Prec={m_eq_t['precision']:.4f} Rec={m_eq_t['recall']:.4f} F1={m_eq_t['f1']:.4f}")

    if args.stageB_weights and os.path.exists(args.stageB_weights):
        w = np.load(args.stageB_weights)
        b = (test_logits * w[None, :, :]).sum(axis=1)
        mb = metrics(b, test_labels)
        bt = (scaled * w[None, :, :]).sum(axis=1)
        mbt = metrics(bt, test_labels)
        print(f"[STAGEB] Acc={mb['accuracy']:.4f} Prec={mb['precision']:.4f} Rec={mb['recall']:.4f} F1={mb['f1']:.4f}")
        print(f"[TEMP+STAGEB] Acc={mbt['accuracy']:.4f} Prec={mbt['precision']:.4f} Rec={mbt['recall']:.4f} F1={mbt['f1']:.4f}")


if __name__ == "__main__":
    main()

