import argparse
from typing import Dict
import torch
import torch.distributed as dist
from torch.utils.data import DataLoader
from .dataset import VideoDataset


def setup_arg_parser(parser: argparse.ArgumentParser):
    parser.add_argument('--train_list_path', type=str, help='path to training data list')
    parser.add_argument('--val_list_path', type=str, help='path to validation data list')
    parser.add_argument('--train_data_root', type=str, help='training samples root directory')
    parser.add_argument('--val_data_root', type=str, help='validation samples root directory')
    parser.add_argument('--data_root', type=str, default='', help='training and validation samples root directory')
    parser.add_argument('--batch_size', type=int, help='training batch size on all GPUs')
    parser.add_argument('--num_frames', type=int, default=8, help='number of frames used for each view')
    parser.add_argument('--sampling_rate', type=int, default=16, help='temporal stride for frame sampling')
    parser.add_argument(
        '--frame_sampling_strategy',
        type=str,
        default='default',
        choices=['default', 'sparse'],
        help='default=128帧后模型采样; sparse=TSN稀疏时序采样(每段1帧,共num_frames帧)',
    )
    parser.add_argument('--spatial_size', type=int, default=224, help='frame height and width in pixels')
    parser.add_argument('--mean', type=float, nargs='+', help='pixel mean used to normalize the image')
    parser.add_argument('--std', type=float, nargs='+', help='pixel std used to normalize the image')
    parser.add_argument('--num_workers', type=int, default=1, help='number of DataLoader worker threads')
    parser.add_argument('--dummy_dataset', action='store_true', help='use fake datasets that generate all 0')
    parser.add_argument('--auto_augment', type=str, help='auto augment configuration')
    parser.add_argument('--interpolation', type=str, default='bicubic', help='interpolation mode')
    parser.add_argument('--mirror', action='store_false', dest='mirror', help='disable mirror for training')
    parser.set_defaults(mirror=True)
#    parser.add_argument('--accel_input_dim', type=int, default=9, help='input dimension of accelerometer data')


def _parse_mean_and_std(args: argparse.Namespace) -> Dict[str, torch.Tensor]:
    def parse_mean_or_std(arg, default_value):
        if arg is None:
            return torch.Tensor([default_value] * 3)
        elif len(arg) == 1:
            return torch.Tensor(arg * 3)
        elif len(arg) == 3:
            return torch.Tensor(arg)
        else:
            raise NotImplementedError()

    return {'mean': parse_mean_or_std(args.mean, 0.45), 'std': parse_mean_or_std(args.std, 0.225)}


def create_train_dataset(args: argparse.Namespace,resume_step=None) -> VideoDataset:
    return VideoDataset(
        list_path=args.train_list_path,
        data_root=args.train_data_root,
        accel_data_root=args.accel_train_dir,  # 确保传递 accel_data_root 参数
        num_frames=args.num_frames,
        sampling_rate=args.sampling_rate,
        spatial_size=args.spatial_size,
        mean=args.mean,
        std=args.std,
        auto_augment=args.auto_augment,
        interpolation=args.interpolation,
        mirror=args.mirror,
        train=True,
        perturb_type=getattr(args, 'perturb_type', None),
        perturb_value=getattr(args, 'perturb_value', None),
        frame_sampling_strategy=getattr(args, 'frame_sampling_strategy', 'default'),
    )


def create_train_loader(args: argparse.Namespace,resume_step=None) -> DataLoader:
    dataset = create_train_dataset(args)
    return DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=True
    )


def create_val_dataset(args: argparse.Namespace) -> VideoDataset:
    return VideoDataset(
        list_path=args.val_list_path,
        data_root=args.val_data_root,
        accel_data_root=args.accel_val_dir,  # 确保传递 accel_data_root 参数
        num_frames=args.num_frames,
        sampling_rate=args.sampling_rate,
        spatial_size=args.spatial_size,
        mean=args.mean,
        std=args.std,
        train=False,
        perturb_type=getattr(args, 'perturb_type', None),
        perturb_value=getattr(args, 'perturb_value', None),
        frame_sampling_strategy=getattr(args, 'frame_sampling_strategy', 'default'),
    )


def create_val_loader(args: argparse.Namespace) -> DataLoader:
    dataset = create_val_dataset(args)
    return DataLoader(
        dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True,
        drop_last=False
    )