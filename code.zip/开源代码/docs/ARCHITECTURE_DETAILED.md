# VitaCLIP 架构详细说明文档

本文档详细描述了 VitaCLIP 模型中视频处理、传感器数据处理和数据融合的完整流程，包含数学公式和实现细节。

---

## 目录

1. [视频处理流程](#1-视频处理流程)
2. [传感器数据处理流程](#2-传感器数据处理流程)
3. [数据融合流程](#3-数据融合流程)
4. [整体架构](#4-整体架构)

---

## 1. 视频处理流程

### 1.1 输入预处理

**输入格式**：视频张量 $V \in \mathbb{R}^{B \times C \times T \times H \times W}$

其中：
- $B$：批次大小（batch size）
- $C = 3$：RGB 通道数
- $T$：时间帧数（通常为 8）
- $H, W = 224$：空间分辨率

### 1.2 动态帧采样（可选）

如果启用 `use_dynamic_sample`，使用局部动态帧采样器选择关键帧：

$$\text{indices} = \text{LocalDynamicFrameSampler}(T)$$

$$V' = V[:, :, \text{indices}, :, :]$$

**目的**：自适应选择最具代表性的帧，减少冗余信息。

### 1.3 空间 Patch 嵌入

将视频帧重塑并分割成 patches：

$$V' \in \mathbb{R}^{B \times C \times T \times H \times W} \rightarrow V'' \in \mathbb{R}^{BT \times C \times H \times W}$$

每个帧被分割成 $N = \frac{H}{P} \times \frac{W}{P}$ 个 patches，其中 $P = 16$ 是 patch 大小。

**Patch Embedding**：

$$\mathbf{E}_{\text{patch}} = \text{PatchEmbed}(V'') \in \mathbb{R}^{BT \times N \times D}$$

其中 $D = 768$ 是特征维度。

**公式**：

$$\mathbf{E}_{\text{patch}}[i, j] = \mathbf{W}_{\text{patch}} \cdot \text{Patch}(V''[i, j]) + \mathbf{b}_{\text{patch}}$$

### 1.4 位置编码和 CLS Token

**CLS Token 添加**：

$$\mathbf{E}_{\text{cls}} = \text{Repeat}(\text{CLS}_{\text{token}}, BT) \in \mathbb{R}^{BT \times 1 \times D}$$

$$\mathbf{E} = [\mathbf{E}_{\text{cls}}, \mathbf{E}_{\text{patch}}] \in \mathbb{R}^{BT \times (N+1) \times D}$$

**空间位置编码**：

$$\mathbf{E}_{\text{pos}} = \mathbf{E} + \mathbf{P}_{\text{spatial}}$$

其中 $\mathbf{P}_{\text{spatial}} \in \mathbb{R}^{(N+1) \times D}$ 是可学习的位置编码。

### 1.5 时序编码

**时序位置编码**：

$$\mathbf{E}_{\text{temp}} = \text{TemporalEncoding}(\mathbf{E}_{\text{pos}}, T, B)$$

具体实现：

$$\mathbf{E}_{\text{temp}}[b, t, n, d] = \mathbf{E}_{\text{pos}}[b, t, n, d] + \mathbf{P}_{\text{time}}[t, d]$$

其中 $\mathbf{P}_{\text{time}} \in \mathbb{R}^{T \times D}$ 是时序位置编码：

$$\mathbf{P}_{\text{time}}[t, 2i] = \sin\left(\frac{t}{10000^{2i/D}}\right)$$

$$\mathbf{P}_{\text{time}}[t, 2i+1] = \cos\left(\frac{t}{10000^{2i/D}}\right)$$

### 1.6 Transformer 编码器

经过 Layer Normalization 后，输入到多层 Transformer 编码器：

$$\mathbf{E}_{\text{norm}} = \text{LayerNorm}(\mathbf{E}_{\text{temp}})$$

**Transformer Block**（共 $L = 12$ 层）：

对于每一层 $l = 1, 2, \ldots, L$：

$$\mathbf{E}^{(l)} = \text{TransformerBlock}^{(l)}(\mathbf{E}^{(l-1)})$$

**Multi-Head Self-Attention (MHA)**：

$$\text{Attention}(\mathbf{Q}, \mathbf{K}, \mathbf{V}) = \text{softmax}\left(\frac{\mathbf{Q}\mathbf{K}^T}{\sqrt{D_h}}\right)\mathbf{V}$$

其中 $D_h = D / H$，$H = 12$ 是注意力头数。

**前馈网络 (FFN)**：

$$\text{FFN}(\mathbf{x}) = \text{GELU}(\mathbf{x}\mathbf{W}_1 + \mathbf{b}_1)\mathbf{W}_2 + \mathbf{b}_2$$

其中 $\mathbf{W}_1 \in \mathbb{R}^{D \times 4D}$，$\mathbf{W}_2 \in \mathbb{R}^{4D \times D}$。

### 1.7 CLS Token 提取

从 Transformer 输出中提取 CLS tokens：

$$\mathbf{V}_{\text{tokens}} = \mathbf{E}^{(L)}[:, 0, :] \in \mathbb{R}^{BT \times D}$$

重塑为时序格式：

$$\mathbf{V}_{\text{tokens}} \in \mathbb{R}^{BT \times D} \rightarrow \mathbf{V}_{\text{cls}} \in \mathbb{R}^{B \times T \times D}$$

### 1.8 双路径时空注意力（可选）

如果启用 `use_dual_path_attention`，应用双路径时空注意力：

$$\mathbf{V}_{\text{cls}}' = \text{DualPathSpatioTemporalAttention}(\mathbf{V}_{\text{cls}})$$

**双路径机制**：

- **空间路径**：处理同一时刻不同空间位置的关系
- **时序路径**：处理同一空间位置不同时刻的关系

**融合方法**（根据 `dual_path_fusion_method`）：

- **Gate 融合**：
  $$\mathbf{V}_{\text{fused}} = \alpha \odot \mathbf{V}_{\text{spatial}} + (1 - \alpha) \odot \mathbf{V}_{\text{temporal}}$$

- **Add 融合**：
  $$\mathbf{V}_{\text{fused}} = \mathbf{V}_{\text{spatial}} + \mathbf{V}_{\text{temporal}}$$

- **Concat 融合**：
  $$\mathbf{V}_{\text{fused}} = \text{Concat}(\mathbf{V}_{\text{spatial}}, \mathbf{V}_{\text{temporal}})$$

### 1.9 特征金字塔（可选）

如果启用 `use_pyramid`，应用全局特征金字塔：

$$\mathbf{V}_{\text{pyramid}} = \text{GlobalFeaturePyramid}(\mathbf{V}_{\text{cls}}')$$

$$\mathbf{V}_{\text{pyramid}} = \frac{1}{K}\sum_{k=1}^{K} \mathbf{V}_{\text{pyramid}}^{(k)}$$

### 1.10 关键帧预测（可选）

如果启用 `use_keyframe`，预测每帧的重要性分数：

$$\mathbf{s}_{\text{key}} = \text{KeyFramePredictor}(\mathbf{V}_{\text{cls}}) \in \mathbb{R}^{B \times T}$$

### 1.11 输出

**最终视频特征**：

$$\mathbf{V}_{\text{tokens}} \in \mathbb{R}^{B \times T \times D}$$

其中：
- $B$：批次大小
- $T$：时间帧数（通常为 8）
- $D = 768$：特征维度

**可选输出**（如果启用 `use_keyframe`）：

$$\mathbf{s}_{\text{key}} \in \mathbb{R}^{B \times T}$$

每帧的重要性分数。

**返回值**：
```python
return cls_tokens, key_score
# cls_tokens: [B, T, D] - 视频特征tokens
# key_score: [B, T] 或 None - 关键帧分数（可选）
```

---

## 2. 传感器数据处理流程

### 2.1 输入预处理

**输入格式**：加速度计数据 $\mathbf{A} \in \mathbb{R}^{B \times L \times C}$

其中：
- $B$：批次大小
- $L$：时间序列长度（通常为 256）
- $C = 9$：传感器通道数（3轴加速度 × 3轴陀螺仪，或更多维度）

### 2.2 数据增强（训练时）

如果启用数据增强，应用以下变换：

**时间裁剪**：
$$\mathbf{A}' = \mathbf{A}[\text{start}:\text{start} + L_{\text{crop}}]$$

**时间扭曲**：
$$\mathbf{A}'' = \text{Interpolate}(\mathbf{A}', L_{\text{new}})$$

其中 $L_{\text{new}} = L_{\text{crop}} \times \text{warp\_ratio}$。

**添加噪声**：
$$\mathbf{A}''' = \mathbf{A}'' + \epsilon, \quad \epsilon \sim \mathcal{N}(0, \sigma^2)$$

**随机缩放和偏移**：
$$\mathbf{A}''' = \mathbf{A}''' \times s + \delta$$

其中 $s \sim \mathcal{U}(0.95, 1.05)$，$\delta \sim \mathcal{U}(-0.1, 0.1)$。

**时间翻转**（概率 $p = 0.2$）：
$$\mathbf{A}_{\text{final}} = \text{Flip}(\mathbf{A}''')$$

### 2.3 Tokenization（标记化）

将原始传感器数据转换为嵌入向量：

$$\mathbf{A}_{\text{flat}} = \mathbf{A} \in \mathbb{R}^{B \times L \times C} \rightarrow \mathbf{A}_{\text{flat}} \in \mathbb{R}^{BL \times C}$$

**线性投影**：

$$\mathbf{E}_{\text{accel}} = \mathbf{A}_{\text{flat}} \mathbf{W}_{\text{token}} + \mathbf{b}_{\text{token}}$$

其中：
- $\mathbf{W}_{\text{token}} \in \mathbb{R}^{C \times D}$
- $\mathbf{b}_{\text{token}} \in \mathbb{R}^{D}$
- $D = 768$ 是嵌入维度

**重塑**：

$$\mathbf{E}_{\text{accel}} \in \mathbb{R}^{BL \times D} \rightarrow \mathbf{E}_{\text{accel}} \in \mathbb{R}^{B \times L \times D}$$

### 2.4 位置编码

**正弦位置编码**：

$$\mathbf{P}_{\text{pos}}[l, 2i] = \sin\left(\frac{l}{10000^{2i/D}}\right)$$

$$\mathbf{P}_{\text{pos}}[l, 2i+1] = \cos\left(\frac{l}{10000^{2i/D}}\right)$$

**添加位置编码**：

$$\mathbf{E}_{\text{pos}} = \mathbf{E}_{\text{accel}} + \mathbf{P}_{\text{pos}}$$

### 2.5 Transformer 编码器

**输入重塑**（Transformer 需要 seq-first 格式）：

$$\mathbf{E}_{\text{pos}} \in \mathbb{R}^{B \times L \times D} \rightarrow \mathbf{E}_{\text{seq}} \in \mathbb{R}^{L \times B \times D}$$

**多层 Transformer 编码**（共 $L_{\text{accel}} = 6$ 层）：

对于每一层 $l = 1, 2, \ldots, L_{\text{accel}}$：

$$\mathbf{E}^{(l)} = \text{TransformerEncoderLayer}^{(l)}(\mathbf{E}^{(l-1)})$$

**Self-Attention**：

$$\text{SelfAttention}(\mathbf{E}) = \text{softmax}\left(\frac{\mathbf{E}\mathbf{W}_Q(\mathbf{E}\mathbf{W}_K)^T}{\sqrt{D_h}}\right)\mathbf{E}\mathbf{W}_V$$

其中：
- $\mathbf{W}_Q, \mathbf{W}_K, \mathbf{W}_V \in \mathbb{R}^{D \times D}$
- $D_h = D / H_{\text{accel}}$，$H_{\text{accel}} = 8$ 是注意力头数

**残差连接和层归一化**：

$$\mathbf{E}^{(l)} = \text{LayerNorm}(\mathbf{E}^{(l-1)} + \text{SelfAttention}(\mathbf{E}^{(l-1)}))$$

$$\mathbf{E}^{(l)} = \text{LayerNorm}(\mathbf{E}^{(l)} + \text{FFN}(\mathbf{E}^{(l)}))$$

**前馈网络**：

$$\text{FFN}(\mathbf{x}) = \text{GELU}(\mathbf{x}\mathbf{W}_1 + \mathbf{b}_1)\mathbf{W}_2 + \mathbf{b}_2$$

其中 $\mathbf{W}_1 \in \mathbb{R}^{D \times 2048}$，$\mathbf{W}_2 \in \mathbb{R}^{2048 \times D}$。

### 2.6 上下文感知模块（可选）

如果启用 `use_context`，应用上下文感知模块：

$$\mathbf{A}_{\text{context}} = \text{ContextAwareModule}(\mathbf{E}^{(L_{\text{accel}})})$$

$$\mathbf{A}_{\text{context}} = \mathbf{E}^{(L_{\text{accel}})} + \text{Context}(\mathbf{E}^{(L_{\text{accel}})})$$

### 2.7 输出重塑

**最终传感器特征**：

$$\mathbf{A}_{\text{tokens}} \in \mathbb{R}^{B \times L \times D}$$

其中：
- $B$：批次大小
- $L$：时间序列长度（通常为 256）
- $D = 768$：特征维度

**返回值**：
```python
return src  # [B, L, D] - 传感器特征tokens
```

---

## 3. 数据融合流程

### 3.1 输入特征

**视频特征**：$\mathbf{V} \in \mathbb{R}^{B \times T \times D}$

**传感器特征**：$\mathbf{A} \in \mathbb{R}^{B \times L \times D}$

### 3.2 特征聚合（预处理）

**视频特征聚合**（时间维度平均）：

$$\bar{\mathbf{V}} = \frac{1}{T}\sum_{t=1}^{T} \mathbf{V}[:, t, :] \in \mathbb{R}^{B \times D}$$

**传感器特征聚合**（时间维度平均）：

$$\bar{\mathbf{A}} = \frac{1}{L}\sum_{l=1}^{L} \mathbf{A}[:, l, :] \in \mathbb{R}^{B \times D}$$

### 3.3 双向动态交叉注意力（可选）

如果启用 `use_cross_attn`，应用双向动态交叉注意力。

#### 3.3.1 动态缩放

**视频特征动态缩放**：

$$\mathbf{V}_{\text{scaled}} = \text{DynamicScaling}(\text{LayerNorm}(\bar{\mathbf{V}}))$$

$$\mathbf{V}_{\text{scaled}} = \bar{\mathbf{V}} \odot \sigma(\text{MLP}(\bar{\mathbf{V}}))$$

其中 $\sigma$ 是 Sigmoid 函数。

**传感器特征动态缩放**：

$$\mathbf{A}_{\text{scaled}} = \text{DynamicScaling}(\text{LayerNorm}(\bar{\mathbf{A}}))$$

$$\mathbf{A}_{\text{scaled}} = \bar{\mathbf{A}} \odot \sigma(\text{MLP}(\bar{\mathbf{A}}))$$

#### 3.3.2 视频到传感器的交叉注意力

**扩展视频特征**：

$$\mathbf{V}_{\text{expanded}} = \text{Expand}(\mathbf{V}_{\text{scaled}}, L) \in \mathbb{R}^{B \times L \times D}$$

$$\mathbf{V}_{\text{expanded}}[:, l, :] = \mathbf{V}_{\text{scaled}} \quad \forall l \in [1, L]$$

**交叉注意力**：

$$\mathbf{V}2\mathbf{A} = \text{MultiHeadAttention}(\mathbf{Q} = \mathbf{A}_{\text{scaled}}, \mathbf{K} = \mathbf{V}_{\text{expanded}}, \mathbf{V} = \mathbf{V}_{\text{expanded}})$$

$$\mathbf{V}2\mathbf{A} = \text{softmax}\left(\frac{\mathbf{A}_{\text{scaled}}\mathbf{W}_Q(\mathbf{V}_{\text{expanded}}\mathbf{W}_K)^T}{\sqrt{D_h}}\right)\mathbf{V}_{\text{expanded}}\mathbf{W}_V$$

**聚合**：

$$\mathbf{V}2\mathbf{A}_{\text{final}} = \frac{1}{L}\sum_{l=1}^{L} \mathbf{V}2\mathbf{A}[:, l, :] \in \mathbb{R}^{B \times D}$$

#### 3.3.3 传感器到视频的交叉注意力

**扩展传感器特征**：

$$\mathbf{A}_{\text{expanded}} = \text{Expand}(\mathbf{A}_{\text{scaled}}, T) \in \mathbb{R}^{B \times T \times D}$$

$$\mathbf{A}_{\text{expanded}}[:, t, :] = \mathbf{A}_{\text{scaled}} \quad \forall t \in [1, T]$$

**交叉注意力**：

$$\mathbf{A}2\mathbf{V} = \text{MultiHeadAttention}(\mathbf{Q} = \mathbf{V}_{\text{scaled}}, \mathbf{K} = \mathbf{A}_{\text{expanded}}, \mathbf{V} = \mathbf{A}_{\text{expanded}})$$

$$\mathbf{A}2\mathbf{V} = \text{softmax}\left(\frac{\mathbf{V}_{\text{scaled}}\mathbf{W}_Q(\mathbf{A}_{\text{expanded}}\mathbf{W}_K)^T}{\sqrt{D_h}}\right)\mathbf{A}_{\text{expanded}}\mathbf{W}_V$$

**聚合**：

$$\mathbf{A}2\mathbf{V}_{\text{final}} = \frac{1}{T}\sum_{t=1}^{T} \mathbf{A}2\mathbf{V}[:, t, :] \in \mathbb{R}^{B \times D}$$

### 3.4 自适应门控融合（可选）

如果启用 `use_gate`，应用自适应门控融合。

#### 3.4.1 特征拼接

$$\mathbf{Z} = \text{Concat}(\mathbf{V}2\mathbf{A}_{\text{final}}, \mathbf{A}2\mathbf{V}_{\text{final}}) \in \mathbb{R}^{B \times 2D}$$

#### 3.4.2 自适应权重计算

$$\alpha = \sigma(\text{MLP}(\mathbf{Z})) \in \mathbb{R}^{B \times 1}$$

其中 MLP 结构为：

$$\mathbf{h}_1 = \text{ReLU}(\mathbf{Z}\mathbf{W}_1 + \mathbf{b}_1) \in \mathbb{R}^{B \times 64}$$

$$\alpha = \sigma(\mathbf{h}_1\mathbf{W}_2 + \mathbf{b}_2) \in \mathbb{R}^{B \times 1}$$

#### 3.4.3 加权融合

$$\mathbf{F}_{\text{fused}} = \alpha \odot \mathbf{V}2\mathbf{A}_{\text{final}} + (1 - \alpha) \odot \mathbf{A}2\mathbf{V}_{\text{final}} \in \mathbb{R}^{B \times D}$$

**逐元素公式**：

$$F_{\text{fused}}[b, d] = \alpha[b] \cdot V2A_{\text{final}}[b, d] + (1 - \alpha[b]) \cdot A2V_{\text{final}}[b, d]$$

### 3.5 简单融合（备用方案）

如果未启用交叉注意力和门控融合，使用简单平均：

$$\mathbf{F}_{\text{fused}} = \frac{1}{2}(\bar{\mathbf{V}} + \bar{\mathbf{A}}) \in \mathbb{R}^{B \times D}$$

### 3.6 分类头

**最终分类**：

$$\mathbf{y} = \mathbf{F}_{\text{fused}}\mathbf{W}_{\text{cls}} + \mathbf{b}_{\text{cls}} \in \mathbb{R}^{B \times N_{\text{classes}}}$$

其中 $N_{\text{classes}} = 6$（brushing, drinking, eating, fighting, standing, walking）。

**概率输出**：

$$\mathbf{p} = \text{softmax}(\mathbf{y}) \in \mathbb{R}^{B \times N_{\text{classes}}}$$

$$p_i = \frac{\exp(y_i)}{\sum_{j=1}^{N_{\text{classes}}} \exp(y_j)}$$

---

## 4. 整体架构

### 4.1 完整前向传播流程

$$\mathbf{V}_{\text{input}} \in \mathbb{R}^{B \times C \times T \times H \times W} \xrightarrow{\text{视频编码器}} \mathbf{V}_{\text{tokens}} \in \mathbb{R}^{B \times T \times D}$$

$$\mathbf{A}_{\text{input}} \in \mathbb{R}^{B \times L \times C} \xrightarrow{\text{传感器编码器}} \mathbf{A}_{\text{tokens}} \in \mathbb{R}^{B \times L \times D}$$

$$\mathbf{V}_{\text{tokens}}, \mathbf{A}_{\text{tokens}} \xrightarrow{\text{特征聚合}} \bar{\mathbf{V}}, \bar{\mathbf{A}} \in \mathbb{R}^{B \times D}$$

$$\bar{\mathbf{V}}, \bar{\mathbf{A}} \xrightarrow{\text{交叉注意力}} \mathbf{V}2\mathbf{A}, \mathbf{A}2\mathbf{V} \in \mathbb{R}^{B \times D}$$

$$\mathbf{V}2\mathbf{A}, \mathbf{A}2\mathbf{V} \xrightarrow{\text{自适应融合}} \mathbf{F}_{\text{fused}} \in \mathbb{R}^{B \times D}$$

$$\mathbf{F}_{\text{fused}} \xrightarrow{\text{分类头}} \mathbf{y} \in \mathbb{R}^{B \times N_{\text{classes}}}$$

### 4.2 关键参数

| 参数 | 值 | 说明 |
|------|-----|------|
| $B$ | 2-32 | 批次大小 |
| $T$ | 8 | 视频帧数 |
| $L$ | 256 | 传感器序列长度 |
| $H, W$ | 224 | 视频空间分辨率 |
| $P$ | 16 | Patch 大小 |
| $D$ | 768 | 特征维度 |
| $H_{\text{vid}}$ | 12 | 视频注意力头数 |
| $H_{\text{accel}}$ | 8 | 传感器注意力头数 |
| $L_{\text{vid}}$ | 12 | 视频 Transformer 层数 |
| $L_{\text{accel}}$ | 6 | 传感器 Transformer 层数 |
| $N_{\text{classes}}$ | 6 | 分类类别数 |

### 4.3 损失函数

**组合损失函数**（Combined Loss）：

$$\mathcal{L}_{\text{total}} = \mathcal{L}_{\text{focal}} + \lambda_{\text{dice}} \cdot \mathcal{L}_{\text{dice}}$$

**Focal Loss**：

$$\mathcal{L}_{\text{focal}} = -\sum_{i=1}^{N_{\text{classes}}} \alpha_i (1 - p_i)^{\gamma} \log(p_i)$$

其中：
- $\alpha_i$：类别权重
- $\gamma = 2.5$：聚焦参数
- $p_i$：预测概率

**Tversky Loss**（用于提升 Precision）：

$$\mathcal{L}_{\text{tversky}} = 1 - \frac{TP}{TP + \alpha \cdot FP + \beta \cdot FN}$$

其中 $\alpha = 0.8$，$\beta = 0.2$。

---

## 5. 总结

VitaCLIP 模型通过以下关键设计实现了多模态行为识别：

1. **视频编码器**：使用 Vision Transformer 架构，支持动态帧采样、双路径时空注意力和特征金字塔。
2. **传感器编码器**：使用 Transformer 编码器处理时序传感器数据，支持上下文感知。
3. **多模态融合**：通过双向动态交叉注意力和自适应门控机制，实现视频和传感器特征的深度融合。

整个架构的设计充分考虑了视频和传感器数据的特性，通过端到端的训练实现了高效的行为分类。

---

## 参考文献

- Vision Transformer (ViT)
- CLIP (Contrastive Language-Image Pre-training)
- Transformer Architecture
- Multi-modal Fusion

