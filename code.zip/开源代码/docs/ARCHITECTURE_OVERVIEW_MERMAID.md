# Overall Architecture (Beef-6 Project)

> 可直接在支持 Mermaid 的 Markdown 渲染器中查看。  
> 结构依据项目当前代码：`training/BehaviorCLIP_model.py`、`training/BehaviorCLIP_vision_encoder.py`、`training/Accelerometer_Encoder.py`、`training/BiDirectionalDynamicCrossAttention.py`、`fusion_run_guide/fusion_pipeline.py`。

```mermaid
flowchart LR
    %% =========================
    %% Input & Data Pipeline
    %% =========================
    subgraph A[Input and Data Pipeline]
        I1[Video CSV Path]
        I2[Accel CSV Path]
        I3[Label 1..6]
        D1[Video Decode and Frame Sampling]
        D2[Resize and Normalize]
        D3[Accel Read xlsx]
        D4[Pad or Truncate to 256]
        I1 --> D1 --> D2
        I2 --> D3 --> D4
        I3 --> LBL[Label to 0..5]
    end

    %% =========================
    %% Vision Branch
    %% =========================
    subgraph B[Vision Branch]
        V1[ImagePatchEmbed2D]
        V2[Transformer Blocks]
        V3[LocalDynamicFrameSampler optional]
        V4[DualPathSpatioTemporalAttention optional]
        V5[GlobalFeaturePyramid optional]
        V6[CLS or Mean Tokens]
        D2 --> V1 --> V2 --> V3 --> V4 --> V5 --> V6
    end

    %% =========================
    %% Sensor Branch
    %% =========================
    subgraph C[Sensor Branch]
        S1[Tokenizer]
        S2[Positional Encoding]
        S3[Transformer Encoder Layers]
        S4[ContextAwareModule]
        S5[Sensor Tokens]
        D4 --> S1 --> S2 --> S3 --> S4 --> S5
    end

    %% =========================
    %% Cross-Modal Interaction
    %% =========================
    subgraph D[Cross Modal Interaction and Fusion]
        F1[BiDirectionalDynamicCrossAttention]
        F2[Video to Accel Attention]
        F3[Accel to Video Attention]
        F4[AdaptiveGate alpha]
        F5[Fused Feature]
        V6 --> F1
        S5 --> F1
        F1 --> F2
        F1 --> F3
        F2 --> F4
        F3 --> F4
        F4 --> F5
    end

    %% =========================
    %% Single Model Head
    %% =========================
    subgraph E[Single Model Classification]
        H1[Linear Classifier]
        H2[Logits C equals 6]
        H3[Loss CE or Focal or Combined]
        F5 --> H1 --> H2
        H2 --> H3
        LBL --> H3
    end

    %% =========================
    %% Multi-Expert Ensemble
    %% =========================
    subgraph F[Ensemble and Fusion Stages]
        M1[Expert1 ... Expert6 Checkpoints]
        M2[Per Expert Inference]
        M3[Stacked Logits N x K x C]
        M4[StageA Global Weights]
        M5[StageB Per Class Weights]
        M6[StageC Samplewise MoE Gating]
        M7[Final Prediction and Metrics]
        M1 --> M2 --> M3
        M3 --> M4 --> M7
        M3 --> M5 --> M7
        M3 --> M6 --> M7
    end

    %% Connections from single model to ensemble
    H2 --> M2
```

## Diagram Block Mapping (to your reference style)

- Input Image/Data: `A`
- ViT-like main branch: `B`
- Auxiliary modality branch: `C`
- Fusion modules: `D`
- Detection/Classification head: `E`
- Multi-stage fusion result: `F`

## Suggested Figure Caption

Unified architecture of the Beef-6 multimodal recognition system. Video and accelerometer streams are encoded by dual branches, aligned through bidirectional cross-attention and adaptive gating, then trained as single experts and further fused by a three-stage ensemble pipeline (global, per-class, and sample-wise MoE).
