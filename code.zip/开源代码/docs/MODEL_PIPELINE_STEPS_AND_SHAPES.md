# 模型全流程步骤与维度（可直接用于画总体结构图）

本文档按“输入 -> 模块 -> 输出”列出每一步，并给出张量维度。  
依据代码：`video_dataset/dataset.py`、`training/BehaviorCLIP_model.py`、`training/BehaviorCLIP_vision_encoder.py`、`training/Accelerometer_Encoder.py`、`training/BiDirectionalDynamicCrossAttention.py`、`fusion_run_guide/fusion_pipeline.py`。

---

## 1) 维度符号说明（先统一口径）

- `B`: batch size（默认推理常见为 4）
- `T_in`: 输入视频时间长度（数据集侧）
- `T_v`: 视觉分支内部时间长度（动态采样后）
- `H, W`: 输入分辨率（默认 `224 x 224`）
- `p`: patch size（默认 `16`）
- `N`: 每帧 patch 数（`(H/p) * (W/p)`，默认 `14*14=196`）
- `C_v`: 视觉特征维（默认 `768`）
- `L`: 加速度时间长度（固定 `256`）
- `C_a_in`: 加速度输入维（默认 `9`）
- `C_a`: 加速度编码维（默认 `768`）
- `K`: 专家数（本项目常用 `6`）
- `C_cls`: 分类数（默认 `6`）

默认参数下：
- `T_in = num_frames * sampling_rate = 8 * 16 = 128`
- 若启用动态帧采样（`use_dynamic_sample=True`），则 `T_v <= 128`（具体由采样器决定）。

---

## 2) 单专家模型（VitaCLIP）从输入到输出

### Step A: 数据读取与预处理

1. **读取视频与传感器**
   - 输入：CSV 一行 `video_path, accel_path, label`
   - 模块：`VideoDataset.__getitem__`
   - 输出：
     - `video_raw`: 原始帧序列
     - `accel_raw`: 原始传感器序列
     - `label`: `1..6` 映射到 `0..5`

2. **视频采样 + 归一化 + resize**
   - 模块：`dataset.py` 中采样/normalize/resize
   - 输出张量：`video`
   - 维度：`[B, 3, T_in, 224, 224]`
   - 默认实例：`[B, 3, 128, 224, 224]`

3. **传感器读取 + 定长化**
   - 模块：`_load_accel()`，读取 xlsx 第 1:10 列并 pad/truncate 到 256
   - 输出张量：`accel`
   - 维度：`[B, L, C_a_in] = [B, 256, 9]`

---

### Step B: 视觉分支（`CLIPVisionEncoder.forward_tokens`）

4. **可选动态帧采样**
   - 条件：`use_dynamic_sample=True`
   - 输入：`[B, 3, T_in, 224, 224]`
   - 输出：`[B, 3, T_v, 224, 224]`

5. **重排为逐帧 batch**
   - 操作：`permute + flatten`
   - 输出：`[B*T_v, 3, 224, 224]`

6. **Patch Embedding**
   - 模块：`ImagePatchEmbed2D`
   - 输出：`[B*T_v, N, C_v] = [B*T_v, 196, 768]`

7. **拼接 cls token + 位置/时间编码**
   - 操作：拼接 `cls` 后 token 数变 `N+1`
   - 输出：`[B*T_v, N+1, C_v] = [B*T_v, 197, 768]`

8. **Transformer 主干（12 层）**
   - 模块：`self.blocks`
   - 输出不变：`[B*T_v, 197, 768]`

9. **提取 cls token 并还原时间轴**
   - 操作：`x[:,0]` + `rearrange`
   - 输出：`v_cls_tokens`
   - 维度：`[B, T_v, 768]`

10. **可选时空增强模块**
   - 双路径时空注意力（推荐主路径）`DualPathSpatioTemporalAttention`
   - 或独立空间/时序注意力（兼容路径）
   - 输出维度保持：`[B, T_v, 768]`

11. **可选金字塔与关键帧**
   - `use_pyramid=True`：输出仍按设计为 `[B, T_v, 768]`
   - `use_keyframe=True`：额外输出 `key_score`（用于辅助）

12. **视觉分支输出**
   - `v_tokens`: `[B, T_v, 768]`

---

### Step C: 传感器分支（`AccelerometerEncoder.forward`）

13. **Tokenizer 投影**
   - 输入：`[B, 256, 9]`
   - 展平再映射后还原
   - 输出：`[B, 256, 768]`

14. **位置编码 + TransformerEncoder(6 层)**
   - 中间会转到 `[L, B, D]` 再转回
   - 输出：`[B, 256, 768]`

15. **可选 ContextAwareModule**
   - 条件：`use_context=True`
   - 输出维度保持：`[B, 256, 768]`

16. **传感器分支输出**
   - `a_tokens`: `[B, 256, 768]`

---

### Step D: 跨模态融合与分类头（`VitaCLIP.forward`）

17. **双向交叉注意力（可选）**
   - 条件：`use_cross_attn=True and use_gate=True`
   - 模块：`BiDirectionalDynamicCrossAttention`
   - 输入：
     - `v_tokens`: `[B, T_v, 768]`（内部先均值池化到 `[B,768]`）
     - `a_tokens`: `[B, 256, 768]`
   - 输出：
     - `v2a`: `[B, 768]`
     - `a2v`: `[B, 768]`

18. **自适应门控融合（可选）**
   - 模块：`AdaptiveGate`
   - 输入：`v2a [B,768]`, `a2v [B,768]`
   - 输出：
     - `fused`: `[B, 768]`
     - `alpha`: `[B, 1]`

19. **若不启用 cross+gate 的后备融合**
   - `fused = (mean(v_tokens, dim=1) + mean(a_tokens, dim=1)) / 2`
   - 输出：`[B, 768]`

20. **分类头**
   - 模块：`Linear(768 -> 6)`
   - 输出：
     - `logits`: `[B, 6]`
     - 训练时 loss 输入：`logits [B,6]` + `labels [B]`

---

## 3) 多专家融合（StageA / StageB / StageC）

该部分用于“总体结构图”的下半部分（专家集成）。

21. **收集各专家 logits**
   - 每个专家输出：`[N, 6]`
   - 堆叠后：`logits_nkc = [N, K, C_cls] = [N, 6, 6]`

22. **StageA 全局静态权重**
   - 权重：`w [K]`
   - 融合：对 `K` 维加权求和
   - 输出：`[N, 6]`

23. **StageB 每类别权重**
   - 权重矩阵：`W [K, C_cls]`
   - 融合：`sum_k logits[:,k,c] * W[k,c]`
   - 输出：`[N, 6]`

24. **StageC 样本级 MoE 门控**
   - 输入特征：将 `logits_nkc` 展平为 `[N, K*C_cls]`（默认 `[N,36]`）
   - `GatingMLP` 输出 gate：`[N, K]`
   - 加权融合输出：`[N, 6]`

25. **最终输出**
   - `pred = argmax([N,6], dim=1)` -> `[N]`
   - 指标：Accuracy / Precision / Recall / F1 / Confusion Matrix / AUC

---

## 4) 一页图建议（你画图时可直接照抄）

建议把总体图分 6 个虚线框：

1. `Input & Preprocess`  
   `Video [B,3,128,224,224]` + `Accel [B,256,9]`

2. `Vision Encoder`  
   `PatchEmbed -> Transformer x12 -> (DualPathAttn opt) -> v_tokens [B,T_v,768]`

3. `Accel Encoder`  
   `Tokenizer -> PosEnc -> Transformer x6 -> Context opt -> a_tokens [B,256,768]`

4. `Cross-Modal Fusion`  
   `BiCrossAttn -> AdaptiveGate -> fused [B,768]`

5. `Classifier`  
   `Linear(768->6) -> logits [B,6]`

6. `Ensemble Stages`  
   `logits [N,K,6] -> StageA/StageB/StageC -> final [N,6] -> metrics`

---

## 5) 备注（画图时避免踩坑）

- 数据集侧 `T_in` 默认是 `8*16=128`，不是 8；模型内部时间编码会按实际 `T` 插值处理。
- 开启动态采样后，`T_v` 会变小（由采样器决定），图中建议写成 `T_v` 而不是固定数字。
- `use_pyramid` 在代码里设计为输入 list 多尺度特征；当前主干调用是单一路径，图里可标为“可选增强模块”。
- 若你只画“当前主跑通配置”，可采用：
  - `use_dynamic_sample=True`
  - `use_keyframe=True`
  - `use_dual_path_attention=True`
  - `use_context=True`
  - `use_cross_attn=True`
  - `use_gate=True`

