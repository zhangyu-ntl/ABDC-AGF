# 模块输出详细说明

本文档详细说明视频处理模块和传感器数据处理模块的最终输出格式。

---

## 1. 视频处理模块输出

### 模块名称
`CLIPVisionEncoder` (位于 `training/BehaviorCLIP_vision_encoder.py`)

### 输出方法
`forward_tokens(self, x: torch.Tensor)`

### 输入格式
$$\mathbf{V}_{\text{input}} \in \mathbb{R}^{B \times C \times T \times H \times W}$$

其中：
- $B$：批次大小（batch size）
- $C = 3$：RGB 通道数
- $T = 8$：时间帧数（可配置）
- $H, W = 224$：空间分辨率

### 输出格式

#### 主输出：视频特征序列（特征张量）

$$\mathbf{V}_{\text{tokens}} \in \mathbb{R}^{B \times T \times D}$$

**术语说明**：
- **特征序列/特征张量**：整个输出是一个3维张量，包含多个特征向量
- **特征向量**：每个时间步的输出是一个 $D$ 维的特征向量

**维度说明**：
- $B$：批次大小
- $T$：时间帧数（通常为 8，如果使用动态帧采样可能变化）
- $D = 768$：特征维度（`feature_dim`）

**详细结构**：
- 整个输出：**特征序列** $\mathbf{V}_{\text{tokens}}$，形状为 $[B, T, D]$
- 每个样本：$T$ 个**特征向量**，每个形状为 $[D]$
- 每个特征向量：从对应帧的 CLS token 提取，包含该帧的全局视觉信息

**物理含义**：
- 每一帧对应一个**特征向量**（从 CLS token 提取）
- 每个**特征向量**包含该帧的全局视觉信息
- 经过 Transformer 编码、双路径注意力、特征金字塔等处理
- 整个**特征序列**保留了时序信息

#### 可选输出：关键帧分数

$$\mathbf{s}_{\text{key}} \in \mathbb{R}^{B \times T} \quad \text{或} \quad \text{None}$$

**条件**：仅在启用 `use_keyframe` 时输出

**维度说明**：
- $B$：批次大小
- $T$：时间帧数

**物理含义**：
- 每帧的重要性分数
- 分数越高，表示该帧越重要
- 可用于后续的关键帧选择或加权

### 代码实现

```python
def forward_tokens(self, x: torch.Tensor):
    # ... 处理过程 ...
    
    # 最终输出
    cls_tokens = ...  # [B, T, D]
    key_score = ...   # [B, T] 或 None
    
    return cls_tokens, key_score
```

### 使用示例

```python
# 在主模型中调用
v_tokens, key_score = self.visual.forward_tokens(video)
# v_tokens: [B, T, D] = [2, 8, 768]
# key_score: [B, T] = [2, 8] 或 None
```

---

## 2. 传感器数据处理模块输出

### 模块名称
`AccelerometerEncoder` (位于 `training/Accelerometer_Encoder.py`)

### 输出方法
`forward(self, src: torch.Tensor)`

### 输入格式
$$\mathbf{A}_{\text{input}} \in \mathbb{R}^{B \times L \times C}$$

其中：
- $B$：批次大小（batch size）
- $L = 256$：时间序列长度（可配置）
- $C = 9$：传感器通道数（3轴加速度 + 3轴陀螺仪，或更多维度）

### 输出格式

#### 主输出：传感器特征序列（特征张量）

$$\mathbf{A}_{\text{tokens}} \in \mathbb{R}^{B \times L \times D}$$

**术语说明**：
- **特征序列/特征张量**：整个输出是一个3维张量，包含多个特征向量
- **特征向量**：每个时间步的输出是一个 $D$ 维的特征向量

**维度说明**：
- $B$：批次大小
- $L$：时间序列长度（通常为 256）
- $D = 768$：特征维度（`accel_d_model`）

**详细结构**：
- 整个输出：**特征序列** $\mathbf{A}_{\text{tokens}}$，形状为 $[B, L, D]$
- 每个样本：$L$ 个**特征向量**，每个形状为 $[D]$
- 每个特征向量：包含对应时间步的传感器信息

**物理含义**：
- 每个时间步对应一个**特征向量**
- 每个**特征向量**包含该时间步的传感器信息
- 经过 Tokenization、位置编码、Transformer 编码、上下文感知等处理
- 整个**特征序列**保留了时序信息

### 代码实现

```python
def forward(self, src):
    # ... 处理过程 ...
    
    # 最终输出
    src = ...  # [B, L, D]
    
    return src
```

### 使用示例

```python
# 在主模型中调用
a_tokens = self.accelerometer(accel)
# a_tokens: [B, L, D] = [2, 256, 768]
```

---

## 3. 输出对比

| 特性 | 视频处理模块 | 传感器数据处理模块 |
|------|------------|------------------|
| **输出变量名** | `v_tokens` | `a_tokens` |
| **输出维度** | $[B, T, D]$ | $[B, L, D]$ |
| **时间维度** | $T = 8$（帧数） | $L = 256$（时间步） |
| **特征维度** | $D = 768$ | $D = 768$ |
| **额外输出** | `key_score`（可选） | 无 |
| **输出类型** | `Tuple[Tensor, Optional[Tensor]]` | `Tensor` |

---

## 4. 在主模型中的使用

### 调用方式

```python
def forward(self, video: torch.Tensor, accel: torch.Tensor):
    # 1. 视频处理
    v_tokens, key_score = self.visual.forward_tokens(video)
    # v_tokens: [B, T, D] = [2, 8, 768]
    
    # 2. 传感器处理
    a_tokens = self.accelerometer(accel)
    # a_tokens: [B, L, D] = [2, 256, 768]
    
    # 3. 特征融合（后续处理）
    # ...
```

### 维度对齐

**问题**：两个模块的时间维度不同（$T = 8$ vs $L = 256$）

**解决方案**：在融合前进行时间维度聚合

```python
# 视频特征：时间维度平均
v_mean = v_tokens.mean(dim=1)  # [B, T, D] -> [B, D]

# 传感器特征：时间维度平均
a_mean = a_tokens.mean(dim=1)  # [B, L, D] -> [B, D]

# 现在两个特征都是 [B, D]，可以融合
```

---

## 5. 输出特征的含义

### 视频特征序列 (`v_tokens`)

**输出类型**：**特征序列**（3维张量），包含 $T$ 个**特征向量**

**每个特征向量包含的信息**：
- ✅ 空间视觉信息（通过 Patch Embedding 和 Transformer）
- ✅ 时序信息（通过时序编码和时序注意力）
- ✅ 全局上下文（通过 CLS token）
- ✅ 多尺度特征（如果启用特征金字塔）

**特点**：
- 每个**特征向量**对应一帧
- 每个**特征向量**经过深度编码，包含丰富的语义信息
- 整个**特征序列**保留了时序关系
- 适合用于行为识别

**示例**：
```python
v_tokens = [[[0.1, 0.2, ..., 0.5],    # 第1帧的特征向量 (768维)
              [0.3, 0.1, ..., 0.7],    # 第2帧的特征向量 (768维)
              ...                      # ... 共8帧
              [0.2, 0.4, ..., 0.6]],   # 第8帧的特征向量 (768维)
             ...]                      # ... 共B个样本
# 形状: [B, T, D] = [2, 8, 768]
```

### 传感器特征序列 (`a_tokens`)

**输出类型**：**特征序列**（3维张量），包含 $L$ 个**特征向量**

**每个特征向量包含的信息**：
- ✅ 加速度和角速度信息（通过 Tokenization）
- ✅ 时序模式（通过位置编码和 Transformer）
- ✅ 上下文信息（如果启用上下文感知模块）

**特点**：
- 每个**特征向量**对应一个时间步
- 高时间分辨率（256 个时间步）
- 每个**特征向量**适合捕获细粒度的运动模式
- 整个**特征序列**保留了时序关系

**示例**：
```python
a_tokens = [[[0.5, 0.3, ..., 0.2],    # 第1个时间步的特征向量 (768维)
              [0.4, 0.6, ..., 0.1],    # 第2个时间步的特征向量 (768维)
              ...                      # ... 共256个时间步
              [0.3, 0.5, ..., 0.4]],   # 第256个时间步的特征向量 (768维)
             ...]                      # ... 共B个样本
# 形状: [B, L, D] = [2, 256, 768]
```

---

## 6. 实际数值示例

假设 `batch_size = 2`：

### 视频处理模块输出

```python
v_tokens.shape = torch.Size([2, 8, 768])
# 2 个样本，每个样本 8 帧，每帧 768 维特征

key_score.shape = torch.Size([2, 8])  # 如果启用
# 2 个样本，每个样本 8 个关键帧分数
```

### 传感器数据处理模块输出

```python
a_tokens.shape = torch.Size([2, 256, 768])
# 2 个样本，每个样本 256 个时间步，每步 768 维特征
```

---

## 7. 总结

### 视频处理模块输出

- **主输出**：`v_tokens` $\in \mathbb{R}^{B \times T \times D}$，视频特征 tokens
- **可选输出**：`key_score` $\in \mathbb{R}^{B \times T}$，关键帧分数
- **特征维度**：$D = 768$
- **时间维度**：$T = 8$（帧数）

### 传感器数据处理模块输出

- **主输出**：`a_tokens` $\in \mathbb{R}^{B \times L \times D}$，传感器特征 tokens
- **特征维度**：$D = 768$
- **时间维度**：$L = 256$（时间步）

### 关键点

1. ✅ 两个模块的输出特征维度相同（$D = 768$），便于融合
2. ✅ 时间维度不同（$T = 8$ vs $L = 256$），需要在融合前聚合
3. ✅ 两个模块的输出都是 token 序列，保留了时序信息
4. ✅ 视频模块有额外的关键帧分数输出（可选）

