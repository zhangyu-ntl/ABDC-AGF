# 训练输出指标说明

## 📊 训练过程中输出的指标

### 1. **训练阶段指标**（每 `print_freq` 步输出）

```
[100] loss=1.2345 top1=25.00% lr=5.00e-05
```

- **loss**: 当前批次的损失值
- **top1**: Top-1准确率（百分比）
- **lr**: 当前学习率

### 2. **评估阶段指标**（每 `eval_freq` 步输出）

#### 2.1 整体指标（Overall Macro Metrics）

```
==========  Overall (Macro) Metrics  ==========
Accuracy  : 0.2524
Precision : 0.2640
Recall    : 0.2524
F1-score  : 0.2108
```

- **Accuracy**: 整体准确率
- **Precision**: 宏平均精确率（Macro Average）
- **Recall**: 宏平均召回率（Macro Average）
- **F1-score**: 宏平均F1分数（Macro Average）

#### 2.2 三种平均指标（Average Metrics）

```
==========  Average Metrics  ==========
      micro avg  P=0.2524  R=0.2524  F1=0.2524
      macro avg  P=0.2640  R=0.2524  F1=0.2108
   weighted avg  P=0.2640  R=0.2524  F1=0.2108
```

- **micro avg**: 微平均（Micro Average）
  - 对所有样本的TP、FP、FN求和后计算
  - 在类别不平衡时，受多数类影响大
  
- **macro avg**: 宏平均（Macro Average）
  - 对每个类别分别计算指标后取平均
  - 每个类别权重相等，适合类别不平衡场景
  
- **weighted avg**: 加权平均（Weighted Average）
  - 按每个类别的样本数量加权平均
  - 考虑类别不平衡

#### 2.3 各类别指标（Per-Class Metrics）

```
==========  Per-Class Metrics  ==========
        brushing  P=0.3594  R=0.0237  F1=0.0445  Support=970
        drinking  P=0.2223  R=0.4299  F1=0.2930  Support=970
          eating  P=0.2748  R=0.5485  F1=0.3661  Support=970
        fighting  P=0.3314  R=0.2348  F1=0.2749  Support=971
        standing  P=0.2202  R=0.2454  F1=0.2321  Support=970
         walking  P=0.1761  R=0.0320  F1=0.0541  Support=970
```

对每个类别输出：
- **P (Precision)**: 精确率
- **R (Recall)**: 召回率
- **F1**: F1分数
- **Support**: 该类别在验证集中的样本数量

类别包括：
- brushing（刷毛）
- drinking（饮水）
- eating（进食）
- fighting（打斗）
- standing（站立）
- walking（行走）

#### 2.4 混淆矩阵（Confusion Matrix）

```
==========  Confusion Matrix  ==========
[[ 23 240 385 100 166  56]
 [  5 417 249  92 186  21]
 [  4 153 532 129 131  21]
 [ 15 437 213 228  71   7]
 [  8 330 283  71 238  40]
 [  9 299 274  68 289  31]]
```

- 6×6矩阵，显示真实标签 vs 预测标签的分布
- 行：真实标签
- 列：预测标签
- 数值：样本数量

同时保存为图片：`train_output/混淆矩阵-2/confusion_matrix_step{step}.png`

#### 2.5 AUC指标

```
==========  AUC  ==========
Macro AUC : 0.6394
Per-class AUC:
  brushing: 0.6389
  drinking: 0.5864
  eating: 0.6805
  fighting: 0.7121
  standing: 0.6036
  walking: 0.6149
```

- **Macro AUC**: 宏平均AUC（所有类别AUC的平均值）
- **Per-class AUC**: 每个类别的AUC值
  - AUC范围：0-1，越接近1越好
  - 0.5表示随机猜测，>0.7表示较好性能

### 3. **最佳模型保存信息**

```
✅ 保存最佳模型 (F1=0.2829, Step=1800)
📊 当前F1=0.2103, 最佳F1=0.2829 (Step=1800)
```

- 当当前F1-score超过历史最佳时，会保存最佳模型
- 显示当前F1和最佳F1及其对应的训练步数

## 📈 指标解读建议

### 重点关注指标

1. **F1-score (Macro)**：主要评估指标
   - 平衡了精确率和召回率
   - 适合类别不平衡场景
   - 目标：逐步提升

2. **各类别F1-score**：检查类别平衡
   - 确保所有类别的F1都>0
   - 如果某个类别F1=0，说明模型完全无法识别该类

3. **Macro AUC**：模型区分能力
   - 反映模型的整体区分能力
   - 通常与F1-score趋势一致

### 指标变化趋势

理想的训练过程：
- ✅ Loss逐步下降
- ✅ Accuracy逐步上升
- ✅ F1-score逐步上升
- ✅ 各类别F1-score都逐步提升
- ✅ Macro AUC逐步上升

## 📝 输出频率

- **训练指标**：每 `print_freq` 步（默认100步）
- **完整评估**：每 `eval_freq` 步（默认200步）
- **模型保存**：每 `save_freq` 步（默认200步）

## 💾 保存的文件

1. **混淆矩阵图片**：`train_output/混淆矩阵-2/confusion_matrix_step{step}.png`
2. **最佳模型**：`train_output/result/best_model.pth`
3. **定期checkpoint**：`train_output/result/checkpoint-{step}.pth`
4. **训练日志**：`train_output/result/train-YYYYMMDD_HHMMSS.log`

