# 多模态肉牛行为识别系统

基于视频和加速度计数据的多模态深度学习模型，用于识别肉牛的6种行为类别。

## 📋 项目简介

本项目实现了一个名为 **VitaCLIP** 的多模态行为识别模型，结合视频视觉信息和加速度计传感器数据，对肉牛的6种行为进行分类：

- **brushing** (刷毛)
- **drinking** (饮水)
- **eating** (进食)
- **fighting** (打斗)
- **standing** (站立)
- **walking** (行走)

## 🏗️ 项目结构

```
mutil-model-所有模块-肉牛6-400跑通版/
├── train-Behavior.py              # 主训练脚本
├── training/                       # 模型训练相关模块
│   ├── BehaviorCLIP_model.py      # VitaCLIP主模型
│   ├── BehaviorCLIP_vision_encoder.py  # 视频编码器
│   ├── Accelerometer_Encoder.py   # 加速度计编码器
│   ├── BiDirectionalDynamicCrossAttention.py  # 双向动态交叉注意力
│   ├── AdaptiveGate.py            # 自适应门控融合
│   ├── DualPathSpatioTemporalAttention.py  # 双路径时空注意力
│   ├── TemporalPositionalContrastiveLearning.py  # 时空对比学习
│   ├── improved_losses.py          # 改进的损失函数
│   ├── checkpoint.py              # 检查点管理
│   └── ...
├── video_dataset/                  # 视频数据集处理
│   ├── dataloader.py              # 数据加载器
│   ├── dataset.py                 # 数据集定义
│   ├── transform.py               # 数据变换
│   └── ...
├── train_scripts/                  # 训练脚本集合
│   ├── cow_train.sh               # 基础训练脚本
│   ├── cow_train_to_96.sh        # 优化训练脚本
│   ├── eval_single_model.sh      # 单模型评估脚本
│   └── ...
├── train_output/                   # 训练输出目录
│   ├── checkpoint/                # 模型检查点
│   ├── result/                    # 训练结果
│   ├── 混淆矩阵/                  # 混淆矩阵可视化
│   └── ...
├── ARCHITECTURE_DETAILED.md        # 架构详细说明
├── MODULE_OUTPUTS.md              # 模块输出说明
├── OUTPUT_METRICS.md              # 输出指标说明
└── README.md                      # 本文件
```

## 🚀 快速开始

### 1. 环境配置

请参考 [环境配置说明文档](环境配置说明-zy虚拟环境.md) 进行虚拟环境 `zy` 的配置。

### 2. 数据准备

确保数据按以下结构组织：

```
behavior/
├── train-video/          # 训练视频目录
├── val-video/            # 验证视频目录
├── train-table/          # 训练加速度计数据目录
├── val-table/            # 验证加速度计数据目录
├── train_balanced.csv    # 训练集列表文件
└── val_balanced.csv      # 验证集列表文件
```

### 3. 训练模型

#### 基础训练

```bash
bash train_scripts/cow_train.sh
```

#### 使用所有模块训练

```bash
bash train_scripts/cow_train_to_96_2gpu.sh
```

#### 自定义训练

```bash
python train-Behavior.py \
    --checkpoint_dir train_output/result-custom \
    --auto_resume \
    --num_steps 10000 \
    --batch_size 2 \
    --lr 1.5e-5 \
    --train_list_path /path/to/train_balanced.csv \
    --val_list_path /path/to/val_balanced.csv \
    --train_data_root /path/to/train-video \
    --val_data_root /path/to/val-video \
    --accel_train_dir /path/to/train-table \
    --accel_val_dir /path/to/val-table \
    --use_dynamic_sample \
    --use_pyramid \
    --use_keyframe \
    --use_context \
    --use_cross_attn \
    --use_gate
```

### 4. 评估模型

```bash
bash train_scripts/eval_single_model.sh
```

或使用Python脚本：

```bash
python train-Behavior.py \
    --eval_only \
    --resume_path /path/to/checkpoint.pth \
    --val_list_path /path/to/val_balanced.csv \
    --val_data_root /path/to/val-video \
    --accel_val_dir /path/to/val-table
```

## 🔧 核心功能模块

### 视频处理模块

- **动态帧采样** (`use_dynamic_sample`): 自适应选择关键帧
- **关键帧预测** (`use_keyframe`): 预测每帧的重要性分数
- **双路径时空注意力** (`use_dual_path_attention`): 同时处理空间和时间信息
- **特征金字塔** (`use_pyramid`): 多尺度特征提取

### 传感器处理模块

- **上下文感知模块** (`use_context`): 增强传感器特征的上下文理解
- **自注意力机制** (`use_accel_self_attn`): 传感器数据内部关系建模
- **数据增强** (`accel_augment`): 传感器数据增强

### 多模态融合模块

- **双向动态交叉注意力** (`use_cross_attn`): 视频和传感器特征的交互融合
- **自适应门控融合** (`use_gate`): 智能权重分配

### 对比学习模块

- **时空对比学习** (`use_contrastive_learning`): 时间-位置对比学习
  - 时间对比 (`use_temporal_contrast`)
  - 位置对比 (`use_positional_contrast`)

## 📊 模型架构

### VitaCLIP 架构概览

```
输入视频 [B, C, T, H, W]  ──┐
                            ├──> 视频编码器 ──> 视频特征 [B, T, D]
输入加速度计 [B, L, C]  ───┘
                            ├──> 加速度计编码器 ──> 传感器特征 [B, L, D]
                            │
                            ├──> 特征聚合 ──> [B, D]
                            │
                            ├──> 双向交叉注意力 ──> [B, D]
                            │
                            └──> 自适应门控融合 ──> [B, D] ──> 分类头 ──> [B, 6]
```

详细架构说明请参考 [ARCHITECTURE_DETAILED.md](ARCHITECTURE_DETAILED.md)

## 📈 训练参数说明

### 基础参数

- `--num_classes`: 分类类别数（默认6）
- `--batch_size`: 批次大小（建议2-4）
- `--batch_split`: 梯度累积步数（用于模拟更大batch）
- `--num_steps`: 训练总步数
- `--lr`: 学习率（建议1e-5到2e-5）
- `--weight_decay`: 权重衰减（默认0.05-0.1）

### 数据参数

- `--num_frames`: 视频帧数（默认8）
- `--spatial_size`: 视频空间分辨率（默认224）
- `--accel_dim`: 加速度计维度（默认9：3轴加速度+3轴陀螺仪）
- `--sampling_rate`: 采样率（默认16）

### 模型参数

- `--accel_num_layers`: 加速度计编码器层数（默认6）
- `--accel_d_model`: 特征维度（默认768）
- `--accel_nhead`: 注意力头数（默认8）

### 模块开关

#### 视频模块
- `--use_dynamic_sample`: 启用动态帧采样
- `--use_keyframe`: 启用关键帧预测
- `--use_spatial`: 启用空间注意力
- `--use_temporal`: 启用时序注意力
- `--use_pyramid`: 启用特征金字塔

#### 传感器模块
- `--use_context`: 启用上下文感知模块
- `--use_accel_self_attn`: 启用传感器自注意力
- `--accel_augment`: 启用传感器数据增强

#### 融合模块
- `--use_cross_attn`: 启用双向交叉注意力
- `--use_gate`: 启用自适应门控融合

#### 对比学习
- `--use_contrastive_learning`: 启用对比学习
- `--contrastive_temperature`: 对比学习温度（默认0.07）
- `--contrastive_loss_weight`: 对比学习损失权重（默认0.1）

## 📝 输出指标

训练和评估过程中会输出以下指标：

### 训练阶段
- **loss**: 当前批次损失值
- **top1**: Top-1准确率
- **lr**: 当前学习率

### 评估阶段
- **Overall Metrics**: 整体指标（Accuracy, Precision, Recall, F1-score）
- **Average Metrics**: 三种平均指标（micro, macro, weighted）
- **Per-Class Metrics**: 逐类别指标
- **Confusion Matrix**: 混淆矩阵（百分比形式）
- **AUC**: 每类别的AUC值

详细说明请参考 [OUTPUT_METRICS.md](OUTPUT_METRICS.md)

## 🔄 检查点管理

### 自动恢复训练

使用 `--auto_resume` 参数，系统会自动从 `checkpoint_dir` 中加载最新的检查点继续训练。

### 手动指定检查点

```bash
--resume_path /path/to/checkpoint.pth
```

### 预训练权重

```bash
--pretrain /path/to/pretrained.pth
```

## 📚 相关文档

- [ARCHITECTURE_DETAILED.md](ARCHITECTURE_DETAILED.md) - 详细架构说明（含数学公式）
- [MODULE_OUTPUTS.md](MODULE_OUTPUTS.md) - 模块输出格式说明
- [OUTPUT_METRICS.md](OUTPUT_METRICS.md) - 输出指标详细说明
- [损失函数详细介绍.md](损失函数详细介绍.md) - 损失函数说明
- [环境配置说明-zy虚拟环境.md](环境配置说明-zy虚拟环境.md) - 环境配置指南

## 🛠️ 技术栈

- **深度学习框架**: PyTorch 2.0.0+ (CUDA 11.8)
- **计算机视觉**: torchvision, PIL
- **数据处理**: numpy, pandas
- **评估指标**: scikit-learn
- **可视化**: matplotlib, seaborn
- **视频处理**: av (PyAV)

## ⚙️ 系统要求

- **GPU**: 支持CUDA的NVIDIA GPU（推荐显存≥16GB）
- **内存**: 建议≥32GB
- **存储**: 建议≥100GB可用空间
- **操作系统**: Linux（推荐Ubuntu 20.04+）

## 📄 许可证

本项目仅供研究使用。

## 👥 贡献

如有问题或建议，请提交Issue或Pull Request。

## 📧 联系方式

如有技术问题，请参考项目文档或提交Issue。

---

**注意**: 本项目为研究项目，使用前请确保已正确配置环境并准备好数据。
