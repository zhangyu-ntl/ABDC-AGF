#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

DATA_ROOT="${DATA_ROOT:-/path/to/behavior}"

# 6 个专家模型路径（请按实际情况修改）
CKPT1="${CKPT1:-train_output/expert1/best_model.pth}"
CKPT2="${CKPT2:-train_output/expert2/best_model.pth}"
CKPT3="${CKPT3:-train_output/expert3/best_model.pth}"
CKPT4="${CKPT4:-train_output/expert4/best_model.pth}"
CKPT5="${CKPT5:-train_output/expert5/best_model.pth}"
CKPT6="${CKPT6:-train_output/expert6/best_model.pth}"

WEIGHTS="1 1 1 1 1 1"

echo "[INFO] 开始运行阶段 A 融合（6 专家等权重）..."
python3 ./training/ensemble_inference.py \
  --checkpoints "${CKPT1}" "${CKPT2}" "${CKPT3}" "${CKPT4}" "${CKPT5}" "${CKPT6}" \
  --weights ${WEIGHTS} \
  --val_list_path "${DATA_ROOT}/val_balanced.csv" \
  --val_data_root "${DATA_ROOT}/val-video" \
  --accel_val_dir "${DATA_ROOT}/val-table" \
  --use_tta \
  --tta_num_augments 5 \
  --device cuda

echo "[INFO] 阶段 A 融合完成。"
