#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")/.."

DATA_ROOT="${DATA_ROOT:-/path/to/behavior}"

CKPT1="${CKPT1:-train_output/expert1/best_model.pth}"
CKPT2="${CKPT2:-train_output/expert2/best_model.pth}"
CKPT3="${CKPT3:-train_output/expert3/best_model.pth}"
CKPT4="${CKPT4:-train_output/expert4/best_model.pth}"
CKPT5="${CKPT5:-train_output/expert5/best_model.pth}"
CKPT6="${CKPT6:-train_output/expert6/best_model.pth}"

CACHE_NPZ="${CACHE_NPZ:-train_output/fusion_pipeline_logs/stageABC_logits_cache.npz}"

echo "[INFO] 开始运行阶段 B（每类别专家权重优化）..."
python3 ./training/ensemble_stage_bc.py \
  --mode stageB \
  --checkpoints "${CKPT1}" "${CKPT2}" "${CKPT3}" "${CKPT4}" "${CKPT5}" "${CKPT6}" \
  --val_list_path "${DATA_ROOT}/val_balanced.csv" \
  --val_data_root "${DATA_ROOT}/val-video" \
  --accel_val_dir "${DATA_ROOT}/val-table" \
  --tta_num_augments 1 \
  --batch_size 1 \
  --cache_npz "${CACHE_NPZ}" \
  --device cuda

echo "[INFO] 阶段 B 完成。"
